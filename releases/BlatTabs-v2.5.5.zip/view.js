// === Тема (тёмная/светлая) ===
// Состояние — в chrome.storage.local, ключ 'blattam-theme' ('dark'/'light'),
// по умолчанию светлая. Применяем сохранённую тему ДО первого рендера
// (loadData() вызывается в конце файла) — чтобы страница не мигала.

function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
}

chrome.storage.local.get(['blattam-theme'], (result) => {
  applyTheme(result['blattam-theme'] === 'dark' ? 'dark' : 'light');
  applyThemeButtons(); // активная кнопка в настройках — под сохранённую тему
});

// «Тема» в настройках: Светлая/Тёмная (blattam-theme, local) — переключатель
// переехал из левой рейки в панель «Внешний вид»
function applyThemeButtons() {
  const cur = document.documentElement.dataset.theme;
  const l = document.getElementById('theme-btn-light');
  const d = document.getElementById('theme-btn-dark');
  if (l) l.classList.toggle('active', cur !== 'dark');
  if (d) d.classList.toggle('active', cur === 'dark');
}
function setTheme(theme) {
  applyTheme(theme);
  applyThemeButtons();
  chrome.storage.local.set({ 'blattam-theme': theme });
}
const themeBtnLight = document.getElementById('theme-btn-light');
const themeBtnDark = document.getElementById('theme-btn-dark');
if (themeBtnLight) themeBtnLight.addEventListener('click', () => setTheme('light'));
if (themeBtnDark) themeBtnDark.addEventListener('click', () => setTheme('dark'));

// === Фон (кастомная картинка-фон) ===
// blattam-bg-image — data URL (большой ключ — только chrome.storage.local;
// лимит ~4 МБ, проверка по длине data URL при выборе файла). Применяем
// сохранённый фон там же, где тему — ДО первого рендера (без «вспышки»).
function applyBackgroundImage(dataUrl) {
  // .center (центр) имеет собственный непрозрачный фон var(--bg), перекрывающий
  // body (рейки — var(--rail-bg)) — картинку вешаем и на body, и на центр:
  // визуально фон за центральной областью (обработчик вешает оба инлайн-стиля,
  // тема не влияет: background-color темы остаётся под картинкой).
  const targets = [document.body, document.getElementById('center-pane')];
  targets.forEach((el) => {
    if (!el) return;
    if (dataUrl) {
      el.style.backgroundImage = 'url("' + dataUrl + '")';
      el.style.backgroundSize = 'cover';
      el.style.backgroundPosition = 'center';
      el.style.backgroundAttachment = 'fixed';
    } else {
      ['background-image', 'background-size', 'background-position', 'background-attachment']
        .forEach((prop) => el.style.removeProperty(prop));
    }
  });
  const preview = document.getElementById('bg-preview');
  const clearBtn = document.getElementById('bg-clear-btn');
  if (preview) {
    preview.style.display = dataUrl ? 'block' : 'none';
    if (dataUrl) preview.src = dataUrl;
  }
  if (clearBtn) clearBtn.style.display = dataUrl ? '' : 'none';
}

chrome.storage.local.get(['blattam-bg-image'], (result) => {
  applyBackgroundImage(result['blattam-bg-image'] || '');
});

// === Фоны боковых реек (левая/правая) ===
// blattam-bg-image-left / blattam-bg-image-right — data URL (как blattam-bg-image:
// только chrome.storage.local, лимит ~4 МБ). Применяем на #rail-left / #rail-right
// (cover/center/fixed) там же, где тему и фон — ДО первого рендера (без «вспышки»).
function applyRailBackgroundImage(which, dataUrl) {
  const el = document.getElementById('rail-' + which);
  if (el) {
    if (dataUrl) {
      el.style.backgroundImage = 'url("' + dataUrl + '")';
      el.style.backgroundSize = 'cover';
      el.style.backgroundPosition = 'center';
      el.style.backgroundAttachment = 'fixed';
    } else {
      ['background-image', 'background-size', 'background-position', 'background-attachment']
        .forEach((prop) => el.style.removeProperty(prop));
    }
  }
  const preview = document.getElementById('bg-' + which + '-preview');
  const clearBtn = document.getElementById('bg-' + which + '-clear-btn');
  if (preview) {
    preview.style.display = dataUrl ? 'block' : 'none';
    if (dataUrl) preview.src = dataUrl;
  }
  if (clearBtn) clearBtn.style.display = dataUrl ? '' : 'none';
}

chrome.storage.local.get(['blattam-bg-image-left', 'blattam-bg-image-right'], (result) => {
  applyRailBackgroundImage('left', result['blattam-bg-image-left'] || '');
  applyRailBackgroundImage('right', result['blattam-bg-image-right'] || '');
});
// Быстрый поиск (экспериментальный): blattam-quick-search (local), по умолчанию off.
let quickSearchOn = false;
// Захват фокуса у адресной строки: после Ctrl+T / «+» фокус у омнибокса Chrome,
// и печатание уходит в адресную строку, а не на страницу (быстрый поиск молчит).
// Скриптовый DOM-фокус возвращает фокус в страницу. Работает только при
// включённом быстром поиске (иначе печатание всё равно никуда бы не денется).
window.__qsFocusInitCalls = 0;
function grabPageFocus(force) {
  if (!force && document.hasFocus()) return;
  window.__qsFocusInitCalls++;
  window.focus();
  // body фокусируется скриптом только с tabindex (проверено в Chromium)
  const target = document.body || document.documentElement;
  if (target !== document.documentElement && !target.hasAttribute('tabindex')) {
    target.setAttribute('tabindex', '-1');
  }
  target.focus();
}
function initFocusGrab() {
  grabPageFocus(true); // первая попытка сразу: страница только загрузилась
  setTimeout(() => grabPageFocus(), 250); // Chrome может держать омнибокс ещё немного
  setTimeout(() => grabPageFocus(), 700);
}
chrome.storage.local.get(['blattam-quick-search'], (result) => {
  quickSearchOn = result['blattam-quick-search'] === true;
  const qsTgl = document.getElementById('qs-toggle');
  if (qsTgl) qsTgl.checked = quickSearchOn;
  if (quickSearchOn) initFocusGrab();
});

// === Цвет вкладок (кастомный фон карточек) ===
// blattam-tab-color — hex (например '#8a6d5c'); пустое значение — токены темы.
// Применяем там же, где тему и фон — ДО первого рендера (без «вспышки»):
// цвет живёт в инлайн-стиле documentElement (переопределяет --tab-card-bg),
// поэтому переживает перерисовку карточек и смену темы (токен сбрасывается).
function themeCardBgHex() {
  // текущий фон карточки темы (для дефолтного значения пикера) — из токена, не литерала
  return getComputedStyle(document.documentElement).getPropertyValue('--card-bg').trim();
}

function applyTabCardColor(hex) {
  const root = document.documentElement;
  if (hex) root.style.setProperty('--tab-card-bg', hex);
  else root.style.removeProperty('--tab-card-bg'); // токены темы возвращают дефолт
  const input = document.getElementById('tab-color-input');
  const resetBtn = document.getElementById('tab-color-reset');
  if (input) {
    const val = hex || themeCardBgHex();
    if (val) input.value = val;
  }
  if (resetBtn) resetBtn.style.display = hex ? '' : 'none';
}

chrome.storage.local.get(['blattam-tab-color'], (result) => {
  applyTabCardColor(result['blattam-tab-color'] || '');
});

// === Кастомизация визуала (blattam-custom-theme) ===
// Один local-ключ: объект «управляемые токены → значения» (цвета — hex,
// геометрия — px, шрифт — 'serif'/'mono'). Хранятся только НЕДЕФОЛТНЫЕ
// значения; пустой объект → ключ удаляется. Применяем инлайн-стилем
// documentElement (переопределяет токены темы, переживает перерисовку и
// смену темы — как blattam-tab-color).
const CUST_COLORS = [
  { token: '--bg', id: 'bg' },
  { token: '--rail-bg', id: 'rail' },
  { token: '--surface', id: 'surface' },
  { token: '--text', id: 'text' },
  { token: '--text-muted', id: 'muted' },
  { token: '--card-name', id: 'cardname' },
  { token: '--ink', id: 'ink' },
  { token: '--ghost-bg', id: 'ghostbg' },
  { token: '--ghost-ring', id: 'ghostring' }
];
const CUST_GEO = [
  { token: '--card-radius', id: 'radius' },
  { token: '--card-gap', id: 'gap' },
  { token: '--card-min', id: 'width' },
  { token: '--card-name-size', id: 'fontsize' },
  { token: '--rail-left-w', id: 'railleft' },
  { token: '--rail-right-w', id: 'railright' }
];
const CUST_FONTS = {
  serif: "'Georgia', 'Times New Roman', serif",
  mono: "'Consolas', 'Cascadia Mono', ui-monospace, monospace"
};
const CUST_TOKENS = CUST_COLORS.concat(CUST_GEO).map((x) => x.token).concat(['--font-ui']);

// Дефолт темы для токена: читаем, ВРЕМЕННО сняв инлайн-переопределение
// (иначе прочитался бы текущий кастомный цвет, а не значение темы).
function custThemeDefault(token) {
  const root = document.documentElement;
  const prev = root.style.getPropertyValue(token);
  root.style.removeProperty(token);
  const v = getComputedStyle(root).getPropertyValue(token).trim();
  if (prev) root.style.setProperty(token, prev);
  return v;
}

function applyCustomTheme(obj) {
  const root = document.documentElement;
  for (const tk of CUST_TOKENS) {
    const v = (obj && obj[tk]) ? String(obj[tk]) : '';
    const resolved = (tk === '--font-ui') ? (CUST_FONTS[v] || '') : v;
    if (resolved) root.style.setProperty(tk, resolved);
    else root.style.removeProperty(tk);
  }
  for (const c of CUST_COLORS) {
    const input = document.getElementById('cust-color-' + c.id);
    const reset = document.querySelector('[data-cust-reset="' + c.id + '"]');
    if (!input) continue;
    const custom = (obj && obj[c.token]) ? String(obj[c.token]) : '';
    const def = custThemeDefault(c.token);
    input.value = (custom || def) || '#ffffff';
    if (reset) reset.style.display = custom ? '' : 'none';
  }
  for (const g of CUST_GEO) {
    const input = document.getElementById('cust-geo-' + g.id);
    const val = document.getElementById('cust-geo-' + g.id + '-val');
    const reset = document.querySelector('[data-cust-reset="' + g.id + '"]');
    if (!input) continue;
    const custom = (obj && obj[g.token]) ? String(obj[g.token]) : '';
    const def = custThemeDefault(g.token);
    const shown = custom || def;
    if (shown && !isNaN(parseFloat(shown))) input.value = String(parseFloat(shown));
    if (val) val.textContent = shown;
    if (reset) reset.style.display = custom ? '' : 'none';
  }
  const font = document.getElementById('cust-font');
  if (font) font.value = (obj && CUST_FONTS[obj['--font-ui']] ? obj['--font-ui'] : 'default');
  const rc = document.getElementById('cust-colors-reset-all');
  if (rc) rc.style.display = CUST_COLORS.some((c) => obj && obj[c.token]) ? '' : 'none';
  const rg = document.getElementById('cust-geo-reset-all');
  if (rg) rg.style.display = CUST_GEO.some((g) => obj && obj[g.token]) ? '' : 'none';
}

function collectCustomFromControls() {
  const out = {};
  for (const c of CUST_COLORS) {
    const input = document.getElementById('cust-color-' + c.id);
    if (!input) continue;
    const v = String(input.value).toLowerCase();
    if (v && v !== custThemeDefault(c.token).toLowerCase()) out[c.token] = v;
  }
  for (const g of CUST_GEO) {
    const input = document.getElementById('cust-geo-' + g.id);
    if (!input) continue;
    const val = parseFloat(input.value);
    const def = parseFloat(custThemeDefault(g.token));
    if (!isNaN(val) && !isNaN(def) && val !== def) out[g.token] = val + 'px';
  }
  const font = document.getElementById('cust-font');
  if (font && font.value !== 'default') out['--font-ui'] = font.value;
  return out;
}

function saveCustomTheme() {
  const obj = collectCustomFromControls();
  if (Object.keys(obj).length === 0) chrome.storage.local.remove('blattam-custom-theme');
  else chrome.storage.local.set({ 'blattam-custom-theme': obj });
}

chrome.storage.local.get(['blattam-custom-theme'], (result) => {
  applyCustomTheme(result['blattam-custom-theme'] || null);
});
const createGroupBtn = document.getElementById('create-group-btn');
if (createGroupBtn) createGroupBtn.addEventListener('click', createGroupInActiveSpace);

// === DOM-ссылки ===

const tabsList = document.getElementById('tabs-list');
const emptyState = document.getElementById('empty-state');
const searchInput = document.getElementById('search');
const noResults = document.getElementById('no-results');
const metaLabel = document.getElementById('meta-label');
const metaCount = document.getElementById('meta-count');
const spacesBar = document.getElementById('spaces-bar');
const spaceChips = document.getElementById('space-chips');
const addSpaceBtn = document.getElementById('add-space-btn');
const metaRenameBtn = document.getElementById('meta-rename-btn');
const metaDeleteBtn = document.getElementById('meta-delete-btn');

// «Изменить»/«Удалить» в мета-строке (статичные кнопки, привязка один раз) —
// на ТЕКУЩЕЕ (активное) пространство: резолвим его В МОМЕНТ КЛИКА, строка
// живёт дольше, чем активное пространство
if (metaRenameBtn) metaRenameBtn.addEventListener('click', () => {
  const sp = allSpaces.find(x => x.id === activeSpaceId);
  if (!sp) return;
  openRenameSpaceModal(sp.id, sp.name);
});
if (metaDeleteBtn) metaDeleteBtn.addEventListener('click', () => {
  const sp = allSpaces.find(x => x.id === activeSpaceId);
  if (!sp) return;
  if (confirm(t('delete_space_confirm', { name: sp.name }))) {
    chrome.runtime.sendMessage({ action: 'delete-space', id: sp.id });
  }
});

// Модалка (создание/переименование пространства, создание группы)
const spaceModal = document.getElementById('space-modal');
const modalTitle = document.getElementById('modal-title');
const spaceNameInput = document.getElementById('space-name-input');
const modalCancel = document.getElementById('modal-cancel');
const modalConfirm = document.getElementById('modal-confirm');

// Модалка редактирования вкладки (имя / адрес / комментарий)
const editTabModal = document.getElementById('edit-tab-modal');
const editNameInput = document.getElementById('edit-name-input');
const editUrlInput = document.getElementById('edit-url-input');
const editCommentInput = document.getElementById('edit-comment-input');
const editCancel = document.getElementById('edit-cancel');
const editConfirm = document.getElementById('edit-confirm');
let editTabRef = null; // вкладка, открытая в модалке редактирования

// Панель массового выбора
const selectionBar = document.getElementById('selection-bar');
const selectionCount = document.getElementById('selection-count');
const openSelectedBtn = document.getElementById('open-selected-btn');
const clearSelectionBtn = document.getElementById('clear-selection-btn');
const deleteSelectedBtn = document.getElementById('delete-selected-btn');

let allTabs = [];
let allSpaces = [];   // { id, name } — плоский список (без вложенности)
let allGroups = [];   // { id, name, spaceId, collapsed } — группы внутри пространств
let activeSpaceId = ''; // активное пространство (по id — переживает перерисовку)
let modalCallback = null;
let modalAllowEmpty = false; // модалки создания допускают пустое имя (авто-«Пространство N» / «Группа N»)
let selectedUrls = new Set(); // выбор вкладок для массового открытия
// Параметры анимаций pointer-драга (читаются ПЕРЕД каждым использованием —
// тесты могут их обнулить). slideMs — FLIP-сдвиг соседей, settleMs —
// «посадка» клона в слот, liftScale — масштаб подъёма клона.
window.blatamFx = { slideMs: 200, settleMs: 180, liftScale: 1.02 };

let dragSourceUrl = null; // URL перетаскиваемой карточки (для reorder; индексы в payload могут устареть)
let dragSourceCardEl = null; // DOM-элемент перетаскиваемой карточки (исключается из расчёта зазора)
let dragCardSize = null; // размер схваченной карточки (w/h) — снят до хайда (display:none → rects 0×0)
let dragGhostSlot = null; // ghost-slot: пустая заглушка размера карточки на её месте в сетке
let dragSourceGroupId = null; // id перетаскиваемой группы (reorder шапок внутри пространства)
let pdLastTouchCard = null; // last card TOUCHED by the cursor (card path): reflow only on touch
let pdLastTouchAnchor = null; // the anchor returned at that touch (frozen while the cursor stays inside the card; gap/sticky anchors must not poison it)
let dragSourceSpaceId = null; // id перетаскиваемого чипа (reorder пространств в ряду чипов)
let dragGhostChipSlot = null; // ghost-slot чипа: тёплая заглушка размера чипа (26px) в ряду
                              // #space-chips — единственный индикатор вставки при drag чипа
let dragWrapHiddenCard = null; // «row-full» группа: крайняя карточка группы, временно
                               // скрытая — тёплая заглушка внутри полной группы дорастила
                               // бы новую строку; скрытие последней карточки держит число
                               // строк постоянным (возврат: заглушка ушла из группы / драг
                               // закончился / перерисовка)
let dragWrapHiddenGroup = null; // groupId той группы: та же карточка держится скрытой,
                                // пока заглушка внутри неё
let dragRowKeepers = [];       // .tab-row-keeper: невидимые карточки-холдеры,
                               // держащие последнюю строку исходной секции, пока
                               // ghost-заглушка уехала из неё (или спрятана)
let dragRowKeeperSection = null; // секция текущих холдеров: groupId (null — без группы)
let dragOverChipTarget = null; // последний target dragover чипа — чтобы отложенное создание
                               // заглушки (dragstart setTimeout) повторило состояние, если
                               // первый dragover уже попал на целевой чип ПЕРЕД таймером
let dragOverChipSide = null; // сторона этого первого dragover ('before'/'after'):
                             // повтор применяется по ЗАПИСАННОЙ стороне — координаты
                             // относятся к ряду ДО reflow, после вставки заглушки
                             // пересчёт по X дал бы противоположную половину
let pendingChipClickAfterDrag = false; // one-shot: ложный клик по чипу-цели рождается
                        // в момент дропа (реальный Chrome: drop → click → dragend) —
                        // вооружаем на dragstart чипа и на drop; гасим ровно ОДИН;
                        // настоящее нажатие (mousedown) сбрасывает флаг раньше клика
let dragBatchUrls = null; // все вкладки, уезжающие с перетаскиваемой карточкой:
                          // выделенный батч (порядок — исходный, из allTabs) или [dragSourceUrl]
let dragOverTarget = null; // последний target dragover — чтобы отложенное создание
                           // заглушки (dragstart setTimeout) повторило состояние, если
                           // первый dragover уже попал на шапку/слот ПЕРЕД таймером
let dragOverTargetXY = null; // координаты этого dragover (clientX/clientY) —
                             // пустая зона карт.области группы повторяется по ГЕОМЕТРИИ,
                             // а не по элементу цели
let lastDragEndAt = 0; // время последнего dragend (карточки или шапки): клик по шапке
                        // сразу после дропа — не действие пользователя, не сворачиваем группу
let pendingGbarClickAfterDrag = false; // one-shot: ложный клик по шапке рождается в момент
                        // дропа — реальный Chrome генерирует его на drop-цели ДО dragend
                        // источника (замер: drop → click → dragend), а не только после;
                        // поэтому флаг вооружаем на dragstart карточки и на drop по шапке
                        // (не только на dragend) — гасим ровно ОДИН такой клик; новое
                        // нажатие мыши (mousedown) раньше его клика сбрасывает флаг
let activeUrl = null; // карточка, выбранная клавиатурой (по URL — переживает перерисовку)
let openModalId = null; // id открытой модалки — чтобы глобальный keydown её не перехватывал
let browserTabs = []; // все открытые вкладки браузера (blattam-browser-tabs, все окна)
let browserWindowId = null; // id этого окна — рейка показывает вкладки только его
let dragSourceBrowserTab = null; // вкладки рейки, которую тянут: {id,url,title,favIconUrl,windowId,index}
let dragBrowserTabGhost = null;const browserTabsList = document.getElementById('browser-tabs-list'); // рейка: список открытых вкладок
const railRight = document.getElementById('rail-right'); // правая рейка — цель дропа карточки (открыть сайт фоном)
let btDragItem = null; // элемент рейки, который тащат (cleanup по id переживает перерисовку)
let btDragHeight = 30; // высота элемента ДО display:none (размер заглушки)
let btDropCommitted = false; // дроп обработан (рейка/центр) — ложный клик гасится
let pendingBtClickAfterDrag = false; // one-shot: ложный post-drop-клик по элементу рейки
let pendingCardClickAfterDrag = false; // one-shot: ложный post-drop-клик по центральной карточке (открыл бы вкладку) — вооружается на dragstart карточки и вкладки рейки
//  // тёплая заглушка рейки (.bt-ghost-slot) на слоте схваченной вкладки


function genId(prefix) {
  return (prefix || 'x') + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

// Отмечаем открытую/закрытую модалку (для global keydown-гарда)
function setModalOpen(id) {
  openModalId = id || null;
}

function isAnyModalOpen() {
  return openModalId !== null;
}

// === Миграция: legacy-папки → пространства (чистая, идемпотентная) ===
// Вызывается, когда ключ 'blattam-spaces' отсутствует: каждое папки (любой
// вложенности) становится отдельным плоским пространством с тем же именем,
// вкладки перемещаются folderId → spaceId, вкладки без папки (folderId
// null/отсутствует/неизвестная) → пространство «Мои вкладки». Группы не
// создаются — все legacy-вкладки без группы.
function migrateFoldersToSpaces(tabs, spaces, folders) {
  const folderToSpaceId = {};
  (folders || []).forEach(f => {
    if (!f || !f.id) return;
    const sp = { id: genId('sp'), name: f.name };
    spaces.push(sp);
    folderToSpaceId[f.id] = sp.id;
  });
  let defaultSpace = null;
  (tabs || []).forEach(tb => {
    if (!tb) return;
    if (tb.folderId != null && folderToSpaceId[tb.folderId]) {
      tb.spaceId = folderToSpaceId[tb.folderId];
    } else {
      if (!defaultSpace) {
        defaultSpace = { id: genId('sp'), name: t('default_space') };
        spaces.push(defaultSpace);
      }
      tb.spaceId = defaultSpace.id;
    }
    tb.groupId = null;
    delete tb.folderId;
  });
}

// === Миграция: вкладки sync → local (идемпотентная) ===
// blattam-tabs — большой ключ (~10 МБ), живёт в chrome.storage.local
// (per-device; лимит sync 8 КБ/ключ ломал запись ~20+ вкладок). ДО первого
// рендера: если local пуст (нет/пусто), а sync непуст — копируем ключ из sync
// в local и удаляем sync-ключ. Если local заполнен — только чистим stale-sync.
let tabsMigrated = null;
function migrateTabsToLocalStorage() {
  if (tabsMigrated) return tabsMigrated;
  tabsMigrated = (async () => {
    const localData = await chrome.storage.local.get('blattam-tabs');
    const syncData = await chrome.storage.sync.get('blattam-tabs');
    const localTabs = Array.isArray(localData['blattam-tabs']) ? localData['blattam-tabs'] : [];
    const syncTabs = Array.isArray(syncData['blattam-tabs']) ? syncData['blattam-tabs'] : [];
    if (localTabs.length === 0 && syncTabs.length > 0) {
      await chrome.storage.local.set({ 'blattam-tabs': syncTabs });
    }
    if (syncData['blattam-tabs'] !== undefined) {
      await chrome.storage.sync.remove('blattam-tabs');
    }
  })();
  return tabsMigrated;
}

// === Загрузка данных ===

function loadData() {
  (async () => {
    await migrateTabsToLocalStorage(); // ДО первого рендера: вкладки — из local
    const localData = await chrome.storage.local.get(['blattam-tabs']);
    const result = await chrome.storage.sync.get(['blattam-spaces', 'blattam-groups', 'blattam-last-space', 'blattam-folders']);
    const tabs = Array.isArray(localData['blattam-tabs']) ? localData['blattam-tabs'] : [];
    const spaces = Array.isArray(result['blattam-spaces']) ? result['blattam-spaces'] : [];
    const groups = Array.isArray(result['blattam-groups']) ? result['blattam-groups'] : [];
    const folders = result['blattam-folders'];

    const updates = {};       // sync (пространства/группы/last-space)
    const localUpdates = {};  // local (вкладки)

    // Миграция legacy (ДО первого рендера): нет 'blattam-spaces', но есть
    // 'blattam-folders' или вкладки с folderId
    if (!Array.isArray(result['blattam-spaces']) && (folders !== undefined || tabs.some(t => t && t.folderId != null))) {
      migrateFoldersToSpaces(tabs, spaces, folders);
      localUpdates['blattam-tabs'] = tabs;
      updates['blattam-spaces'] = spaces;
    }

    // Свежее состояние — всегда есть хотя бы одно пространство
    if (spaces.length === 0) {
      spaces.push({ id: genId('sp'), name: t('default_space') });
      updates['blattam-spaces'] = spaces;
    }

    // Вкладки без spaceId (вручную внесённые данные) — в первое пространство
    let tabsChanged = false;
    tabs.forEach(t => {
      if (t && !t.spaceId) { t.spaceId = spaces[0].id; tabsChanged = true; }
    });
    if (tabsChanged) localUpdates['blattam-tabs'] = tabs;

    // Активное пространство: последнее посещённое (blattam-last-space),
    // если оно ещё существует, иначе первое
    const last = result['blattam-last-space'];
    activeSpaceId = (last && spaces.some(s => s.id === last)) ? last : spaces[0].id;
    if (updates['blattam-spaces'] && last !== activeSpaceId) updates['blattam-last-space'] = activeSpaceId;

    allTabs = tabs;
    allSpaces = spaces;
    allGroups = groups;

    if (Object.keys(updates).length) {
      if (folders !== undefined) chrome.storage.sync.remove('blattam-folders');
      chrome.storage.sync.set(updates);
    }
    if (Object.keys(localUpdates).length) {
      chrome.storage.local.set(localUpdates);
    }
    renderSpaces();
    renderTabs();
  })();
}

// === Пространства (чипы) ===

function spaceLabel() {
  const s = allSpaces.find(x => x.id === activeSpaceId);
  return s ? s.name : t('default_space');
}

function renderSpaces() {
  spaceChips.innerHTML = '';
  // Перерисовка во время drag чипа уносит chip-заглушку из DOM — сбрасываем
  // ссылку, чтобы она не «воскресла» после dragend
  if (dragGhostChipSlot && !dragGhostChipSlot.isConnected) dragGhostChipSlot = null;
  allSpaces.forEach(sp => {
    const chip = document.createElement('button');
    chip.className = 'chip space-chip' + (sp.id === activeSpaceId ? ' active' : '');
    chip.dataset.spaceId = sp.id;

    const name = document.createElement('span');
    name.className = 'chip-name';
    name.textContent = sp.name;
    chip.appendChild(name);

    // «Изменить»/«Удалить» — НЕ на чипе: кнопки мету-строки (ниже,
    // .meta-actions) действуют на АКТИВНОЕ пространство, резолв в момент клика

    // DnD: чип принимает перетаскиваемую карточку
    attachSpaceDrop(chip, sp.id);

    // DnD-источник: чип тянем на другой чип — reorder пространств (порядок
    // чипов = порядок массива blattam-spaces). Пейлоад: id пространства
    // (у карточки — индекс вкладки)
    chip.draggable = true;
    pcdBindChip(chip, sp.id); // pointer-путь (реальный Chrome) — см. ниже
    chip.addEventListener('dragstart', (e) => {
      // Нативный HTML5-драг отменяется в реальном Chrome (цикл ведёт
      // pointer-путь, см. «Pointer drag of space chips» ниже); синтетический
      // dragstart харнесса (не-trusted) проходит дальше и работает без изменений
      e.preventDefault();
      if (e.isTrusted) return;
      e.dataTransfer.setData('text/plain', sp.id);
      e.dataTransfer.effectAllowed = 'move';
      dragSourceSpaceId = sp.id;
      dragOverChipTarget = null; // свежий драг — целевой dragover ещё не приходил
      dragOverChipSide = null;
      chip.classList.add('dragging');
      // Ложный клик вооружаем уже на dragstart: реальный Chrome генерирует
      // его на drop-цели ДО dragend источника
      pendingChipClickAfterDrag = true;
      // Исходный чип исчезает из ряда (нативный drag-образ браузера следует за
      // курсором); место занимает тёплая заглушка чипа — отложенно:
      // display:none в самом dragstart «залипает» HTML5-drag в Chrome
      setTimeout(() => {
        // Перерисовка во время драга уносит чип из DOM, а поздний drop/dragend
        // уже решил драг — заглушку для отсоединённого чипа не вставляем
        if (dragSourceSpaceId !== sp.id || !chip.isConnected) return;
        if (!dragGhostChipSlot) {
          // Меряем ДО display:none (у скрытого чипа offsetWidth/Height = 0)
          dragGhostChipSlot = makeSpaceGhostSlot(chip);
          chip.insertAdjacentElement('afterend', dragGhostChipSlot);
        }
        chip.style.display = 'none';
        // Гонка: первый dragover мог попасть на целевой чип ПЕРЕД этим таймером
        // (заглушки ещё не существовало). Повторяем его состояние по записанной
        // стороне, иначе свежая заглушка неверно замирает дома.
        if (dragOverChipTarget && dragOverChipTarget.isConnected && dragOverChipTarget !== chip) {
          moveSpaceGhostSlot({ el: dragOverChipTarget, side: dragOverChipSide });
        }
      }, 0);
    });
    chip.addEventListener('dragend', () => {
      lastDragEndAt = Date.now();
      pendingChipClickAfterDrag = true;
      dragSourceSpaceId = null;
      dragOverChipTarget = null; // не держим ссылку на DOM-узел после драга
      dragOverChipSide = null;
      chip.classList.remove('dragging');
      removeSpaceGhostSlot();
      if (chip.isConnected) chip.style.display = ''; // drag без drop — чип обратно в ряд
      document.querySelectorAll('.space-chip.drag-over')
        .forEach(c => c.classList.remove('drag-over'));
    });

    // Клик — переключение пространства. Ложный post-drop клик (без mousedown)
    // гасим ровно один: настоящий press всегда проходит через
    // document-mousedown, сбрасывающий флаг раньше клика
    chip.addEventListener('click', () => {
      if (pendingChipClickAfterDrag) { pendingChipClickAfterDrag = false; return; }
      switchSpace(sp.id);
    });
    spaceChips.appendChild(chip);
  });
}

// Переключение пространства: активное — JS-переменная, blattam-last-space
// обновляется, чтобы следующий newtab-открыв открылся с тем же пространством
function switchSpace(id) {
  if (!id || id === activeSpaceId) return;
  activeSpaceId = id;
  chrome.storage.sync.set({ 'blattam-last-space': id });
  renderSpaces();
  renderTabs(searchInput.value);
}

// "+ Пространство" — создать пространство (пустое имя → «Пространство N»);
// та же модалка — по хоткею (действие newSpace)
function openNewSpaceModal() {
  modalTitle.textContent = t('new_space');
  spaceNameInput.value = '';
  showSpaceModal(true, (name) => {
    chrome.runtime.sendMessage({ action: 'create-space', name }, (result) => {
      // новое пространство становится активным
      if (result && result.id) {
        activeSpaceId = result.id;
        chrome.storage.sync.set({ 'blattam-last-space': result.id });
      }
      renderSpaces();
      renderTabs(searchInput.value);
    });
  });
}
addSpaceBtn.addEventListener('click', openNewSpaceModal);

// Модалка: переименовать пространство
function openRenameSpaceModal(spaceId, currentName) {
  modalTitle.textContent = t('rename_space');
  spaceNameInput.value = currentName;
  showSpaceModal(false, (name) => {
    if (name && name !== currentName) {
      chrome.runtime.sendMessage({ action: 'rename-space', id: spaceId, name });
    }
  });
}

function showSpaceModal(allowEmpty, onConfirm) {
  modalCallback = onConfirm;
  modalAllowEmpty = allowEmpty;
  spaceModal.classList.add('open');
  setModalOpen('space');
  setTimeout(() => spaceNameInput.focus(), 50);
}

modalCancel.addEventListener('click', closeSpaceModal);
spaceModal.addEventListener('click', (e) => {
  if (e.target === spaceModal) closeSpaceModal();
});

function closeSpaceModal() {
  spaceModal.classList.remove('open');
  modalCallback = null;
  modalAllowEmpty = false;
  setModalOpen(null);
}

modalConfirm.addEventListener('click', () => {
  const name = spaceNameInput.value.trim();
  if (!name && !modalAllowEmpty) return;
  if (modalCallback) modalCallback(name);
  closeSpaceModal();
});

spaceNameInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') modalConfirm.click();
  if (e.key === 'Escape') modalCancel.click();
});

// === Модалка: редактирование сохранённой вкладки (имя / адрес / комментарий) ===
function openEditTabModal(tab) {
  editTabRef = tab;
  editNameInput.value = tab.name;
  editUrlInput.value = tab.url;
  editCommentInput.value = tab.comment || '';
  editTabModal.classList.add('open');
  setModalOpen('edit-tab');
  setTimeout(() => { editNameInput.focus(); editNameInput.select(); }, 50);
}

function closeEditTabModal() {
  editTabModal.classList.remove('open');
  editTabRef = null;
  setModalOpen(null);
}

editCancel.addEventListener('click', closeEditTabModal);
// Клик по затемнённому фону НЕ закрывает модалку: при выделении текста
// в поле указатель уносит за окно, и «клик снаружи» бы схлопнул форму.
// Закрытие: Enter (сохранить), «Отмена», Escape.

editConfirm.addEventListener('click', () => {
  if (!editTabRef) return;
  const name = editNameInput.value.trim();
  const url = editUrlInput.value.trim();
  const comment = editCommentInput.value.trim();
  if (!name && !url && !comment) return; // пустая форма — не сохраняем
  // Пустое имя/адрес — старое значение; комментарий пустой — очистить
  chrome.runtime.sendMessage({
    action: 'update-tab',
    index: allTabs.indexOf(editTabRef),
    name: name || editTabRef.name,
    url: url || editTabRef.url,
    comment,
  });
  closeEditTabModal();
});

[editNameInput, editUrlInput, editCommentInput].forEach((inp) => {
  inp.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') editConfirm.click();
    if (e.key === 'Escape') editCancel.click();
  });
});

// === Модалка: настройки (FAQ) ===
// Открытие — кнопка «Настройки» в левой рейке. Закрытие — ✕, клик по затемнённому
// фону (как у модалки пространств) и Escape. setModalOpen('settings') делает
// isAnyModalOpen() истинным, поэтому глобальный keydown (modal check → Escape →
// editable-guard) не перехватывает клавиши, пока модалка открыта.
const settingsModal = document.getElementById('settings-modal');
const settingsCloseBtn = document.getElementById('settings-close');
const settingsBtn = document.getElementById('settings-btn');

function openSettingsModal() {
  settingsModal.classList.add('open');
  setModalOpen('settings');
  setSettingsSection('appearance'); // при каждом открытии — «Внешний вид»
  renderPresetList();
  // пикер «Цвет вкладок» показывает актуальное значение (из local-хранилища)
  chrome.storage.local.get(['blattam-tab-color'], (r) => {
    applyTabCardColor(r['blattam-tab-color'] || '');
  });
  // пикеры кастомизации — актуальные значения (из local-хранилища)
  chrome.storage.local.get(['blattam-custom-theme'], (r) => {
    applyCustomTheme(r['blattam-custom-theme'] || null);
  });
}

function closeSettingsModal() {
  settingsModal.classList.remove('open');
  setModalOpen(null);
}

settingsBtn.addEventListener('click', openSettingsModal);
settingsCloseBtn.addEventListener('click', closeSettingsModal);
settingsModal.addEventListener('click', (e) => {
  if (e.target === settingsModal) closeSettingsModal();
});

// Escape — закрыть (отдельный слушатель: глобальный keydown байлит при открытой модалке)
document.addEventListener('keydown', (e) => {
  if (settingsModal.classList.contains('open') && e.key === 'Escape') closeSettingsModal();
});

// Двухпанное окно: слева навигация разделов («Внешний вид»/«Общие»/«Горячие клавиши»/«Экспериментальное»/«FAQ»/«О программе» — кнопки
// .settings-nav-item), справа — контент; виден только активный
// (#settings-pane-appearance и др. — display:none у неактивной).
// Состояние — module-переменная по id раздела (переживает перерисовку, идемпотентна);
// клик по навигации модалку НЕ закрывает — close-по-фону скоуплен на сам оверлей
// (e.target === settingsModal), а клик по пункту — только по внутренней кнопке.
let settingsSection = 'appearance';
const settingsNavItems = [...settingsModal.querySelectorAll('.settings-nav-item')];
function setSettingsSection(id) {
  if (!settingsNavItems.some((b) => b.dataset.section === id)) id = 'appearance';
  settingsSection = id;
  settingsNavItems.forEach((b) => b.classList.toggle('active', b.dataset.section === id));
  ['appearance', 'general', 'hotkeys', 'experimental', 'faq', 'about'].forEach((s) => {
    const pane = document.getElementById('settings-pane-' + s);
    if (pane) pane.style.display = (s === id) ? '' : 'none';
  });
}
settingsNavItems.forEach((btn) => {
  btn.addEventListener('click', () => setSettingsSection(btn.dataset.section));
});

// «Пресеты» — профили внешнего вида (blattam-presets + blattam-active-preset, local).
// Пресет — снапшот шести ключей: тема / кастомные цвета-геометрия / три фона / цвет вкладок.
// Активный пресет сбрасывается, когда вид поменяли вручную (сравнение значений).
const PRESET_KEYS = ['blattam-theme', 'blattam-custom-theme', 'blattam-bg-image', 'blattam-bg-image-left', 'blattam-bg-image-right', 'blattam-tab-color'];
function presetCollectData(r) {
  return {
    theme: r['blattam-theme'] || null,
    customTheme: r['blattam-custom-theme'] || null,
    bgImage: r['blattam-bg-image'] || null,
    bgImageLeft: r['blattam-bg-image-left'] || null,
    bgImageRight: r['blattam-bg-image-right'] || null,
    tabColor: r['blattam-tab-color'] || null
  };
}

function presetWriteData(data, done) {
  const map = { theme: 'blattam-theme', customTheme: 'blattam-custom-theme', bgImage: 'blattam-bg-image', bgImageLeft: 'blattam-bg-image-left', bgImageRight: 'blattam-bg-image-right', tabColor: 'blattam-tab-color' };
  const set = {}; const rm = [];
  Object.keys(map).forEach((f) => {
    const v = (data || {})[f];
    const empty = (v === null || v === undefined) || (f === 'customTheme' && typeof v === 'object' && Object.keys(v).length === 0);
    if (empty) rm.push(map[f]); else set[map[f]] = v;
  });
  if (!rm.length) { chrome.storage.local.set(set, done); return; }
  if (!Object.keys(set).length) { chrome.storage.local.remove(rm, done); return; }
  chrome.storage.local.set(set, () => chrome.storage.local.remove(rm, done));
}

function renderPresetList() {
  const list = document.getElementById('preset-list');
  if (!list) return;
  chrome.storage.local.get(['blattam-presets', 'blattam-active-preset'], (r) => {
    const presets = r['blattam-presets'] || [];
    const activeId = r['blattam-active-preset'];
    list.innerHTML = '';
    if (!presets.length) {
      const empty = document.createElement('div');
      empty.className = 'preset-empty';
      empty.textContent = t('preset_empty');
      list.appendChild(empty);
      return;
    }
    presets.forEach((p) => {
      const row = document.createElement('div');
      row.className = 'preset-row' + (p.id === activeId ? ' active' : '');
      const name = document.createElement('span');
      name.className = 'preset-name';
      name.textContent = p.name || t('preset_default_name', { n: 1 });
      row.appendChild(name);
      if (p.id === activeId) {
        const badge = document.createElement('span');
        badge.className = 'preset-badge';
        badge.textContent = t('preset_active');
        row.appendChild(badge);
      }
      const applyBtn = document.createElement('button');
      applyBtn.className = 'btn btn-ghost preset-apply';
      applyBtn.textContent = t('preset_apply');
      applyBtn.addEventListener('click', () => applyPreset(p.id));
      row.appendChild(applyBtn);
      const delBtn = document.createElement('button');
      delBtn.className = 'btn btn-ghost preset-del';
      delBtn.textContent = t('preset_delete');
      delBtn.addEventListener('click', () => deletePreset(p.id));
      row.appendChild(delBtn);
      list.appendChild(row);
    });
  });
}

function savePresetAsNew() {
  const nameEl = document.getElementById('preset-name-input');
  chrome.storage.local.get(PRESET_KEYS.concat(['blattam-presets']), (r) => {
    const presets = r['blattam-presets'] || [];
    const name = (nameEl.value || '').trim() || t('preset_default_name', { n: presets.length + 1 });
    const preset = { id: genId('p'), name: name, createdAt: Date.now(), data: presetCollectData(r) };
    presets.push(preset);
    chrome.storage.local.set({ 'blattam-presets': presets, 'blattam-active-preset': preset.id });
    nameEl.value = '';
  });
}
function applyPreset(id) {
  chrome.storage.local.get(['blattam-presets'], (r) => {
    const p = (r['blattam-presets'] || []).find((x) => x.id === id);
    if (!p) return;
    presetWriteData(p.data, () => {
      chrome.storage.local.set({ 'blattam-active-preset': id });
    });
  });
}
function deletePreset(id) {
  chrome.storage.local.get(['blattam-presets', 'blattam-active-preset'], (r) => {
    const presets = (r['blattam-presets'] || []).filter((x) => x.id !== id);
    if (r['blattam-active-preset'] === id) {
      chrome.storage.local.set({ 'blattam-presets': presets }, () => chrome.storage.local.remove('blattam-active-preset'));
    } else {
      chrome.storage.local.set({ 'blattam-presets': presets });
    }
  });
}
function syncActivePreset() {
  chrome.storage.local.get(PRESET_KEYS.concat(['blattam-active-preset', 'blattam-presets']), (r) => {
    const activeId = r['blattam-active-preset'];
    if (!activeId) return;
    const p = (r['blattam-presets'] || []).find((x) => x.id === activeId);
    if (!p) { chrome.storage.local.remove('blattam-active-preset'); return; }
    const same = JSON.stringify(presetCollectData(r)) === JSON.stringify(p.data || {});
    if (!same) chrome.storage.local.remove('blattam-active-preset');
  });
}
const presetSaveBtn = document.getElementById('preset-save-btn');
presetSaveBtn.addEventListener('click', savePresetAsNew);

// «Фон» в настройках: картинка → data URL → blattam-bg-image (local).
const bgFileBtn = document.getElementById('bg-file-btn');
const bgFileInput = document.getElementById('bg-file-input');
const bgClearBtn = document.getElementById('bg-clear-btn');

bgFileBtn.addEventListener('click', () => bgFileInput.click());

bgFileInput.addEventListener('change', (e) => {
  const file = e.target.files[0];
  e.target.value = ''; // сброс input — тот же файл можно выбрать повторно
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (event) => {
    const dataUrl = String(event.target.result || '');
    if (dataUrl.length > 4000000) {
      alert(t('bg_too_big'));
      return;
    }
    chrome.storage.local.set({ 'blattam-bg-image': dataUrl });
    applyBackgroundImage(dataUrl);
  };
  reader.readAsDataURL(file);
});

bgClearBtn.addEventListener('click', () => {
  chrome.storage.local.remove('blattam-bg-image');
  applyBackgroundImage('');
});

// «Фон левой/правой рейки» в настройках: картинка → data URL →
// blattam-bg-image-left / blattam-bg-image-right (local), тот же паттерн FileReader.
[['blattam-bg-image-left', 'left'], ['blattam-bg-image-right', 'right']].forEach((pair) => {
  const key = pair[0];
  const which = pair[1];
  const fileBtn = document.getElementById('bg-' + which + '-file-btn');
  const fileInput = document.getElementById('bg-' + which + '-file-input');
  const clearBtn = document.getElementById('bg-' + which + '-clear-btn');

  fileBtn.addEventListener('click', () => fileInput.click());

  fileInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    e.target.value = ''; // сброс input — тот же файл можно выбрать повторно
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = String(event.target.result || '');
      if (dataUrl.length > 4000000) {
        alert(t('bg_too_big'));
        return;
      }
      chrome.storage.local.set({ [key]: dataUrl });
      applyRailBackgroundImage(which, dataUrl);
    };
    reader.readAsDataURL(file);
  });

  clearBtn.addEventListener('click', () => {
    chrome.storage.local.remove(key);
    applyRailBackgroundImage(which, '');
  });
});

// «Цвет вкладок» в настройках: пикер → blattam-tab-color (local), live-применение.
const tabColorInput = document.getElementById('tab-color-input');
const tabColorResetBtn = document.getElementById('tab-color-reset');

if (tabColorInput) {
  tabColorInput.addEventListener('input', () => {
    chrome.storage.local.set({ 'blattam-tab-color': tabColorInput.value });
    applyTabCardColor(tabColorInput.value);
  });
}

if (tabColorResetBtn) {
  tabColorResetBtn.addEventListener('click', () => {
    chrome.storage.local.remove('blattam-tab-color');
    applyTabCardColor('');
  });
}
// «Цвета»/«Размер и форма»/«Шрифт» (blattam-custom-theme): live-применение
// saveCustomTheme → storage → ветка applyCustomTheme в onChanged.
CUST_COLORS.forEach((c) => {
  const input = document.getElementById('cust-color-' + c.id);
  if (input) input.addEventListener('input', saveCustomTheme);
});
CUST_GEO.forEach((g) => {
  const input = document.getElementById('cust-geo-' + g.id);
  if (input) input.addEventListener('input', () => {
    const val = document.getElementById('cust-geo-' + g.id + '-val');
    if (val) val.textContent = input.value + 'px';
    saveCustomTheme();
  });
});
function custResetControl(id) {
  const color = CUST_COLORS.find((c) => c.id === id);
  const geo = CUST_GEO.find((g) => g.id === id);
  if (color) {
    const input = document.getElementById('cust-color-' + id);
    if (input) input.value = (custThemeDefault(color.token) || '#ffffff');
  } else if (geo) {
    const input = document.getElementById('cust-geo-' + id);
    const val = document.getElementById('cust-geo-' + id + '-val');
    const def = custThemeDefault(geo.token);
    if (input) input.value = String(parseFloat(def));
    if (val) val.textContent = def;
  }
  saveCustomTheme();
}
document.querySelectorAll('#settings-modal [data-cust-reset]').forEach((btn) => {
  btn.addEventListener('click', () => custResetControl(btn.getAttribute('data-cust-reset')));
});
const custColorsResetAll = document.getElementById('cust-colors-reset-all');
if (custColorsResetAll) custColorsResetAll.addEventListener('click', () => {
  CUST_COLORS.forEach((c) => {
    const input = document.getElementById('cust-color-' + c.id);
    if (input) input.value = (custThemeDefault(c.token) || '#ffffff');
  });
  saveCustomTheme();
});
const custGeoResetAll = document.getElementById('cust-geo-reset-all');
if (custGeoResetAll) custGeoResetAll.addEventListener('click', () => {
  CUST_GEO.forEach((g) => {
    const input = document.getElementById('cust-geo-' + g.id);
    const val = document.getElementById('cust-geo-' + g.id + '-val');
    const def = custThemeDefault(g.token);
    if (input) input.value = String(parseFloat(def));
    if (val) val.textContent = def;
  });
  saveCustomTheme();
});
const custFont = document.getElementById('cust-font');
if (custFont) custFont.addEventListener('change', saveCustomTheme);
// Тумблер «Быстрый поиск» в настройках.
const qsToggle = document.getElementById('qs-toggle');
if (qsToggle) {
  qsToggle.addEventListener('change', () => {
    quickSearchOn = qsToggle.checked;
    chrome.storage.local.set({ 'blattam-quick-search': quickSearchOn });
    if (!quickSearchOn) qsHide();
  });
}

// «О программе»: версия (из манифеста) + «Проверить обновления»
// (кнопка открывает страницу GitHub Releases — обновление ручное, С4.15).
const aboutVersion = document.getElementById('about-version');
const checkUpdateBtn = document.getElementById('check-update-btn');

if (aboutVersion) {
  aboutVersion.textContent = chrome.runtime.getManifest().version;
}

// Версия в левой рейке (#rail-version) — та же динамическая строка из манифеста
const railVersion = document.getElementById('rail-version');
if (railVersion) railVersion.textContent = chrome.runtime.getManifest().version;

// С4.15: автообновление убрано (update_url из манифеста). Кнопка открывает страницу
// Releases — обновление ручное: скачать свежий zip → подменить расширение (Load unpacked).
const RELEASES_URL = 'https://github.com/BlattamRoach/BlatTabs/releases';
if (checkUpdateBtn) {
  checkUpdateBtn.addEventListener('click', () => { openUrl(RELEASES_URL); });
}

// === Открытие вкладок (единый путь: background создаёт browser-tab) ===

// Открыть одну вкладку: background создаёт browser-tab
function openUrl(url) {
  chrome.runtime.sendMessage({ action: 'open-one', url });
  selectedUrls.delete(url);
  renderTabs(searchInput.value);
}

// Массовое открытие: background открывает каждую вкладку (неактивно)
function openMany(urls) {
  chrome.runtime.sendMessage({ action: 'open-many', urls: urls });
  selectedUrls.clear();
  renderTabs(searchInput.value);
}

// === Фавикон на карточке ===
// Буквенный fallback: первая буквенная/цифровая символа домена
// (github.com → 'g'), иначе '?'.
function faviconFallbackChar(url) {
  let host = '';
  try { host = new URL(url).hostname || ''; } catch (err) { host = ''; }
  if (!host && url) host = String(url).replace(/^[a-z]+:\/\/?/i, '').split('/')[0].split(':')[0];
  const m = (host || '').toLowerCase().match(/[a-zа-яё0-9]/);
  return m ? m[0] : '?';
}

// Буквенная монохромная плитка (span.tab-favicon-fallback)
function makeFaviconFallback(tab, letter) {
  const span = document.createElement('span');
  span.className = 'tab-favicon-fallback';
  span.textContent = letter || '?';
  span.title = tab.url || '';
  return span;
}

// Рендерит <img class="tab-favicon"> (если есть favIconUrl) перед именем,
// иначе буквенный fallback. При ошибке загрузки img — меняет его на
// буквенный fallback (однократно, без повторных попыток).
function appendFavicon(nameEl, tab) {
  const letter = faviconFallbackChar(tab.url);
  if (tab.favIconUrl) {
    const img = document.createElement('img');
    img.className = 'tab-favicon';
    img.src = tab.favIconUrl;
    img.alt = '';
    img.draggable = false;
    img.addEventListener('error', () => {
      if (img.parentNode) img.replaceWith(makeFaviconFallback(tab, letter));
    });
    nameEl.insertBefore(img, nameEl.firstChild);
  } else {
    nameEl.insertBefore(makeFaviconFallback(tab, letter), nameEl.firstChild);
  }
}

// === Группы (сворачиваемые секции внутри пространства) ===

function pluralGroups(n) {
  if (I18N_LANG === 'en') return (n === 1) ? t('plural_group') : t('plural_groups_many');
  const a = Math.abs(n) % 100, d = a % 10;
  if (a > 10 && a < 20) return t('plural_groups_many');
  if (d > 1 && d < 5) return t('plural_groups_few');
  if (d === 1) return t('plural_group');
  return t('plural_groups_many');
}

function pluralVkladok(n) {
  if (I18N_LANG === 'en') return (n === 1) ? t('plural_tab') : t('plural_tabs_many');
  const a = Math.abs(n) % 100, d = a % 10;
  if (a > 10 && a < 20) return t('plural_tabs_many');
  if (d > 1 && d < 5) return t('plural_tabs_few');
  if (d === 1) return t('plural_tab');
  return t('plural_tabs_many');
}



// Защита hover-кнопок от drag, «проглотившего» клик: на draggable-родителе
// (шапка группы / карточка) нажатие + движение >~5px запускает drag родителем
// и click по вложенной кнопке теряется (реальный Chrome; синтетический
// .click() это не ловит). Пока мышь нажата на кнопке — снимаем draggable,
// восстанавливаем на mouseup/blur окна (fallback: press, завершённый вне
// окна).
function guardDragOverButtons(parent, selector) {
  parent.addEventListener('mousedown', (e) => {
    const t = e.target;
    if (!(t instanceof Element) || !t.closest(selector)) return;
    parent.draggable = false;
    parent.dataset.pressBtn = '1'; // click-обработчик родителя учитывает
    const restore = () => {
      parent.draggable = true;
      delete parent.dataset.pressBtn;
      window.removeEventListener('mouseup', restore);
      window.removeEventListener('blur', restore);
    };
    window.addEventListener('mouseup', restore);
    window.addEventListener('blur', restore);
  });
}

// Шапка группы «Штрих»: полноширинная (grid-column 1/-1) строка БЕЗ заливки
// — 1px-линия сверху (--line2) + chevron + приглушённое имя (--text-soft, 12px)
// + mono-счётчик + «✕». Всегда видна; клик — свернуть/развернуть (карточки
// уходят из DOM, счётчик на шапке остаётся). Состояние сворачивания — в данных
// (blattam-groups.collapsed), поэтому переживает перерисовку.
function appendGroupBar(g, memberCount) {
  const bar = document.createElement('div');
  bar.className = 'gbar';
  // Свёрнутая группа — полноширинная шапка (gbar-collapsed); развёрнутая —
  // компактная область по ширине содержимого (CSS — view.html, .gbar)
  if (g.collapsed || memberCount === 0) bar.classList.add('gbar-collapsed'); // пустая группа — всегда свёрнутый вид (раскрытие убрано)
  bar.dataset.groupId = g.id;

  const chev = document.createElement('span');
  chev.className = 'chev';
  chev.textContent = (g.collapsed || memberCount === 0) ? '\u25B8' : '\u25BE';

  const name = document.createElement('span');
  name.className = 'gname';
  name.textContent = g.name;

  const count = document.createElement('span');
  count.className = 'gcount';
  count.textContent = memberCount + ' ' + pluralVkladok(memberCount);

  const del = document.createElement('button');
  del.className = 'gdel';
  del.textContent = '\u2715';
  del.title = t('delete_group');
  del.addEventListener('click', (e) => {
    e.stopPropagation();
    if (confirm(t('delete_group_confirm', { name: g.name }))) {
      chrome.runtime.sendMessage({ action: 'delete-group', id: g.id });
    }
  });

  const gUrls = allTabs.filter(t => t.spaceId === g.spaceId && t.groupId === g.id).map(t => t.url);

  // ☑ — выбрать/снять выбор ВСЕХ вкладок группы (hover-контрол; не сворачивает
  // группу и не стартует drag — stopPropagation)
  const gselect = document.createElement('button');
  gselect.className = 'gselect';
  gselect.textContent = '\u2611';
  gselect.title = t('select_group_tabs');
  if (gUrls.length > 0 && gUrls.every(u => selectedUrls.has(u))) gselect.classList.add('on');
  gselect.addEventListener('click', (e) => {
    e.stopPropagation();
    toggleGroupSelection(g);
  });

  // ✎ — инлайн-ренейм группы (hover-контрол, та же идиоматика, что у карточки)
  const grename = document.createElement('button');
  grename.className = 'grename';
  grename.textContent = '\u270E';
  grename.title = t('rename_group');
  grename.addEventListener('click', (e) => {
    e.stopPropagation();
    startGroupRename(g, name);
  });

  bar.appendChild(chev);
  bar.appendChild(name);
  bar.appendChild(count);
  // ⧉ — открыть ВСЕ вкладки группы в новых вкладках браузера (hover-контрол,
  // тот же путь, что клик по карточке — openUrl для каждой вкладки группы)
  const gopenall = document.createElement('button');
  gopenall.className = 'gopenall';
  gopenall.textContent = '\u29C9';
  gopenall.title = t('open_group_tabs');
  gopenall.addEventListener('click', (e) => {
    e.stopPropagation();
    allTabs.filter(t => t.spaceId === g.spaceId && t.groupId === g.id).forEach(t => openUrl(t.url));
  });

  bar.appendChild(gselect);
  bar.appendChild(grename);
  bar.appendChild(del);
  bar.appendChild(gopenall);

  // DnD-источник: шапку можно перетащить на другую шапку (reorder групп
  // внутри пространства). Пейлоад: id группы (у карточки — индекс вкладки).
  bar.draggable = true;
  // Кнопки шапки (☑/✎/✕) не стартуют drag: нажатие на них временно снимает
  // draggable, иначе движение >~5px во время press уносит drag-ом шапку и
  // click по кнопке теряется (реальный Chrome).
  guardDragOverButtons(bar, '.gselect, .grename, .gdel, .gopenall');
  bar.addEventListener('dragstart', (e) => {
    if (!bar.draggable) { e.preventDefault(); return; } // press начался на кнопке
    // Нативный HTML5-драг отменяется, когда press ведёт pointer-путь: свой
    // (gbarPointerPress — ставится на pointerdown pointer-путём шапки, более поздняя волна)
    // или чужой pointer-драг пересекает шапку (pdForeignActive). Синтетическая
    // цепочка харнесса (не-trusted) всегда проходит без изменений
    if (e.isTrusted && (gbarPointerPress || pdForeignActive())) { e.preventDefault(); return; }
    e.dataTransfer.setData('text/plain', g.id);
    e.dataTransfer.effectAllowed = 'move';
    dragSourceGroupId = g.id;
    bar.classList.add('dragging');
  });
  bar.addEventListener('dragend', () => {
    lastDragEndAt = Date.now();
    pendingGbarClickAfterDrag = true;
    dragSourceGroupId = null;
    bar.classList.remove('dragging');
    clearGroupReorderIndicators();
  });

  gpdBindGbar(bar, g);

  // DnD: шапка принимает только другую шапку — reorder групп (2px-индикатор
  // до/после). Карточка, сброшенная на шапку, больше не уходит в группу
  // (свою семантику дропа карточки сохранил только чип пространства)
  bar.addEventListener('dragover', (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (dragSourceGroupId) {
      if (dragSourceGroupId === g.id) return; // на себя — не целевая
      const side = reorderSide(bar, e.clientY);
      bar.classList.toggle('drop-before', side === 'before');
      bar.classList.toggle('drop-after', side === 'after');
      return;
    }
    // Пустая/свёрнутая группа (нет видимых карточек): шапка принимает
    // карточку — тёплый армед-подсвет
    if (dragSourceUrl && !groupVisibleCardCount(g.id)) bar.classList.add('drop-over');
  });
  bar.addEventListener('dragleave', () => bar.classList.remove('drop-over', 'drop-before', 'drop-after'));
  bar.addEventListener('drop', (e) => {
    e.preventDefault();
    bar.classList.remove('drop-over', 'drop-before', 'drop-after');
    // Ложный клик по шапке рождается в этот момент (до dragend источника):
    // вооружаем one-shot-подавление и уводим тёплую заглушку — собственный
    // drop шапки не проходит через глобальный removeGhostSlot
    pendingGbarClickAfterDrag = true;
    removeGhostSlot();
    if (dragSourceGroupId) {
      reorderGroups(dragSourceGroupId, g.id, reorderSide(bar, e.clientY));
      return;
    }
    // Пустая/свёрнутая группа: карточка уходит в группу — в конец списка
    // (anchorIndex null); карточка своей группы — no-op. Выделенный батч —
    // целиком (place-tabs), если хотя бы одна его вкладка не в этой группе.
    if (dragSourceUrl && !groupVisibleCardCount(g.id)) {
      const src = allTabs.find(t => t.url === dragSourceUrl);
      if (!src) return;
      // Свернутая группа: вкладка в неё ушла — разворачиваем (вкладка видна)
      expandGroupForDrop(g.id);
      const batch = dragBatchUrls && dragBatchUrls.length > 1 ? dragBatchUrls : null;
      if (batch) {
        if (batch.some(u => {
          const t = allTabs.find(x => x.url === u);
          return !t || tabGroupOf(t) !== g.id;
        })) {
          chrome.runtime.sendMessage({ action: 'place-tabs', urls: batch,
            anchorUrl: null, side: 'after', groupId: g.id });
        }
      } else if (src.groupId !== g.id) {
        chrome.runtime.sendMessage({ action: 'place-tab', index: allTabs.indexOf(src),
          anchorIndex: null, side: 'after', groupId: g.id });
      }
    }
  });

  bar.addEventListener('click', () => {
    if (bar.dataset.pressBtn) return; // press начался на кнопке и сошёл на шапку — не сворачиваем
    if (pendingGbarClickAfterDrag) {
      // Ложный клик по шапке: браузер генерирует его в момент дропа —
      // до dragend источника, либо позже (медленная перерисовка — за
      // 500ms-окном lastDragEndAt) — гасим ровно один; реальное нажатие
      // сначала прогонит document-mousedown, который сбросит флаг раньше клика
      pendingGbarClickAfterDrag = false;
      return;
    }
    if (Date.now() - lastDragEndAt < 500) return; // backstop: клик сразу после дропа — не сворачиваем
    // Пустая группа не раскрывается (раскрытие пустых групп убрано) — клик no-op
    if (!allTabs.some(t => t.groupId === g.id)) return;
    toggleGroupCollapsed(g.id);
  });
  tabsList.appendChild(bar);
}

// Число ВИДИМЫХ карточек группы в #tabs-list (схваченная во время драга
// остаётся видимой — считается: пока своя карточка в сетке, собственная
// шапка не вооружается; свёрнутая группа — карточек в DOM нет → 0). По нему
// шапка/слот пустой группы принимают карточку.
function groupVisibleCardCount(groupId) {
  return [...document.querySelectorAll('#tabs-list .tab-card')]
    .filter(c => c.style.display !== 'none' && c.__tab && c.__tab.groupId === groupId).length;
}

// Сворачивание группы: запись в blattam-groups → onChanged → перерисовка.
// Пишем только при реальном переключении.
function toggleGroupCollapsed(groupId) {
  const g = allGroups.find(x => x.id === groupId);
  if (!g) return;
  g.collapsed = !g.collapsed;
  chrome.storage.sync.set({ 'blattam-groups': allGroups });
}

// Дроп вкладки В группу: развёртываем Свёрнутую группу, чтобы вставленная
// вкладка была видна (запись blattam-groups → onChanged → перерисовка).
// No-op, если группа не свёрнута (или неизвестна).
function expandGroupForDrop(groupId) {
  if (groupId == null) return;
  const g = allGroups.find(x => x.id === groupId);
  if (g && g.collapsed) {
    g.collapsed = false;
    chrome.storage.sync.set({ 'blattam-groups': allGroups });
  }
}

// ☑ — выбор ВСЕХ вкладок группы (независимо от сворачивания): если все члены
// уже в selectedUrls — снять всех, иначе добавить всех. Выбор завязан на URL,
// переживает перерисовку; перерисовка — с текущим поиском.
function toggleGroupSelection(g) {
  const urls = allTabs.filter(t => t.spaceId === g.spaceId && t.groupId === g.id).map(t => t.url);
  if (urls.length === 0) return;
  const allSelected = urls.every(u => selectedUrls.has(u));
  urls.forEach(u => allSelected ? selectedUrls.delete(u) : selectedUrls.add(u));
  renderTabs(searchInput.value);
}

// ☑ — выбрать/снять выбор ВСЕХ негрупповых вкладок активного пространства
// (секция «Без группы»; как у групп — независимо от поиска). Все члены уже
// выделены — снять всех, иначе — выделить всех.
function toggleLooseSelection() {
  const urls = allTabs.filter(t => t.spaceId === activeSpaceId && isLooseTab(t)).map(t => t.url);
  if (urls.length === 0) return;
  const allSelected = urls.every(u => selectedUrls.has(u));
  urls.forEach(u => allSelected ? selectedUrls.delete(u) : selectedUrls.add(u));
  renderTabs(searchInput.value);
}

// ✎ — инлайн-ренейм группы: <input> на месте .gname. Enter/blur — сохранить
// (пустое/whitespace-имя — старое имя, дубли имён допустимы), Esc — отмена.
// Имя пишется в allGroups + blattam-groups (запись в storage → onChanged).
function startGroupRename(g, nameEl) {
  const input = document.createElement('input');
  input.type = 'text';
  input.className = 'gname-input';
  input.value = g.name;
  input.autocomplete = 'off';
  nameEl.replaceWith(input);
  input.focus();
  input.select();

  let done = false;
  const finish = (save) => {
    if (done) return;
    done = true;
    const newName = input.value.trim();
    if (save && newName && newName !== g.name) {
      g.name = newName;
      chrome.storage.sync.set({ 'blattam-groups': allGroups });
    }
    renderTabs(searchInput.value);
  };

  input.addEventListener('click', (e) => e.stopPropagation());
  input.addEventListener('keydown', (e) => {
    e.stopPropagation();
    if (e.key === 'Enter') finish(true);
    if (e.key === 'Escape') finish(false);
  });
  input.addEventListener('blur', () => finish(true));
}

// Reorder групп: вырезаем группу из глобального allGroups и вставляем
// до/после цели (side — по половине целевой шапки). Группы других
// пространств сохраняют относительный порядок; collapsed/члены остаются
// у группы. Drop on себя — no-op. Запись в blattam-groups → onChanged.
// Возвращает true, если запись ушла (порядок изменился), false — no-op
// (порядок не изменился — записи в storage нет; в реальном Chrome set
// равного значения не шлёт onChanged, поэтому caller, который вырвал DOM
// из потока (pointer-путь), обязан сам перерисовать раскладку).
function reorderGroups(fromId, toId, side) {
  const from = allGroups.findIndex(x => x.id === fromId);
  const to = allGroups.findIndex(x => x.id === toId);
  if (from === -1 || to === -1 || from === to) return false;
  const src = allGroups[from];
  if (src.spaceId !== activeSpaceId) return false;
  // no-op-guard (аналог reorderSpaces): результат сначала на КОПИИ id —
  // если последовательность не изменилась (группа брошена в собственный
  // слот), записи в storage не идёт
  const ids = allGroups.map(x => x.id);
  ids.splice(from, 1);
  let insertAt = ids.indexOf(toId);
  if (side === 'after') insertAt += 1;
  ids.splice(insertAt, 0, fromId);
  if (ids.every((id, i) => id === allGroups[i].id)) return false;
  allGroups.splice(from, 1);
  insertAt = allGroups.findIndex(x => x.id === toId);
  if (side === 'after') insertAt += 1;
  allGroups.splice(insertAt, 0, src);
  chrome.storage.sync.set({ 'blattam-groups': allGroups });
  return true;
}

// Снимаем индикаторы reorder со всех шапок групп
function clearGroupReorderIndicators() {
  document.querySelectorAll('.gbar.drop-before, .gbar.drop-after')
    .forEach(b => b.classList.remove('drop-before', 'drop-after'));
}

// Reorder пространств: вырезаем перетаскиваемое пространство из глобального
// allSpaces и вставляем до/после цели (side — по половине целевого чипа).
// Порядок чипов = порядок массива blattam-spaces. Drop на себя — no-op.
// Активное пространство и blattam-last-space НЕ меняются. Запись в
// blattam-spaces → onChanged → перерисовка чипов.
function reorderSpaces(fromId, toId, side) {
  const from = allSpaces.findIndex(x => x.id === fromId);
  const to = allSpaces.findIndex(x => x.id === toId);
  if (from === -1 || to === -1 || from === to) return;
  const src = allSpaces[from];
  // no-op-guard: результат сначала на КОПИИ — если последовательность id
  // не изменилась (чип брошен в собственный слот), записи в storage не идёт
  // (ни лишняя перерисовка, ни лишнее событие onChanged)
  const reordered = allSpaces.slice();
  reordered.splice(from, 1);
  let insertAt = reordered.findIndex(x => x.id === toId);
  if (side === 'after') insertAt += 1;
  reordered.splice(insertAt, 0, src);
  if (reordered.every((x, i) => x.id === allSpaces[i].id)) return;
  allSpaces.splice(from, 1);
  insertAt = allSpaces.findIndex(x => x.id === toId);
  if (side === 'after') insertAt += 1;
  allSpaces.splice(insertAt, 0, src);
  chrome.storage.sync.set({ 'blattam-spaces': allSpaces });
}

// «Создать группу» — кнопка .rail-item в левой рейке (#create-group-btn —
// ПЕРВАЯ строка #rail-controls): открывает модалку создания группы; работает
// и с пустым пространством. Пустое имя → «Группа N».
// Группа создаётся в активном пространстве.
function createGroupInActiveSpace() {
  modalTitle.textContent = t('new_group');
  spaceNameInput.value = '';
  showSpaceModal(true, (name) => {
    chrome.runtime.sendMessage({ action: 'create-group', spaceId: activeSpaceId, name }, (group) => {
      if (group && group.id) renderTabs(searchInput.value);
    });
  });
}


// === Корзина (blattam-trash, chrome.storage.local) ===
// Удаление вкладки больше не навсегда: вкладка уходит в корзину (массив
// записей = полный объект вкладки + поле deletedAt) и может быть возвращена.
// Confirm при удалении вкладок НЕТ (возврат — через корзину); confirm
// остались только для удаления пространства/группы и безвозвратных
// операций корзины («Удалить навсегда» / «Очистить корзину»).

let trashTabs = []; // записи blattam-trash в памяти (синхронизация — onChanged)

// Прочитать корзину из local: на старте и при открытии модалки (список
// всегда актуален) + обновить счётчик рейки и открытую модалку
function loadTrash() {
  chrome.storage.local.get(['blattam-trash'], (r) => {
    trashTabs = Array.isArray(r['blattam-trash']) ? r['blattam-trash'] : [];
    updateTrashCount();
    if (trashModal && trashModal.classList.contains('open')) renderTrashList();
  });
}

// Отправить вкладки в корзину: убрать из allTabs, дописать записи с
// deletedAt в blattam-trash (дедупликация по url — уже в корзине не
// дублируем), ОДНОЙ записью положить оба ключа в storage, снять выбор
// удалённых, перерисовать сетку. Вызывается из трёх точек удаления:
// ✕ на карточке, «✕ Удалить» (выделенные), клавиша Delete/Backspace.
function sendTabsToTrash(tabs) {
  if (!tabs || tabs.length === 0) return;
  const urls = new Set(tabs.map(t => t.url));
  const now = Date.now();
  const inTrash = new Set(trashTabs.map(x => x.url));
  const seen = new Set();
  for (const t of tabs) {
    if (inTrash.has(t.url) || seen.has(t.url)) continue; // дедупликация по url
    seen.add(t.url);
    const rec = Object.assign({}, t);
    delete rec.deletedAt;
    rec.deletedAt = now;
    trashTabs.push(rec);
  }
  allTabs = allTabs.filter(t => !urls.has(t.url));
  for (const u of selectedUrls) if (urls.has(u)) selectedUrls.delete(u);
  chrome.storage.local.set({ 'blattam-tabs': allTabs, 'blattam-trash': trashTabs });
  // onChanged (blattam-trash) обновит счётчик/модалку; сетку рендерим сразу
  renderTabs(searchInput.value);
}

// Вернуть вкладки из корзины: поле deletedAt удаляется, объект возвращается
// в blattam-tabs (spaceId/groupId сохраняются; если пространство/группы
// больше нет — вкладка возвращается как «свежая»: в первое пространство,
// без группы — как при обычном добавлении)
function restoreFromTrash(records) {
  if (!records || records.length === 0) return;
  const urls = new Set(records.map(r => r.url));
  const restored = records.map(r => {
    const rec = Object.assign({}, r);
    delete rec.deletedAt;
    if (!allSpaces.some(s => s.id === rec.spaceId)) {
      rec.spaceId = allSpaces.length ? allSpaces[0].id : undefined;
    }
    if (rec.groupId != null && !allGroups.some(g => g.id === rec.groupId)) rec.groupId = null;
    return rec;
  });
  trashTabs = trashTabs.filter(x => !urls.has(x.url));
  allTabs = allTabs.filter(t => !urls.has(t.url)); // страховка от дублей по url
  allTabs = allTabs.concat(restored);
  chrome.storage.local.set({ 'blattam-tabs': allTabs, 'blattam-trash': trashTabs });
  if (trashModal && trashModal.classList.contains('open')) renderTrashList();
}

// «Удалить навсегда»: убрать записи из корзины (безвозвратно). Вызывается
// только после confirm (одна запись — trash_permanent_confirm, все —
// trash_clear_confirm)
function deleteFromTrash(records) {
  if (!records || records.length === 0) return;
  const urls = new Set(records.map(r => r.url));
  trashTabs = trashTabs.filter(x => !urls.has(x.url));
  chrome.storage.local.set({ 'blattam-trash': trashTabs });
  if (trashModal && trashModal.classList.contains('open')) renderTrashList();
}

// === Модалка: корзина (удалённые вкладки) ===
// Открытие — кнопка «Корзина» в левой рейке (#trash-btn). Закрытие — ✕,
// клик по затемнённому фону (как у модалки пространств) и Escape.
// setModalOpen('trash') делает isAnyModalOpen() истинным, поэтому глобальный
// keydown не перехватывает клавиши, пока модалка открыта.
const trashModal = document.getElementById('trash-modal');
const trashCloseBtn = document.getElementById('trash-close');
const trashBtn = document.getElementById('trash-btn');
const trashList = document.getElementById('trash-list');
const trashEmpty = document.getElementById('trash-empty');
const trashRestoreAllBtn = document.getElementById('trash-restore-all');
const trashClearBtn = document.getElementById('trash-clear');

// Счётчик в подписи кнопки рейки: 0 → «Удалённые вкладки» (trash_sub),
// N>0 → «N в корзине» (trash_count_sub). Вызывается на старте, в
// renderTabs, по onChanged blattam-trash и после операций корзины.
function updateTrashCount() {
  const sub = trashBtn && trashBtn.querySelector('.s');
  if (!sub) return;
  sub.textContent = trashTabs.length === 0 ? t('trash_sub') : t('trash_count_sub', { n: trashTabs.length });
}

// Дата удаления: «20 ноя, 17:22» (Intl.DateTimeFormat, ru-RU / en-US
// по текущему языку)
function formatTrashDate(ts) {
  try {
    const dtf = new Intl.DateTimeFormat(I18N_LANG === 'en' ? 'en-US' : 'ru-RU',
      { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
    return dtf.format(new Date(ts));
  } catch (err) {
    return String(ts);
  }
}

// Рендер списка корзины: строка .trash-row = имя + url (truncate по CSS)
// + дата удаления + «Вернуть» + «Удалить навсегда» (confirm)
function renderTrashList() {
  if (!trashList) return;
  trashList.innerHTML = '';
  const empty = trashTabs.length === 0;
  if (trashEmpty) trashEmpty.style.display = empty ? '' : 'none';
  trashList.style.display = empty ? 'none' : '';
  for (const rec of trashTabs) {
    const row = document.createElement('div');
    row.className = 'trash-row';

    const favEl = document.createElement('span');
    favEl.className = 'trash-row-fav';
    const favLetter = (rec.name || rec.url || '?').trim().charAt(0).toUpperCase();
    if (rec.favIconUrl) {
      const img = document.createElement('img');
      img.src = rec.favIconUrl;
      img.alt = '';
      img.addEventListener('error', () => {
        const fb = document.createElement('span');
        fb.className = 'trash-row-fav-fallback';
        fb.textContent = favLetter;
        favEl.replaceChildren(fb);
      });
      favEl.appendChild(img);
    } else {
      const fb = document.createElement('span');
      fb.className = 'trash-row-fav-fallback';
      fb.textContent = favLetter;
      favEl.appendChild(fb);
    }

    const main = document.createElement('div');
    main.className = 'trash-row-main';
    const nameEl = document.createElement('span');
    nameEl.className = 'trash-row-name';
    nameEl.textContent = rec.name || rec.url || t('untitled');
    nameEl.title = rec.url || '';
    const urlEl = document.createElement('span');
    urlEl.className = 'trash-row-url';
    urlEl.textContent = rec.url || '';
    main.appendChild(nameEl);
    main.appendChild(urlEl);

    const dateEl = document.createElement('span');
    dateEl.className = 'trash-row-date';
    dateEl.textContent = t('trash_deleted_on', { when: formatTrashDate(rec.deletedAt) });

    const restoreBtn = document.createElement('button');
    restoreBtn.className = 'modal-btn primary';
    restoreBtn.textContent = t('trash_restore');
    restoreBtn.addEventListener('click', () => restoreFromTrash([rec]));

    const permBtn = document.createElement('button');
    permBtn.className = 'modal-btn ghost';
    permBtn.textContent = t('trash_permanent');
    permBtn.addEventListener('click', () => {
      if (confirm(t('trash_permanent_confirm', { name: rec.name || rec.url }))) {
        deleteFromTrash([rec]);
      }
    });

    row.appendChild(favEl);
    row.appendChild(main);
    row.appendChild(dateEl);
    row.appendChild(restoreBtn);
    row.appendChild(permBtn);
    trashList.appendChild(row);
  }
}

function openTrashModal() {
  if (!trashModal) return;
  trashModal.classList.add('open');
  setModalOpen('trash');
  loadTrash(); // список актуален в момент открытия
}

function closeTrashModal() {
  if (trashModal) trashModal.classList.remove('open');
  setModalOpen(null);
}

if (trashBtn) trashBtn.addEventListener('click', openTrashModal);
if (trashCloseBtn) trashCloseBtn.addEventListener('click', closeTrashModal);
if (trashModal) {
  trashModal.addEventListener('click', (e) => {
    if (e.target === trashModal) closeTrashModal();
  });
  // Escape — закрыть (отдельный слушатель: глобальный keydown байлит при открытой модалке)
  document.addEventListener('keydown', (e) => {
    if (trashModal.classList.contains('open') && e.key === 'Escape') closeTrashModal();
  });
}

// «Вернуть все» — без confirm, все записи обратно в blattam-tabs
if (trashRestoreAllBtn) trashRestoreAllBtn.addEventListener('click', () => {
  restoreFromTrash(trashTabs.slice());
});
// «Очистить корзину» — confirm trash_clear_confirm; пустая корзина — no-op
if (trashClearBtn) trashClearBtn.addEventListener('click', () => {
  if (trashTabs.length === 0) return;
  if (confirm(t('trash_clear_confirm', { n: trashTabs.length }))) {
    deleteFromTrash(trashTabs.slice());
  }
});

// === Карточки вкладок ===

// Переместить вкладку: spaceId (в новое пространство, groupId очищается)
// и/или groupId (null — «Без группы»). Индекс — по полному массиву.
function moveTabTo(tab, spaceId, groupId) {
  const idx = allTabs.indexOf(tab);
  if (idx === -1) return;
  const msg = { action: 'move-tab', index: idx };
  if (spaceId !== undefined) msg.spaceId = spaceId;
  if (groupId !== undefined) msg.groupId = groupId;
  chrome.runtime.sendMessage(msg);
}

// Строит карточку вкладки (вызывается для членов групп и негрупповых вкладок)
function appendCard(tab) {
  const card = document.createElement('div');
  card.className = 'tab-card'
    + (selectedUrls.has(tab.url) ? ' selected' : '')
    + (activeUrl === tab.url ? ' kbd-active' : '');
  card.__tab = tab; // ссылка на данные (секционно-чуткий расчёт слота при DnD)

  // Чекбокс массового выбора (hover-контрол, сверху-слева)
  const selectCb = document.createElement('input');
  selectCb.type = 'checkbox';
  selectCb.className = 'tab-select';
  selectCb.checked = selectedUrls.has(tab.url);
  selectCb.title = t('select_bulk');
  selectCb.addEventListener('click', (e) => {
    e.stopPropagation();
    if (selectCb.checked) selectedUrls.add(tab.url);
    else selectedUrls.delete(tab.url);
    card.classList.toggle('selected', selectCb.checked);
    updateSelectionBar();
  });

  // Кнопка удаления (hover-контрол, сверху-справа)
  const deleteBtn = document.createElement('button');
  deleteBtn.className = 'icon-btn tab-remove delete';
  deleteBtn.title = t('delete');
  deleteBtn.textContent = '\u2715';
  deleteBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    // Без confirm: вкладка уходит в корзину (blattam-trash) — можно вернуть
    sendTabsToTrash([tab]);
  });

  // Кнопка редактирования (hover-контрол, снизу-справа) — клик СРАЗУ открывает
  // модалку редактирования (промежуточное меню «Изменить» убрано).
  const editBtn = document.createElement('button');
  editBtn.className = 'tab-edit';
  editBtn.title = t('edit_tab_title');
  editBtn.textContent = '\u270E';
  editBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    openEditTabModal(tab);
  });

  // Hover-контролы — absolute, привязаны к карточке
  card.appendChild(selectCb);
  card.appendChild(deleteBtn);
  card.appendChild(editBtn);

  // Тело: имя + URL
  const body = document.createElement('div');
  body.className = 'cbody';

  const nameEl = document.createElement('div');
  nameEl.className = 'cname';
  const nameText = document.createElement('span');
  nameText.className = 'tab-name';
  nameText.textContent = tab.name;
  nameText.title = t('dblclick_rename');
  nameEl.appendChild(nameText);

  // Фавикон (или буквенный fallback) — перед именем
  appendFavicon(nameEl, tab);

  // Двойной клик по имени → инлайн-редактирование.
  // Одиночный клик по имени открывает вкладку, но с задержкой 300мс,
  // чтобы dblclick успел отменить его.
  let nameClickTimer = null;
  let nameClicks = 0;
  nameEl.addEventListener('click', (e) => {
    e.stopPropagation();
    nameClicks++;
    if (nameClicks === 1) {
      nameClickTimer = setTimeout(() => {
        nameClicks = 0;
        nameClickTimer = null;
        openUrl(tab.url);
      }, 300);
    }
  });
  nameEl.addEventListener('dblclick', (e) => {
    e.stopPropagation();
    if (nameClickTimer) { clearTimeout(nameClickTimer); nameClickTimer = null; }
    nameClicks = 0;
    startRename(tab, nameText, body);
  });

  body.appendChild(nameEl);
  card.appendChild(body);

  // Комментарий (если задан) — внизу внутри карточки, моно, обрезается
  if (tab.comment) {
    const commentEl = document.createElement('div');
    commentEl.className = 'tab-comment';
    commentEl.textContent = tab.comment;
    commentEl.title = tab.comment;
    card.appendChild(commentEl);
  }

  // Клик по карточке — открыть вкладку + снять выбор
  card.addEventListener('click', () => {
    if (card.dataset.pressBtn) return; // press начался на чекбоксе/✕ — не открываем
    // Ложный post-drop-клик (без mousedown) рождается в момент дропа —
    // гасим ровно один; настоящее нажатие сначала прогонит mousedown
    if (pendingCardClickAfterDrag) { pendingCardClickAfterDrag = false; return; }
    openUrl(tab.url);
  });

  // Средний клик (колесо) — открыть сайт новой ФОНОВОЙ вкладкой
  // (chrome.tabs.create, active:false) и остаться на странице плагина:
  // mousedown гасит autoscroll браузера (preventDefault), auxclick (button 1)
  // — фоновое открытие (тот же путь, что дроп карточки на правую рейку).
  // Hover-кнопки (чекбокс/✕/✎) своё поведение сохраняют.
  card.addEventListener('mousedown', (e) => {
    if (e.button === 1) e.preventDefault();
  });
  card.addEventListener('auxclick', (e) => {
    if (e.button !== 1) return;
    if (pdInteractiveTarget(e.target)) return; // чекбокс/✕/✎ держат своё
    e.preventDefault();
    openSavedUrlsInBackground([tab.url]);
  });

  // Drag & drop: карточку можно перетащить на чип пространства (переместить)
  // или в зазор между карточками (reorder — глобальные обработчики ниже)
  card.draggable = true;
  // Hover-кнопки (чекбокс/✕/✎) не стартуют drag — то же, что у шапки группы.
  guardDragOverButtons(card, '.tab-select, .tab-remove, .tab-edit');
  card.addEventListener('dragstart', (e) => {
    if (!card.draggable) { e.preventDefault(); return; } // press начался на кнопке
    // Нативный HTML5-драг заменён pointer-системой (см. «Pointer drag» ниже):
    // preventDefault отменяет нативный drag-образ и всю нативную ленту
    // dragover/drop/dragend в реальном Chrome. Синтетическая диспетч-цепочка
    // DragEvent (тест-харнесс) проходит через этот же обработчик и работает
    // без изменений.
    e.preventDefault();
    if (e.isTrusted) return; // trusted dragstart — нативный HTML5-драг отменён preventDefault,
    // цикл ведёт pointer-путь (см. «Pointer drag»); синтетический dragstart харнесса идёт дальше
    e.dataTransfer.setData('text/plain', String(allTabs.indexOf(tab)));
    e.dataTransfer.effectAllowed = 'move';
    beginCardDrag(tab, card);
  });
  card.addEventListener('dragend', () => endCardDrag(card));
  pdBindCard(card, tab); // pointer-путь (реальный Chrome) — см. «Pointer drag»

  tabsList.appendChild(card);
}

// Вкладки активного пространства
function spaceTabs() {
  return allTabs.filter(t => t.spaceId === activeSpaceId);
}

// Группы активного пространства (порядок = порядок в blattam-groups)
function spaceGroups() {
  return allGroups.filter(g => g.spaceId === activeSpaceId);
}

// Негрупповая вкладка: groupId отсутствует/пуст, или группы с таким id
// нет в активном пространстве (ветхий groupId)
function isLooseTab(t) {
  if (!t.groupId) return true;
  return !spaceGroups().some(g => g.id === t.groupId);
}

// Текущие видимые карточки активного пространства, в порядке рендера:
// группы по порядку (свёрнутые — вне DOM, их члены пропускаются), затем
// негрупповые. Поиск фильтрует по имени/title/URL.
function visibleTabs(filter = '') {
  const sTabs = spaceTabs();
  const match = (t) => !filter || matchFilter(t, filter);
  const result = [];
  spaceGroups().forEach(g => {
    if (g.collapsed) return;
    sTabs.filter(t => t.groupId === g.id && match(t)).forEach(t => result.push(t));
  });
  sTabs.filter(t => isLooseTab(t) && match(t)).forEach(t => result.push(t));
  return result;
}

function renderTabs(filter = '') {
  tabsList.innerHTML = '';
  // Счётчик корзины в подписи рейки (не зависит от списка — все ветки)
  updateTrashCount();
  // Перерисовка во время перетаскивания уносит заглушку (и заменяет карточку) —
  // сбрасываем ссылку, чтобы ghost-slot не «воскрес» после dragend
  if (dragGhostSlot && !dragGhostSlot.isConnected) dragGhostSlot = null;
  if (dragWrapHiddenCard && !dragWrapHiddenCard.isConnected) { dragWrapHiddenCard = null; dragWrapHiddenGroup = null; }
  // Холдеры последней строки (row-keeper) унесены с DOM — сбрасываем трекер,
  // чтобы следующий dragover драга прицепил их заново
  dragRowKeepers.forEach(k => { if (k.isConnected) k.remove(); });
  dragRowKeepers = [];
  dragRowKeeperSection = null;

  const sTabs = spaceTabs();
  const sGroups = spaceGroups();

  // Если активная (клавиатурная) карточка не в видимом списке — сбрасываем
  const visible = visibleTabs(filter);
  if (activeUrl && !visible.some(t => t.url === activeUrl)) activeUrl = null;

  metaLabel.textContent = spaceLabel();

  if (sTabs.length === 0) {
    if (sGroups.length > 0) {
      // Пространство без вкладок, но с группами — не «пусто»: показываем
      // пустые группы (счётчик «0 вкладок»)
      emptyState.style.display = 'none';
      sGroups.forEach(g => {
        appendGroupBar(g, 0);
      });
      noResults.style.display = 'none';
      metaCount.textContent = '0';
    } else {
      emptyState.style.display = 'block';
      noResults.style.display = 'none';
      metaCount.textContent = '0';
    }
    updateSelectionBar();
    return;
  }
  emptyState.style.display = 'none';

  let visibleCount = 0;

  // Секции групп (порядок = порядок в массиве)
  sGroups.forEach(g => {
    const members = sTabs.filter(t => t.groupId === g.id);
    appendGroupBar(g, members.length);
    if (!g.collapsed) {
      members.forEach(t => {
        if (filter && !matchFilter(t, filter)) return;
        appendCard(t);
        visibleCount++;
      });
    }
  });

  // Негрупповые вкладки — после всех групп (с подписью, если есть группы)
  const loose = sTabs.filter(t => isLooseTab(t) && (!filter || matchFilter(t, filter)));
  if (sGroups.length > 0 && loose.length > 0) {
    const lbl = document.createElement('div');
    lbl.className = 'loose-label';

    const lname = document.createElement('span');
    lname.className = 'loose-name';
    lname.textContent = t('ungrouped');
    lbl.appendChild(lname);

    // ☑ — выбрать/снять выбор ВСЕХ негрупповых вкладок пространства
    // (аналог ☑ шапки группы; проверяет ПОЛНЫЙ набор, а не видимые)
    const looseAllUrls = sTabs.filter(t => isLooseTab(t)).map(t => t.url);
    const lselect = document.createElement('button');
    lselect.className = 'loose-select';
    lselect.textContent = '\u2611';
    lselect.title = t('select_ungrouped');
    if (looseAllUrls.length > 0 && looseAllUrls.every(u => selectedUrls.has(u))) lselect.classList.add('on');
    lselect.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleLooseSelection();
    });
    lbl.appendChild(lselect);
    tabsList.appendChild(lbl);
  }
  loose.forEach(t => {
    appendCard(t);
    visibleCount++;
  });

  // «Ничего не найдено» — только при активном поиске: сворачивание групп
  // (visibleCount === 0 без фильтра) его не показывает
  noResults.style.display = (visibleCount === 0 && filter) ? 'block' : 'none';
  metaCount.textContent = String(visibleCount);
  updateSelectionBar();
  // Активная карточка видна на экране
  if (activeUrl) {
    const activeCard = tabsList.querySelector('.tab-card.kbd-active');
    if (activeCard) activeCard.scrollIntoView({ block: 'nearest' });
  }
}

function matchFilter(tab, filter) {
  const f = filter.toLowerCase();
  return (tab.name || '').toLowerCase().includes(f) ||
         (tab.title || '').toLowerCase().includes(f) ||
         (tab.url || '').toLowerCase().includes(f);
}

// === Drag & drop: перетаскивание карточки on чип пространства ===

// Чип принимает карточку (перетаскиваемая шапка группы — no-op) и принимает
// чип-реorder: тёплая заглушка чипа .space-ghost-slot — как ghost-slot карточек.
// Исходный чип скрыт (display:none), заглушка ходит за курсором в ряду:
// левая половина целевого чипа — заглушка перед целью, правая — после
// (reorderSideX). 2px-линия на кромке цели убрана — боковых классов на чипах
// при drag чипа нет; единственный индикатор — заглушка. Семантика дропа
// карточки не тронута.
function attachSpaceDrop(chip, spaceId) {
  chip.addEventListener('dragover', (e) => {
    if (dragSourceSpaceId) {
      if (dragSourceSpaceId === spaceId) return; // на себя — не цель
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      const side = reorderSideX(chip, e.clientX);
      dragOverChipTarget = chip;
      dragOverChipSide = side;
      moveSpaceGhostSlot({ el: chip, side: side });
      return;
    }
    if (dragSourceGroupId) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    chip.classList.add('drag-over');
  });
  chip.addEventListener('dragleave', () => chip.classList.remove('drag-over'));
  chip.addEventListener('drop', (e) => {
    e.preventDefault();
    chip.classList.remove('drag-over');
    if (dragSourceSpaceId) {
      // Ложный клик по цели генерируется в этот момент (до dragend источника):
      // вооружаем one-shot-подавление; chip-заглушка снимается СОБСТВЕННЫМ
      // drop-хендлером (drop чипа не проходит через глобальный document drop),
      // затем reorder
      pendingChipClickAfterDrag = true;
      removeSpaceGhostSlot();
      e.stopPropagation(); // дроп по чипу закоммичен здесь — хендлер ряда
                           // #space-chips не должен коммитить повторно
      reorderSpaces(dragSourceSpaceId, spaceId, reorderSideX(chip, e.clientX));
      return;
    }
    if (dragSourceGroupId) return;
    const batch = dragBatchUrls;
    if (batch && batch.length > 1) {
      // Выделенный батч: уезжают все выделенные вкладки (в пространство, без группы)
      for (const u of batch) {
        const tab = allTabs.find(t => t.url === u);
        if (tab) moveTabTo(tab, spaceId, undefined);
      }
      return;
    }
    const idx = parseInt(e.dataTransfer.getData('text/plain'), 10);
    const tab = allTabs[idx];
    if (tab) moveTabTo(tab, spaceId, undefined);
  });
}

// === Drag & drop: перестановка карточек (reorder), BlatTabs-style ===
// Забрали карточку: оригинал исчезает из слота (на его месте — ghost-slot: тёплая пустая
// заглушка размера карточки); нативный drag-образ браузера следует за курсором, клон-призрака нет.
// Заглушка — ЕДИНСТВЕННЫЙ индикатор вставки (2px-линия убрана): она ходит за
// курсором с учётом секций (группы / «Без группы») — встаёт перед карточкой,
// после последней, ДО шапки секции (конец предыдущей) или ПОСЛЕ шапки
// (начало секции). Дроп ставит вкладку в ПОЛНОМ allTabs на позицию заглушки
// (работает под любым фильтром) и задаёт groupId секции заглушки
// (null — «Без группы»); spaceId не меняется. Свою семантику дропа карточки
// сохранил только чип пространства (над ним и над шапкой группы заглушка
// просто стоит до drop/dragend); шапка группы — только reorder групп.

// Ghost-slot: пустая заглушка размера карточки (без текста) — занимает слот
// карточки в сетке; тон — тёплые токены --ghost-bg/--ghost-ring (фон) и
// пунктирный --ghost-ring (контур).
// pointer-events:none — курсор «видит сквозь» заглушку (gap-индекс не дёргается,
// дроп падает на сам список). Инлайн: в тестах <head>-стили view.html не грузятся.
function makeGhostSlot(card) {
  const slot = document.createElement('div');
  slot.className = 'tab-ghost-slot';
  slot.draggable = false;
  slot.style.cssText =
    'pointer-events:none;box-sizing:border-box;background:var(--ghost-bg);' +
    'border-width:1px;border-style:dashed;border-color:var(--ghost-ring);' +
    'border-radius:' + (getComputedStyle(card).borderRadius || '0px');
  slot.style.width = card.offsetWidth + 'px';
  slot.style.height = card.offsetHeight + 'px';
  return slot;
}

// Row keeper УБРАН: схваченная карточка скрыта инлайновым display:none, но
// тёплая заглушка (тот же размер, сразу после карточки) занимает её слот — при
// захвате рефлоу нет; когда заглушка уезжает от дома, соседи закрывают
// высвобожденный слот естественным reflow сетки (FLIP-слайд на pointer-пути).

// Переносит заглушку в потенциальный слот вставки: anchor — {el, side} из
// slotAnchor(); соседи сдвигаются естественным reflow сетки. Своя (отложенная)
// точка создания — в dragstart; перерисовка во время перетаскивания уносит
// заглушку из DOM — в этом случае её не воссоздаём (drag продолжится без
// заглушки, дроп всё равно сработает).
function moveGhostSlot(anchor) {
  if (!dragSourceUrl || !anchor || !anchor.el) return;
  if (!dragGhostSlot) return;
  if (!dragGhostSlot.isConnected) { dragGhostSlot = null; return; }
  if (anchor.side === 'before') anchor.el.before(dragGhostSlot);
  else anchor.el.after(dragGhostSlot);
}

function removeGhostSlot() {
  if (dragGhostSlot && dragGhostSlot.isConnected) dragGhostSlot.remove();
  dragGhostSlot = null;
}

// Ghost-slot чипа: тёплая заглушка размера чипа (высота 26px, радиус чипа)
// в ряду #space-chips — ЕДИНСТВЕННЫЙ индикатор вставки при reorder чипов
// (2px-линия убрана), тон и механика — как у ghost-slot карточек:
// фон --ghost-bg, пунктирный контур --ghost-ring. Инлайн-стили — в тестах
// head-стили view.html не грузятся. pointer-events:none — курсор «видит
// сквозь» заглушку (dragover падает на чипы; ряд reflow'ится естественно).
function makeSpaceGhostSlot(chip) {
  const slot = document.createElement('div');
  slot.className = 'space-ghost-slot';
  slot.draggable = false;
  slot.style.cssText =
    'pointer-events:none;box-sizing:border-box;flex:none;background:var(--ghost-bg);' +
    'border-width:1px;border-style:dashed;border-color:var(--ghost-ring);' +
    'border-radius:' + (getComputedStyle(chip).borderRadius || '9999px');
  slot.style.width = chip.offsetWidth + 'px';
  slot.style.height = chip.offsetHeight + 'px';
  return slot;
}

// Переносит chip-заглушку в потенциальный слот вставки ряда: левая половина
// целевого чипа — перед ним, правая — после; соседи сдвигаются естественным
// reflow flex-ряда (заглушка занимает один слот вместо скрытого чипа —
// число элементов ряда не меняется, хвост не дёргается).
function moveSpaceGhostSlot(anchor) {
  if (!dragSourceSpaceId || !anchor || !anchor.el) return;
  if (!dragGhostChipSlot) return;
  if (!dragGhostChipSlot.isConnected) { dragGhostChipSlot = null; return; }
  if (anchor.side === 'before') anchor.el.before(dragGhostChipSlot);
  else anchor.el.after(dragGhostChipSlot);
}

function removeSpaceGhostSlot() {
  if (dragGhostChipSlot && dragGhostChipSlot.isConnected) dragGhostChipSlot.remove();
  dragGhostChipSlot = null;
}

// Ряд пространств (#spaces-bar: span #space-chips display:contents +
// кнопка «+ Пространство» — последний элемент ряда) — цель дропа В ЛЮБОМ
// месте ряда (зазор между чипами, отступы ряда, кнопка «+ Пространство»):
// заглушка чипа pointer-events:none, поэтому дроп по заглушке/фону ряда
// промахивался мимо хендлеров чипов — dragend без дропа, чип возвращался
// домой без reorder. Как у дропа карточек (коммит в любом месте списка):
// позиция дропа = ТЕКУЩАЯ DOM-позиция заглушки (соседние .space-chip;
// кнопка «+ Пространство»/null — не цель). Drag карточки/шапки группы —
// не трогаем (dragSourceSpaceId пуст — без preventDefault, поведение
// byte-for-byte).
spacesBar.addEventListener('dragover', (e) => {
  if (!dragSourceSpaceId) return;
  e.preventDefault();
  e.dataTransfer.dropEffect = 'move';
  // заглушка остаётся на последнем слоте (dragover чипов её и ставят)
});

spacesBar.addEventListener('drop', (e) => {
  if (!dragSourceSpaceId) return;
  e.preventDefault();
  e.stopPropagation(); // дроп по самому чипу уже закоммичен хендлером чипа
  const slot = dragGhostChipSlot;
  if (slot && slot.isConnected) {
    const next = slot.nextElementSibling;
    const prev = slot.previousElementSibling;
    if (next && next.classList.contains('space-chip')) {
      reorderSpaces(dragSourceSpaceId, next.dataset.spaceId, 'before');
    } else if (prev && prev.classList.contains('space-chip')) {
      reorderSpaces(dragSourceSpaceId, prev.dataset.spaceId, 'after');
    }
    // заглушка не у чипов (ряд пуст / заглушка вне ряда) — no-op
  }
  // заглушки нет (крайне короткий драг) — no-op: дроп по чипу закрывает
  // собственным хендлером чипа
  removeSpaceGhostSlot();
});

// (Row keeper и ghostDomSection убраны: схваченная карточка остаётся
// видимой — держит слот и число строк секции; тёплая заглушка её размера
// сразу после неё — индикатор слота вставки.)

// Видимые карточки для расчёта зазора: перетаскиваемая карточка исключается
// (по флагу — во время драга она остаётся видимой), индекс зазора считается по
// карточкам, которые курсор «обогнал» (собственный слот карточки в счёт не идёт)
function visibleCards() {
  return [...document.querySelectorAll('#tabs-list .tab-card')]
    .filter(c => c !== dragSourceCardEl && c.style.display !== 'none');
}

// Gap index = the card the cursor is directly over (the ghost takes its place);
// if the cursor is over no card, fall back to how many visible cards it has
// "passed" (a card is passed when cursor Y is below its bottom, or cursor is on
// the card's row and right of its horizontal center)
function cardGapIndex(clientX, clientY) {
  const cards = visibleCards();
  // Cursor-oriented: the ghost takes the place of the card under the cursor, so
  // neighbors only reflow when the cursor touches a new card.
  for (let i = 0; i < cards.length; i++) {
    const r = cards[i].getBoundingClientRect();
    if (clientX >= r.left && clientX <= r.right && clientY >= r.top && clientY <= r.bottom) return i;
  }
  // Not over a card (grid background, e.g. empty cells right of a partial row):
  // keep the previous "cards passed" count so row/section ends stay reachable.
  let idx = 0;
  for (const c of cards) {
    const r = c.getBoundingClientRect();
    const onRow = clientY >= r.top && clientY <= r.bottom;
    if (clientY > r.bottom || (onRow && clientX > r.left + r.width / 2)) idx++;
  }
  return idx;
}

// Секция вкладки по данным: groupId или null (негрупповая)
function tabGroupOf(t) {
  return t && t.groupId ? t.groupId : null;
}

// Шапка секции, стоящая перед карточкой в списке: .gbar (группа) или
// .loose-label (негрупповая секция); null — карточка в начале списка
function sectionHeaderBefore(card) {
  let el = card.previousElementSibling;
  while (el && !el.classList.contains('gbar') && !el.classList.contains('loose-label'))
    el = el.previousElementSibling;
  return el;
}

// Секция секционной шапки: .gbar — её groupId; .loose-label — null
function headerSection(header) {
  return header && header.classList.contains('gbar') ? (header.dataset.groupId || null) : null;
}

// Слот самой исходной карточки (домой): в исходной секции НЕТ других видимых
// карточек (схваченная исключена из visibleCards — секция читается «пустой»),
// а курсор в полосе исходной секции (от низа её шапки до верха шапки
// следующей секции). Без проверки геометрия прыгает через полосу исходной
// секции в соседнюю — заглушка уезжает, и единственную вкладку нельзя
// вернуть на место.
function slotIsSourceHome(clientY) {
  const card = dragSourceCardEl;
  if (!card || !card.isConnected) return false;
  const srcGroup = tabGroupOf(card.__tab);
  for (const c of visibleCards())
    if (tabGroupOf(c.__tab) === srcGroup) return false;
  const header = sectionHeaderBefore(card);
  let n = card.nextElementSibling;
  while (n && !n.classList.contains('gbar') && !n.classList.contains('loose-label'))
    n = n.nextElementSibling;
  const top = header ? layoutRect(header).bottom : 0;
  const bottom = n ? layoutRect(n).top : Infinity;
  return clientY != null && clientY >= top && clientY < bottom;
}

// Позиция заглушки с учётом секций: плоский gap-индекс + Y курсора →
// {el, side}. На границе секций (карточка — первая своей секции, перед ней
// шапка): курсор НИЖЕ середины шапки — начало этой секции (заглушка после
// шапки), ВЫШЕ — конец предыдущей (заглушка до шапки). Остальные позиции —
// перед карточкой / после последней видимой.
function slotAnchor(idx, clientY) {
  const cards = visibleCards();
  if (!cards.length) return null;
  // Домашний слот исходной карточки: заглушка остаётся в слоте схваченной
  // карточки, пока курсор в полосе исходной секции (дроп туда — no-op)
  if (slotIsSourceHome(clientY)) return { el: dragSourceCardEl, side: 'after' };
  if (idx <= 0) return { el: cards[0], side: 'before' };
  if (idx >= cards.length) return { el: cards[cards.length - 1], side: 'after' };
  const card = cards[idx];
  const header = sectionHeaderBefore(card);
  if (header && tabGroupOf(card.__tab) !== tabGroupOf(cards[idx - 1].__tab)) {
    const r = header.getBoundingClientRect();
    const below = clientY == null || clientY > r.top + r.height / 2;
    if (below) return { el: header, side: 'after' };
    // «до» целевой шапки — в конец ПРЕДЫДУЩЕЙ секции (после её последней видимой
    // карточки), а не перед шапкой: между секциями могут стоять свёрнутые группы,
    // и перед шапкой заглушка встала бы в пространство НИЗКОЙ свёрнутой группы
    // (она «раскрывается» с призрачной вкладкой)
    return { el: cards[idx - 1], side: 'after' };
  }
  return { el: card, side: 'before' };
}

// Layout-rect = rect МИНус in-flight FLIP-transform (то же вычитание
// matrix(tx, ty), что и в applyFlipFrom): геометрия территорий (строки,
// midpoint-tiling, touch-rect) должна быть детерминированной относительно
// DOM-порядка + grid-layout и НЕ зависеть от состояния анимации — иначе
// событие, прилетевшее во время 200ms-слайда, резолвит WRONG-owner
// (mid-flight rect сдвинут до полуклетки), и freeze защёлкивает чужой
// anchor (осцилляция между соседними вкладками: чем больше возишь, тем
// хуже). Элемент без transform (ghost-slot, шапки, #tabs-list) — no-op.
function layoutRect(el) {
  const r = el.getBoundingClientRect();
  const cs = getComputedStyle(el).transform;
  if (cs && cs !== 'none') {
    const m = cs.match(/matrix\(([^)]+)\)/);
    if (m) {
      const p = m[1].split(',');
      const tx = parseFloat(p[4]) || 0;
      const ty = parseFloat(p[5]) || 0;
      return { left: r.left - tx, right: r.right - tx, top: r.top - ty,
               bottom: r.bottom - ty, width: r.width, height: r.height };
    }
  }
  return r;
}

// Territory-oriented anchor, CARD path only (dragSourceUrl set, no group
// drag). A card's TERRITORY = its rect + half of the gap to each neighbor
// (midpoint split, horizontally within a row and vertically across
// row/section borders). Cursor inside a territory -> that card becomes the
// OWNER and starts moving (FLIP slide): the ghost takes the owner's old
// cell, the owner slides to where the drag came from. Approach side maps to
// the ghost side: left/above -> 'after' (owner slides earlier in the DOM),
// right/below -> 'before' (owner slides later). The anchor is FROZEN while
// the cursor stays in the same owner's territory (pdLastTouchCard); reflow
// happens only at territory borders (gap midpoints, row/section midpoints).
// Row ends keep the legacy A3a; above the first section header — legacy A3c;
// the bottom band (below the last row of the last section) never reaches
// this function (cardAreaEmptyBand handles it). The ONLY remaining direct
// caller of slotAnchor(cardGapIndex(...)) is the legacy() fallback inside
// this function (A3a/A3c and edge cases) — the rail→center path switched to
// cursorCardAnchor (RAIL→CENTER parity), the chip path anchors by its own
// chip-row midpoint rule.
function cursorCardAnchor(clientX, clientY) {
  if (slotIsSourceHome(clientY)) return { el: dragSourceCardEl, side: 'after' };
  // Гонка отложенного создания заглушки (dragover раньше setTimeout(0)):
  // исходник ещё виден, курсор над НИМ — домашний слот (дроп — no-op).
  if (dragSourceCardEl && dragSourceCardEl.isConnected &&
      dragSourceCardEl.style.display !== 'none') {
    const sr = layoutRect(dragSourceCardEl);
    if (clientX >= sr.left && clientX <= sr.right && clientY >= sr.top && clientY <= sr.bottom)
      return { el: dragSourceCardEl, side: 'after' };
  }
  const cards = visibleCards();
  if (!cards.length) return null;
  const gIdx = new Map();
  cards.forEach((c, i) => gIdx.set(c, i));
  const lr = tabsList.getBoundingClientRect();
  const rightEdge = lr.right - (parseFloat(getComputedStyle(tabsList).paddingRight) || 0);
  const isHeader = el => el.classList.contains('gbar') || el.classList.contains('loose-label');
  const legacy = () => slotAnchor(cardGapIndex(clientX, clientY), clientY);
  // Sections in DOM order (same split as cardAreaEmptyBand): visible cards
  // and the ghost slot (when connected and visible) are attached to their
  // section, grouped into rows by rect.top (4px tolerance). The ghost is a
  // ROW ITEM — its cell (home position) is its own territory (sticky).
  const ghost = (dragGhostSlot && dragGhostSlot.isConnected &&
      dragGhostSlot.style.display !== 'none') ? dragGhostSlot : null;
  const sections = [];
  let cur = null;
  for (const el of tabsList.children) {
    if (el.id === 'add-group-btn') continue;
    if (isHeader(el)) {
      cur = { topEl: el, items: [] };
      sections.push(cur);
    } else {
      if (!cur) { cur = { topEl: null, items: [] }; sections.push(cur); }
      if (el.classList.contains('tab-card') && el !== dragSourceCardEl && el.style.display !== 'none')
        cur.items.push({ el, ghost: false });
      else if (ghost && el === ghost)
        cur.items.push({ el, ghost: true });
    }
  }
  for (const s of sections) {
    const rows = [];
    for (const it of s.items) {
      const r = layoutRect(it.el);
      const last = rows[rows.length - 1];
      if (last && Math.abs(last.top - r.top) < 4) { // <4: subpixel offsets must not split a row
        last.items.push(it);
        last.bottom = Math.max(last.bottom, r.bottom);
      } else rows.push({ top: r.top, bottom: r.bottom, items: [it] });
    }
    for (const row of rows)
      row.cards = row.items.filter(it => !it.ghost).map(it => it.el);
    s.rows = rows;
  }
  // STICKY (ex-old A3b): the ghost's current anchor — the next visible
  // card sibling (side 'before'); at the list end (no next sibling) —
  // 'after' the last visible card; at the end of its section (next sibling
  // is a header) — 'after' the section's last visible card; no card — legacy.
  const stickyGhostAnchor = () => {
    const g = dragGhostSlot;
    let n = g.nextElementSibling;
    while (n) {
      if (n.classList.contains('gbar') || n.classList.contains('loose-label')) {
        // Ghost at the end of its section: sticky anchor = after the
        // section's last visible card (never crosses the section header)
        let p = g.previousElementSibling;
        while (p && !(p.classList.contains('tab-card') && p.style.display !== 'none'))
          p = p.previousElementSibling;
        if (p) return { el: p, side: 'after' };
        break; // no section card — legacy fallback below
      }
      if (n.classList.contains('tab-card') && n.style.display !== 'none')
        return { el: n, side: 'before' };
      n = n.nextElementSibling;
    }
    if (n === null) return { el: cards[cards.length - 1], side: 'after' };
    return legacy();
  };
  // Owner by its horizontal span in a row: the elements tile [leftEdge,
  // rightEdge] by midpoints with the neighbors (edges — the list edges).
  // Null outside.
  const ownerOf = (els, x) => {
    const n = els.length;
    if (!n) return null;
    const rects = els.map(el => layoutRect(el));
    const leftEdge = rects[0].left;
    if (x < leftEdge || x > rightEdge) return null;
    for (let i = 0; i < n; i++) {
      const lo = i === 0 ? leftEdge : (rects[i - 1].right + rects[i].left) / 2;
      const hi = i === n - 1 ? rightEdge : (rects[i].right + rects[i + 1].left) / 2;
      if (x >= lo && x < hi) return els[i];
    }
    return els[n - 1];
  };
  // Owner anchor with freeze: entering a territory = "touch" — while the
  // cursor stays in the same owner's territory the anchor is frozen. With
  // flip=true (the horizontal approach path, owner's cell outside the card
  // rect) the side is also compared: crossing to the opposite side of the
  // owner (e.g. into the ghost|owner gap's far half) flips the approach side
  // and re-commits. The vertical zones (default flip=false) freeze on the
  // owner alone (freeze по территории).
  const commitOwner = (owner, side, flip) => {
    if (pdLastTouchCard === owner &&
        (!flip || (pdLastTouchAnchor && pdLastTouchAnchor.side === side)))
      return pdLastTouchAnchor;
    pdLastTouchCard = owner;
    const anchor = { el: owner, side };
    pdLastTouchAnchor = anchor;
    return anchor;
  };
  // Between-section zone (from the upper section S's last row bottom to the
  // lower section N's first row top, N's header included): midpoint split.
  // N without visible cards — the whole zone belongs to S's tail.
  // Spans only by CARDS (the ghost column is irrelevant for vertical zones).
  // Tail: the nearest section ABOVE with visible rows — a run of empty
  // (collapsed) sections between them is all that upper section's tail
  // territory; no such section — legacy.
  const betweenSections = (S, N, sections) => {
    if (N.rows.length) {
      const sLast = S.rows.length ? S.rows[S.rows.length - 1].bottom
        : (S.topEl ? layoutRect(S.topEl).bottom : lr.top);
      const M = (sLast + N.rows[0].top) / 2;
      if (clientY > M) {
        const owner = ownerOf(N.rows[0].cards, clientX);
        if (owner) return commitOwner(owner, 'after'); // approach from above
        return legacy();
      }
    }
    let up = S;
    while (up && !up.rows.length) {
      const i = sections.indexOf(up);
      up = i > 0 ? sections[i - 1] : null;
    }
    if (!up || !up.rows.length) return legacy();
    const row = up.rows[up.rows.length - 1];
    // The band below a section's last row is that section's TAIL territory:
    // the owner is the last card of the last row (the section end), NOT the
    // nearest-by-x card — a band point far from the last card still anchors
    // before it (approach from below -> side 'before').
    const owner = row.cards[row.cards.length - 1];
    if (owner) return commitOwner(owner, 'before'); // approach from below
    return legacy();
  };
  for (let si = 0; si < sections.length; si++) {
    const s = sections[si];
    const topBound = s.topEl ? layoutRect(s.topEl).top : lr.top;
    const rows = s.rows;
    // Above this section's top bound: the tail zone of the previous section
    // (or above the first header — legacy A3c).
    if (clientY < topBound) {
      if (si === 0) return legacy();
      return betweenSections(sections[si - 1], s, sections);
    }
    if (!rows.length) continue; // no visible items — the next topBound handles it
    const firstRowTop = rows[0].top;
    if (clientY < firstRowTop) {
      // Header-row zone above the first row.
      if (si === 0) {
        const owner = ownerOf(rows[0].cards, clientX);
        if (owner) return commitOwner(owner, 'after'); // approach from above
        return legacy();
      }
      return betweenSections(sections[si - 1], s, sections);
    }
    for (let ri = 0; ri < rows.length; ri++) {
      const row = rows[ri];
      const prev = ri > 0 ? rows[ri - 1] : null;
      if (prev && clientY >= prev.bottom && clientY < row.top) {
        // Row-gap zone (same section): midpoint split — above M the owner is
        // the upper row's card (approach from below), below M the lower row's.
        const M = (prev.bottom + row.top) / 2;
        const pick = clientY >= M ? row : prev;
        const owner = ownerOf(pick.cards, clientX);
        if (owner) return commitOwner(owner, clientY >= M ? 'after' : 'before');
        return legacy();
      }
      if (clientY < row.top || clientY > row.bottom) continue;
      // Row zone: cursor Y inside this row. The row is tiled over ALL its
      // items (visible cards + the ghost slot when visible in it) by
      // midpoints — each item owns [midPrev, midNext].
      const itemEls = row.items.map(it => it.el);
      const n = itemEls.length;
      if (!n) continue;
      const rects = itemEls.map(el => layoutRect(el));
      // A3a: empty end of the row (right of the rightmost item) — legacy
      // end-of-row behavior (unchanged).
      if (clientX > rects[n - 1].right) {
        const lastCard = row.cards[row.cards.length - 1];
        return lastCard ? slotAnchor(gIdx.get(lastCard) + 1, clientY) : legacy();
      }
      // Left of the first item — approach from the left of the row.
      if (clientX < rects[0].left) {
        const first = itemEls[0];
        return first === ghost ? stickyGhostAnchor() : commitOwner(first, 'after');
      }
      const owner = ownerOf(itemEls, clientX);
      if (!owner) return legacy();
      // The ghost's own cell — STICKY (home position): the anchor is the
      // ghost's current position, no reflow while the cursor stays in it.
      if (owner === ghost) return stickyGhostAnchor();
      // Owner is a card.
      const card = owner;
      const crect = layoutRect(card);
      if (clientX >= crect.left && clientX <= crect.right) {
        // Touch rule (unchanged): section-boundary override for the first
        // card of a section + freeze + DOM-side flip.
        const gi = gIdx.get(card);
        const header = sectionHeaderBefore(card);
        if (header && gi > 0 && tabGroupOf(card.__tab) !== tabGroupOf(cards[gi - 1].__tab)) {
          const hr = layoutRect(header);
          const below = clientY == null || clientY > hr.top + hr.height / 2;
          if (below) return { el: header, side: 'after' };
          return { el: cards[gi - 1], side: 'after' };
        }
        if (pdLastTouchCard === card) return pdLastTouchAnchor;
        pdLastTouchCard = card;
        const g = dragGhostSlot;
        let anchor;
        if (g && g.isConnected) {
          const ghostBefore = g.compareDocumentPosition(card) & Node.DOCUMENT_POSITION_FOLLOWING;
          anchor = { el: card, side: ghostBefore ? 'after' : 'before' };
        } else {
          anchor = { el: card, side: 'before' }; // no ghost yet (deferred creation)
        }
        pdLastTouchAnchor = anchor;
        return anchor;
      }
      // In the owner's cell but outside the card rect: approach from the
      // left (clientX < card.left) → side 'after'; from the right → 'before'.
      // flip=true: crossing to the opposite side of the owner re-commits.
      return commitOwner(card, clientX < crect.left ? 'after' : 'before', true);
    }
    // Below all rows of this section: the between-sections zone ends at the
    // next section's first row (or header) top — deeper is the next
    // section's territory (its own iteration handles it).
    if (si < sections.length - 1) {
      const next = sections[si + 1];
      const nextTop = next.rows.length ? next.rows[0].top
        : (next.topEl ? layoutRect(next.topEl).top : lr.top);
      if (clientY < nextTop) return betweenSections(s, next, sections);
      continue;
    }
    // Below the last row of the last section — the bottom band
    // (unreachable: cardAreaEmptyBand catches it first).
    return legacy();
  }
  return legacy();
}

// Секция позиции заглушки (groupId или null): карточка — группа её вкладки;
// «после» шапки — секция шапки; «до» шапки — секция карточки, стоящей
// перед шапкой.
function slotSection(anchor) {
  if (anchor.el.classList.contains('tab-card')) return tabGroupOf(anchor.el.__tab);
  if (anchor.side === 'after') return headerSection(anchor.el);
  let prev = anchor.el.previousElementSibling;
  while (prev && !prev.classList.contains('tab-card')) prev = prev.previousElementSibling;
  return prev ? tabGroupOf(prev.__tab) : null;
}

// Первая/последняя вкладка секции в ПОЛНОМ массиве (секция = активное
// пространство + groupId; null — «Без группы»)
function sectionTabFull(section, last) {
  const inSec = allTabs.filter(t => t.spaceId === activeSpaceId && tabGroupOf(t) === section);
  return inSec.length ? inSec[last ? inSec.length - 1 : 0] : null;
}

// Дроп в позицию заглушки: вкладка встаёт в ПОЛНОМ allTabs на позицию слота —
// перед/после якорной вкладки (конец секции — после последней вкладки секции,
// конец списка — в конец) — и получает groupId секции слота (null — «Без
// группы»); spaceId не меняется. Same slot (позиция и группа те же) — no-op.
// True when the card is the last VISIBLE card of its section (no visible
// same-section card after it in the DOM): an "after" anchor on such a card
// means the end of the section; on a mid-section card it means "right after
// this card" (touch from the left: the card slides left, the ghost takes
// the card's old cell).
function isLastVisibleOfSection(card) {
  const sec = tabGroupOf(card.__tab);
  let n = card.nextElementSibling;
  while (n && !n.classList.contains('gbar') && !n.classList.contains('loose-label')) {
    if (n.classList.contains('tab-card') && n.style.display !== 'none' && tabGroupOf(n.__tab) === sec)
      return false;
    n = n.nextElementSibling;
  }
  return true;
}

// Якорь слота → (anchorUrl, side, section) в ПОЛНОМ allTabs: карточка
// 'before' — перед ней; 'after' — после неё, если она последняя ВИДИМАЯ
// секции (конец секции), иначе сразу после (mid-section); 'after' шапки —
// начало её секции (перед первой); 'before' шапки — конец предыдущей
// секции (после последней). null — нет якоря / пустая секция (dropper
// кладёт в конец списка).
function slotAnchorResolution(anchor) {
  if (!anchor || !anchor.el) return null;
  const section = slotSection(anchor);
  let anchorUrl, side = anchor.side;
  if (anchor.el.classList.contains('tab-card') && anchor.side === 'before') {
    anchorUrl = anchor.el.__tab.url; // перед видимой карточкой X
  } else if (anchor.el.classList.contains('tab-card')) {
    if (isLastVisibleOfSection(anchor.el)) {
      const t = sectionTabFull(section, true); // end of section (= end of list)
      if (!t) return null;
      anchorUrl = t.url; side = 'after';
    } else {
      anchorUrl = anchor.el.__tab.url; // mid-section: right after the anchor card
      side = 'after';
    }
  } else if (anchor.side === 'after') {
    const t = sectionTabFull(section, false); // начало секции
    if (!t) return null;
    anchorUrl = t.url; side = 'before';
  } else {
    const t = sectionTabFull(section, true); // конец предыдущей секции
    if (!t) return null;
    anchorUrl = t.url; side = 'after';
  }
  return { anchorUrl, side, section };
}

function placeCardToSlot(src, anchor) {
  if (!anchor || !anchor.el) return;
  const from = allTabs.indexOf(src);
  if (from === -1) return;
  const res = slotAnchorResolution(anchor);
  if (!res) return;
  const { anchorUrl, side, section } = res;
  const anchorIndex = allTabs.findIndex(t => t.url === anchorUrl);
  if (anchorIndex === -1) return;
  const batch = dragBatchUrls;
  if (batch && batch.length > 1) return placeBatchToSlot(batch, anchorUrl, side, section);
  // Дроп в СВОЁ место исходной карточки (якорь — сама исходная, сторона
  // «после»): no-op — позиция и группа не меняются
  if (anchorUrl === src.url && side === 'after') return;
  let a = anchorIndex > from ? anchorIndex - 1 : anchorIndex;
  const finalAt = side === 'before' ? a : Math.min(a + 1, allTabs.length - 1);
  if (finalAt === from && section === tabGroupOf(src)) return;
  chrome.runtime.sendMessage({ action: 'place-tab', index: from, anchorIndex, side, groupId: section });
  // Свернутая группа-секция слота: вкладка в неё ушла — разворачиваем
  expandGroupForDrop(section);
}

// Перенос выделенного батча в слот: ВСЕ вкладки `batch` (порядок между ними —
// исходный) встают на позицию слота блоком и получают группу секции слота.
// Симуляция по allTabs: если порядок И группы батча не меняются — no-op
// (сообщение не шлётся, перерисовки нет).
function placeBatchToSlot(batch, anchorUrl, side, section) {
  const urlsSet = new Set(batch);
  const moved = allTabs.filter(t => urlsSet.has(t.url));
  if (!moved.length) return;
  const a = allTabs.findIndex(t => t.url === anchorUrl);
  if (a === -1) return;
  let removedBefore = 0;
  for (let i = 0; i < a; i++) if (urlsSet.has(allTabs[i].url)) removedBefore++;
  const at = Math.max(0, Math.min(allTabs.length - moved.length,
    side === 'after' ? a - removedBefore + 1 : a - removedBefore));
  const rest = allTabs.filter(t => !urlsSet.has(t.url));
  const next = rest.slice();
  next.splice(at, 0, ...moved);
  let changed = false;
  for (let i = 0; i < next.length; i++) {
    if (next[i].url !== allTabs[i].url) { changed = true; break; }
    if (urlsSet.has(next[i].url) && section !== tabGroupOf(allTabs[i])) { changed = true; break; }
  }
  if (!changed) return;
  chrome.runtime.sendMessage({ action: 'place-tabs', urls: batch, anchorUrl, side, groupId: section });
  // Свернутая группа-секция слота: батч в неё ушёл — разворачиваем
  expandGroupForDrop(section);
}

// Новое нажатие мыши — реальное действие пользователя: сбрасываем one-shot
// флаг ложного post-drop клика ДО того, как придёт его click (у ложного клика
// после drag mousedown не было)
document.addEventListener('mousedown', () => { pendingGbarClickAfterDrag = false; pendingChipClickAfterDrag = false; pendingCardClickAfterDrag = false; pendingBtClickAfterDrag = false; }, true);

// Глобальные dragover/drop: нативный drag-образ браузера следует за курсором,
// заглушка — в ближайшую позицию вставки (с учётом секций). Свою семантику дропа
// карточки сохранили чип пространства (заглушка над ним замирает) и шапка группы /
// слот пустой группы (вкладка уходит В группу) — над последними заглушку прячем
// целиком: ни «тёплая» заглушка на старом месте, ни дырка на её месте не остаётся.
// Прячет/показывает заглушку по display: display:none освобождает её ячейку
// сетки (сетка перетекает — дырки нет), display:'' возвращает слот. Элемент НЕ
// удаляем из DOM, чтобы moveGhostSlot мог вернуть его в позицию вставки.
function setGhostDisplay(v) {
  if (dragGhostSlot) dragGhostSlot.style.display = v;
}

// Пустая полоса центр.сетки #tabs-list — НИЗОВАЯ ЗОНА:
// пространство ниже последней видимой строки ПОСЛЕДНЕЙ
// секции, до низа #tabs-list (строка #add-group-btn + отступ .tabs-list
// — не границы полосы). Всё остальное место (шапные строки,
// зазоры между карточками/строками/секциями) — территории
// карточек (cursorCardAnchor): заглушка видима, дроп — в слот.
// Над полосой — как над шапкой: заглушка прячется ЦЕЛИКОМ, дроп — отмена
// (вкладка возвращается в исходный слот, storage не тронут). Пустые
// ячейки СВОЙ строки (справа от последней карточки) — НЕ полоса.
// Видимая заглушка и слот пустой группы ЗАНИМАЮТ строку (полоса
// не глотает их). Возвращает id секции под курсором (groupId;
// «loose» — негрупповая) или null.
function cardAreaEmptyBand(clientX, clientY) {
  if (clientX == null || clientY == null) return null;
  const lr = tabsList.getBoundingClientRect();
  if (clientX < lr.left || clientX > lr.right) return null;
  const g = (dragGhostSlot && dragGhostSlot.isConnected && dragGhostSlot.style.display !== 'none')
    ? dragGhostSlot.getBoundingClientRect() : null;
  const gidOf = el => el.classList.contains('gbar')
    ? (el.dataset.groupId || null) : 'loose';
  const isHeader = el => el.classList.contains('gbar') || el.classList.contains('loose-label');
  // Секции по шапкам в DOM-порядке; содержимое до первой шапки —
  // негрупповая секция без шапки (#add-group-btn — терминатор, не содержимое)
  const sections = [];
  let cur = null;
  for (const el of tabsList.children) {
    if (el.id === 'add-group-btn') { if (cur) cur.nextEl = el; continue; }
    if (isHeader(el)) {
      cur = { id: gidOf(el), topEl: el, nextEl: null, items: [] };
      sections.push(cur);
    } else {
      if (!cur) { cur = { id: 'loose', topEl: null, nextEl: null, items: [] }; sections.push(cur); }
      cur.items.push(el);
    }
  }
  for (let i = 0; i < sections.length; i++) {
    const s2 = sections[i];
    const next = s2.nextEl || (i < sections.length - 1 ? sections[i + 1].topEl : null);
    s2.topBound = s2.topEl ? s2.topEl.getBoundingClientRect().top : lr.top;
    // #add-group-btn — терминатор секции, но НЕ граница полосы: нижняя зона
    // последней секции (строка кнопки + отступ .tabs-list) — полоса до конца
    s2.nextTop = (next && next.id !== 'add-group-btn')
      ? next.getBoundingClientRect().top : lr.bottom;
  }
  // Осталась ОДНА полоса (территории курсора — в
  // cursorCardAnchor): ниже последней видимой строки ПОСЛЕДНЕЙ секции —
  // до низа списка (строка кнопки + отступ). Всё остальное (шапа А/Б/С)
  // — больше не полосы: территории карточек.
  if (!sections.length) return null;
  const last2 = sections[sections.length - 1];
  const rows = [];
  const addRow = (r) => {
    if (!r || r.height <= 0) return;
    const last = rows[rows.length - 1];
    if (last && Math.abs(last.top - r.top) < 4) { if (r.bottom > last.bottom) last.bottom = r.bottom; } // <4: subpixel offsets must not split a row
    else rows.push({ top: r.top, bottom: r.bottom });
  };
  for (const el of last2.items) {
    if (el.classList.contains('tab-card') && el.style.display !== 'none') addRow(layoutRect(el));
    else if (el.classList.contains('group-empty-slot')) addRow(layoutRect(el));
  }
  if (g && ghostSlotSectionId() === (last2.id === 'loose' ? null : last2.id)) addRow(g);
  rows.sort((a, b) => a.top - b.top);
  const inBand = (y1, y2) => clientY > y1 && clientY < y2;
  const res = last2.id === 'loose' ? 'loose' : last2.id;
  if (!rows.length) return inBand(last2.topBound, last2.nextTop) ? res : null;
  return inBand(rows[rows.length - 1].bottom, last2.nextTop) ? res : null;
}

document.addEventListener('dragover', (e) => {
  if (!dragSourceUrl || dragSourceGroupId || !e.dataTransfer) return;
  // Логика слежения за заглушкой — в trackCardDragAt (общая с pointer-путём).
  // preventDefault/dropEffect — только там, где и раньше: над шапкой/слотом
  // пустой группы, пустой полосой карт.области и в пределах списка.
  if (trackCardDragAt(e.clientX, e.clientY, e.target)) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  }
});

document.addEventListener('drop', (e) => {
  if (!dragSourceUrl || dragSourceGroupId || !e.dataTransfer) return;
  const t = e.target;
  if (!t || !tabsList.contains(t)) return;
  if (t.closest && t.closest('.gbar')) return; // дроп на шапку группы — карточка не переезжает через неё
  if (t.closest && t.closest('.group-empty-slot')) return; // слот пустой группы — свой обработчик шлёт, глобальный не должен
  // Пустая полоса сетки (между строками карточек) — ОТМЕНА: no place-tab /
  // place-tabs — вкладка возвращается в исходный слот на dragend (storage не
  // тронут); заглушка снимается, карточка и холдеры — в endCardDrag
  if (cardAreaEmptyBand(e.clientX, e.clientY)) {
    e.preventDefault();
    removeGhostSlot();
    return;
  }
  const src = allTabs.find(tb => tb.url === dragSourceUrl);
  if (!src) return;
  e.preventDefault();
  placeCardToSlot(src, cursorCardAnchor(e.clientX, e.clientY));
  removeGhostSlot();
});

// === Карточка → правая рейка: открыть сохранённый сайт новой фоновой вкладкой ===
// Дроп сохранённой карточки по #rail-right — сайт открывается новой фоновой
// вкладкой (chrome.tabs.create, active:false). Сама карточка НЕ меняется:
// без place-tab/place-tabs, без записи в blattam-tabs — она остаётся в своём
// слоте сетки (оба пути драга: HTML5-дроп рейки ниже + commitCardDropAt
// pointer-пути). Выделенный батч: все выделенные сайты открываются фоном.
function openSavedUrlsInBackground(urls) {
  if (!chrome.tabs || typeof chrome.tabs.create !== 'function') return;
  for (const url of urls || []) {
    if (!url) continue;
    try { chrome.tabs.create({ url: url, active: false }); } catch (_) {}
  }
}

// HTML5-путь: рейка — цель дропа только для драга КАРТОЧКИ (dragSourceUrl).
// Собственный драг рейки (dragSourceBrowserTab) идёт своими глобальными
// обработчиками — здесь не трогаем; глобальный document-дроп по рейке не
// коммитится (он принимает только #tabs-list) — двойного срабатывания нет.
// dragover-предупреждение (preventDefault) рейка даёт сама — иначе браузер
// не разрешит drop на ней.
if (railRight) {
  railRight.addEventListener('dragover', (e) => {
    if (!dragSourceUrl || dragSourceGroupId || !e.dataTransfer) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    railRight.classList.add('rail-drag-over'); // тёплый тон: рейка принимает карточку
  });
  // Курсор ушёл с рейки — тёплый тон снят (endCardDrag — страховка на dragend)
  railRight.addEventListener('dragleave', () => {
    railRight.classList.remove('rail-drag-over');
  });
  railRight.addEventListener('drop', (e) => {
    if (!dragSourceUrl || dragSourceGroupId || !e.dataTransfer) return;
    const src = allTabs.find(tb => tb.url === dragSourceUrl);
    if (!src) return;
    e.preventDefault();
    railRight.classList.remove('rail-drag-over'); // коммит — тёплый тон снят
    const urls = (dragBatchUrls && dragBatchUrls.length > 1) ? dragBatchUrls : [src.url];
    openSavedUrlsInBackground(urls);
    removeGhostSlot(); // dragend/endCardDrag довершит очистку
  });
}

// Ядро драга карточки, общее для HTML5-обработчиков и pointer-пути.
// Захват карточки: исходник + флаги ложного клика + батч выбора, затем
// ставим тёплую заглушку (ghost-slot) ПОСЛЕ карточки и прячем саму
// карточку (display:none) — исходник вырван из сетки, единственная видимая
// копия — под курсором (pointer-путь: LIFT-клон .pd-clone; HTML5-путь:
// нативный drag-образ браузера). sync=true — синхронно (pointer-путь);
// HTML5-путь сохраняет отложенное создание setTimeout(0) (хид в момент
// trusted dragstart может заклинить нативный драг — known Chrome quirk).
function beginCardDrag(tab, cardEl, sync) {
  dragSourceUrl = tab.url;
  dragSourceCardEl = cardEl;
  pdLastTouchCard = null; // fresh drag — no card touched yet
  pdLastTouchAnchor = null;
  dragOverTarget = null; // свежий драг — целевой dragover ещё не приходил
  dragOverTargetXY = null;
  // Вооружаем подавление ложного клика по шапке уже на dragstart: реальный
  // Chrome генерирует его на drop-цели ДО dragend источника — флаг, поставленный
  // только на dragend, его не поймаешь
  pendingGbarClickAfterDrag = true;
  pendingCardClickAfterDrag = true; // дроп на другую карточку — ложный клик её не открывает
  // Выделенный батч: перетаскивая ЛЮБУЮ выделенную карточку, переезжают ВСЕ
  // выделенные вкладки (батч — в исходном порядке). В рендере — как одна:
  // скрыта только захваченная карточка (display:none), заглушка одна,
  // остальные выделенные карточки остаются видимыми.
  dragBatchUrls = (selectedUrls.size > 1 && selectedUrls.has(tab.url))
    ? allTabs.filter(t => selectedUrls.has(t.url)).map(t => t.url)
    : [tab.url];
  cardEl.classList.add('dragging');
  dragCardSize = { w: cardEl.offsetWidth, h: cardEl.offsetHeight }; // до хайда в applyGhost
  // Состояние «идёт перетаскивание карточки» — для тонировки шапок групп при hover
  document.body.classList.add('dragging-card');
  const applyGhost = () => {
    // Перерисовка во время драга уносит карточку из DOM, а поздний drop/dragend
    // уже решил драг — заглушку для отсоединённой карточки не вставляем
    if (dragSourceUrl !== tab.url || !cardEl.isConnected) return;
    if (!dragGhostSlot) {
      dragGhostSlot = makeGhostSlot(cardEl);
      cardEl.insertAdjacentElement('afterend', dragGhostSlot);
    }
    // Исходник вырван из сетки (тот же паттерн, что рейка/чип-пути: хайд
    // ПОСЛЕ синхронной вставки той же заглушки — без рефлоу): видимая копия
    // только одна — под курсором (pointer-путь: LIFT-клон, его cssText
    // перезаписан pdCreateClone целиком, клон виден; HTML5: нативный
    // drag-образ). Возврат — в endCardDrag (cardEl.style.display = '').
    cardEl.style.display = 'none';
    // Гонка: первый dragover мог попасть на шапку/слот/пустую полосу карт.области
    // группы ПЕРЕД этим таймером (заглушки ещё не существовало). Повторяем
    // состояние по dragOverTarget (зона — по её координатам), иначе свежая
    // заглушка неверно «замигает» дома.
    const overGbarOrSlot = dragOverTarget && dragOverTarget.closest &&
        (dragOverTarget.closest('.gbar') || dragOverTarget.closest('.group-empty-slot'));
    const overRail = dragOverTarget && dragOverTarget.closest &&
        dragOverTarget.closest('#rail-right');
    const overEmptyBand = dragOverTargetXY !== null &&
        cardAreaEmptyBand(dragOverTargetXY[0], dragOverTargetXY[1]) !== null;
    if (overGbarOrSlot || overRail || overEmptyBand) {
      setGhostDisplay('none');
    }
    syncSourceRowKeeper(); // заглушка дома ИЛИ спрятана на старте — пересчёт холдеров
  };
  if (sync) applyGhost();
  else setTimeout(applyGhost, 0);
}

// Конец драга карточки (dragend / конец pointer-драга): заглушка снимается
// первой, затем карточка возвращается в свой слот, сброс исходника и флагов
// ложных кликов.
function endCardDrag(cardEl) {
  lastDragEndAt = Date.now();
  pendingGbarClickAfterDrag = true;
  dragSourceUrl = null;
  dragSourceCardEl = null;
  pdLastTouchCard = null;
  pdLastTouchAnchor = null;
  dragCardSize = null;
  dragBatchUrls = null;
  dragOverTarget = null; // не держим ссылку на DOM-узел после драга
  dragOverTargetXY = null;
  restoreWrapHiddenCard(); // «row-full» группа: вернуть временно скрытую крайнюю карточку
  removeSourceRowKeeper(); // холдеры последней строки — снять (dragend / Escape / cancel)
  // Снимаем состояние «идёт перетаскивание карточки» (тонировка шапок групп)
  document.body.classList.remove('dragging-card');
  if (cardEl) {
    cardEl.classList.remove('dragging');
    cardEl.style.cursor = '';
    removeGhostSlot(); // заглушка снимается первой, затем карточка
                       // возвращается в свой слот
    if (cardEl.isConnected) cardEl.style.display = ''; // возврат карточки (во время драга скрыта display:none)
  }
  document.querySelectorAll('.space-chip.drag-over').forEach(c => c.classList.remove('drag-over'));
  if (railRight) railRight.classList.remove('rail-drag-over'); // рейка: тёплый тон не «залипает» после dragend
}

// === «row-full» группа: заглушка не доращивает новую строку ===
// Драг карточки: тёплая заглушка внутри группы, строки которой ПОЛНЫЕ (число
// реальных карточек группы кратное числу колонок сетки), дорастила бы НОВУЮ
// строку. Чтобы число строк группы осталось постоянным, временно скрываем
// крайнюю карточку группы — заглушка занимает её клетку. Карточка возвращается:
// заглушка ушла из группы / заглушка скрыта (шапка / слот / пустая зона) / драг
// закончился / перерисовка. Новая строка появляется только на реальном дропе
// (в группу уходит настоящая карточка). Только группы: loose-секция — как была.
function gridColumnCount() {
  const cs = getComputedStyle(tabsList);
  if (cs.display !== 'grid') return 0; // не сетка — понятие «полных строк» не применимо
  const gtc = cs.gridTemplateColumns;
  return (gtc && gtc !== 'none') ? gtc.trim().split(/\s+/).length : 0;
}

// Крайняя видимая карточка группы (кроме перетаскиваемой).
function lastVisibleGroupCard(gid) {
  const cards = [...document.querySelectorAll('#tabs-list .tab-card')]
    .filter(c => c.__tab && c.__tab.groupId === gid && c !== dragSourceCardEl &&
                 c.style.display !== 'none');
  return cards.length ? cards[cards.length - 1] : null;
}

function restoreWrapHiddenCard() {
  if (dragWrapHiddenCard) {
    if (dragWrapHiddenCard.isConnected) dragWrapHiddenCard.style.display = '';
    dragWrapHiddenCard = null;
    dragWrapHiddenGroup = null;
  }
}

// === Холдер последней строки исходной секции (row-keeper) ===
// Заглушка УЕХАЛА из исходной секции (в другую секцию или спрятана над
// .gbar / .group-empty-slot / пустой полосой карт.области) — вырванная
// карточка высвободила свою клетку, и последняя строка секции может
// СХОЛОНТЬСЯ, сдвинув всё, что ниже. Пока число строк секции уменьшается,
// хвост держит невидимая карточка-заглушка (.tab-row-keeper, opacity:0,
// pointer-events:none; НЕ .tab-card — groupVisibleCardCount и вооружение
// шапок групп её не видят). Заглушка ВНУТРИ секции — холдер не нужен:
// она сама занимает клетку. Холдер ставится в ХВОСТ исходной секции
// (после последней видимой карточки, после её .gbar, если видимых
// карточек нет, перед #add-group-btn в негрупповой секции) и снимается,
// когда заглушка возвращается в секцию / драг закончился / перерисовка.
// Размер — размер схваченной карточки (dragCardSize, снят до хайда).
// Визуально это «пустая» строка держится всё время драга — удобно для
// быстрого перетаскивания: пространство ниже не елозится.
function ghostSlotSectionId() {
  const g = dragGhostSlot;
  if (!g || !g.isConnected || g.style.display === 'none') return null;
  for (let el = g.previousElementSibling; el; el = el.previousElementSibling) {
    if (el.classList.contains('tab-row-keeper') ||
        el.classList.contains('tab-ghost-slot')) continue;
    if (el.classList.contains('gbar') || el.classList.contains('group-empty-slot'))
      return el.dataset.groupId || null;
    if (el.classList.contains('tab-card')) return el.__tab ? tabGroupOf(el.__tab) : null;
    return null; // .loose-label, «+ Группа» и прочее — негрупповая секция
  }
  return null; // заглушка до первого ребёнка списка — негрупповая секция
}

function makeRowKeeper() {
  const k = document.createElement('div');
  k.className = 'tab-row-keeper';
  k.style.cssText = 'opacity:0;pointer-events:none;';
  const s = dragCardSize;
  if (s && s.w) k.style.width = s.w + 'px';
  if (s && s.h) k.style.height = s.h + 'px';
  return k;
}

function removeSourceRowKeeper() {
  dragRowKeepers.forEach(k => { if (k.isConnected) k.remove(); });
  dragRowKeepers = [];
  dragRowKeeperSection = null;
}

// Пересчёт холдеров после перемещения/скрытия заглушки: подключаются ТОЛЬКО
// когда заглушка НЕ занимает клетку в исходной секции И число отрисованных
// строк этой секции без холдеров МЕНЬШЕ rOrig = ceil(nFull / cols)
// (nFull — ПОЛНОЕ число карточек источника, включая вырванную). Число
// холдеров = rOrig − текущие строки (обычно 1). Не сетка (cols 0) — нет.
function syncSourceRowKeeper() {
  if (!dragSourceUrl || !dragSourceCardEl || !dragSourceCardEl.isConnected) {
    removeSourceRowKeeper();
    return;
  }
  const src = allTabs.find(t => t.url === dragSourceUrl);
  const srcGid = src ? tabGroupOf(src) : null;
  const g = dragGhostSlot;
  const ghostVisible = !!(g && g.isConnected && g.style.display !== 'none');
  if (ghostVisible && ghostSlotSectionId() === srcGid) {
    removeSourceRowKeeper(); // заглушка в секции — сама держит клетку
    return;
  }
  const cols = gridColumnCount();
  if (!cols) { removeSourceRowKeeper(); return; }
  const nFull = allTabs.filter(t => t.spaceId === activeSpaceId && tabGroupOf(t) === srcGid).length;
  const rOrig = Math.ceil(nFull / cols);
  const visible = [...document.querySelectorAll('#tabs-list .tab-card')]
    .filter(c => c !== dragSourceCardEl && c.style.display !== 'none' &&
                 (c.__tab ? tabGroupOf(c.__tab) : null) === srcGid);
  const keepersNeeded = Math.max(0, rOrig - Math.ceil(visible.length / cols));
  if (keepersNeeded === 0) { removeSourceRowKeeper(); return; }
  if (dragRowKeeperSection !== srcGid) removeSourceRowKeeper();
  let anchorEl = null;
  if (srcGid != null) {
    anchorEl = lastVisibleGroupCard(srcGid) ||
      document.querySelector('#tabs-list .gbar[data-group-id="' + srcGid + '"]');
    if (!anchorEl) { removeSourceRowKeeper(); return; }
  } // loose (srcGid null): append keepers at the END of #tabs-list
  while (dragRowKeepers.length < keepersNeeded) {
    const k = makeRowKeeper();
    if (srcGid != null) anchorEl.after(k); else tabsList.appendChild(k);
    dragRowKeepers.push(k);
  }
  while (dragRowKeepers.length > keepersNeeded) {
    const k = dragRowKeepers.pop();
    if (k.isConnected) k.remove();
  }
  dragRowKeeperSection = srcGid;
}

// Заглушка в группе (anchor — {el, side}): после вставки заглушки группа дорастёт
// НОВУЮ строку — держим скрытой крайнюю карточку (одна и та же, пока заглушка внутри
// группы); иначе — вернуть ранее скрытую. Loose (null) — тоже вернуть.
// Критерий: ПОЛНОЕ число карточек группы nFull (allTabs активного
// пространства, включая перетаскиваемую) — драг внутри группы не меняет числа карточек в ней и новая строка вне возникает; растёт
// только внешняя карточка: видимые + 1 (заглушка) > rOrig*cols.
function updateWrapHiddenCard(anchor) {
  const gid = slotSection(anchor);
  if (gid == null) { restoreWrapHiddenCard(); return; }
  if (dragWrapHiddenCard && dragWrapHiddenGroup === gid &&
      dragWrapHiddenCard.isConnected && dragWrapHiddenCard.style.display === 'none') return;
  restoreWrapHiddenCard();
  const cols = gridColumnCount();
  if (!cols) return; // не сетка — без временного скрытия
  const nFull = allTabs.filter(t => t.spaceId === activeSpaceId && tabGroupOf(t) === gid).length;
  const rOrig = Math.ceil(nFull / cols); // строк группы в до-переносной раскладке
  const visible = [...document.querySelectorAll('#tabs-list .tab-card')]
    .filter(c => c.__tab && c.__tab.groupId === gid && c !== dragSourceCardEl &&
                 c.style.display !== 'none');
  const hideCount = (visible.length + 1) - rOrig * cols; // +1 — клетка заглушки
  if (hideCount > 0) {
    const last = lastVisibleGroupCard(gid);
    if (last) {
      last.style.display = 'none';
      dragWrapHiddenCard = last;
      dragWrapHiddenGroup = gid;
    }
  }
}

// Tracks the card drag at coordinates (clientX, clientY): ghost hidden (over
// .gbar / .group-empty-slot / group card-area empty zone), frozen (over a
// space chip) or moved (slot in the list). Returns true when the point is a
// valid card-drag position (HTML5 dragover needs preventDefault there).
// targetEl — event target (HTML5 path); the pointer path passes null and the
// target is resolved via document.elementFromPoint.
function trackCardDragAt(clientX, clientY, targetEl) {
  if (!dragSourceUrl || dragSourceGroupId) return false;
  const t = targetEl || document.elementFromPoint(clientX, clientY);
  // Тёплый тон правой рейки — цель дропа карточки (открыть сайт фоновой
  // вкладкой). Рейка лежит вне #tabs-list, поэтому проверка стоит ДО всех
  // веток (работает независимо от попадания в список) и сама снимает класс,
  // когда курсор уходит с рейки (любой другой target).
  dragOverTarget = t;
  dragOverTargetXY = [clientX, clientY];
  if (railRight) {
    if (t && t.closest && t.closest('#rail-right')) {
      railRight.classList.add('rail-drag-over');
      // Призрак спрятан целиком — рейка за пределами #tabs-list, у слота нет
      // валидного места вставки (тот же паттерн, что .gbar/.group-empty-slot);
      // строка исходной секции держится условным холдером.
      setGhostDisplay('none');
      restoreWrapHiddenCard(); // заглушка скрыта — новая строка не видна
      syncSourceRowKeeper(); // заглушка спрятана — исходная секция держит строку холдером
      return true;
    }
    railRight.classList.remove('rail-drag-over');
  }
  // Over ANY group header (.gbar) and over an empty-group slot
  // (.group-empty-slot) the card drops INTO that group (own drop handler on
  // the element) — hide the ghost WHOLLY. NOT removeGhostSlot: deferred ghost
  // creation is only in dragstart, a removed ghost never reappears.
  if (t && t.closest && (t.closest('.gbar') || t.closest('.group-empty-slot'))) {
    setGhostDisplay('none');
    restoreWrapHiddenCard(); // заглушка скрыта — новая строка не видна
    syncSourceRowKeeper(); // заглушка спрятана — исходная секция держит строку холдером
    return true;
  }
  // Space chip: ghost stands still in place (behavior unchanged).
  if (t && t.closest && t.closest('.space-chip')) return false;
  // Пустая полоса сетки (полоса А/В/С над любой секцией: выше первой
  // строки / ниже последней / row-gap между строками): hide the ghost wholly.
  // Empty cells of its OWN row — not a band: ghost stays visible in the
  // potential slot (list path below).
  if (cardAreaEmptyBand(clientX, clientY) !== null) {
    setGhostDisplay('none');
    restoreWrapHiddenCard(); // заглушка скрыта — новая строка не видна
    syncSourceRowKeeper(); // заглушка спрятана — исходная секция держит строку холдером
    return true;
  }
  if (!t || !tabsList.contains(t)) return false;
  const anchor = cursorCardAnchor(clientX, clientY);
  setGhostDisplay('');
  if (anchor) {
    // FLIP (pointer path ONLY): when the slot anchor actually CHANGES — record
    // rects of the visible cards before the move, then apply the slide
    // transform after it. One FLIP pass per anchor change. The synthetic
    // HTML5 path never FLIPs — its geometry is untouched.
    // ВАЖНО: снимок — ДО ВСЕХ рефлоу этого события (wrap-hidden + ход
    // заглушки + холдер): «first» = истинное до-состояние (settled-раскладка
    // предыдущего тика), «last» = финальная раскладка после хода. Если любой
    // рефлоу стоит ПЕРЕД снимком — снимок фиксирует фантомную раскладку:
    // например, restoreWrapHiddenCard возвращает крайнюю карточку row-full
    // группы, пока заглушка ЕЩЁ в её строке (6 ячеек = +1 строка), а затем
    // moveGhostSlot уводит заглушку и строка схлопывается. FLIP старт-
    // трансформ = (фантом − финал) = +высота строки: ВСЕ карточки ниже
    // группы (крайняя карточка G, сама H и всё под ней) на 200ms уезжают
    // ВНИЗ на строку и слайдом возвращаются — «дерганье вниз» вкладок под
    // группой при касании зазора между её последней вкладкой и шапкой
    // следующей группы (баг G<->H gap).
    const changed = pd && pd.armed &&
        (!pdLastAnchor || pdLastAnchor.el !== anchor.el || pdLastAnchor.side !== anchor.side);
    const firstRects = changed ? snapshotCardRects() : null;
    // «row-full» группа: держим/снимаем временное скрытие крайней карточки —
    // её рефлоу входит в post-геометрию FLIP (applyFlipFrom читает финальную
    // раскладку); скрытая карточка в снимок не попадёт и «мигнёт» на месте
    // заглушки без слайда
    updateWrapHiddenCard(anchor);
    moveGhostSlot(anchor);
    pdLastAnchor = anchor;
    // Холдер строки исходной секции пересчитываем ДО post-снимка FLIP
    // (тот же тик): заглушка уехала из исходной секции — она могла потерять
    // строку, и невидимый холдер её разворачивает обратно. Post-геометрия
    // FLIP обязана учесть этот рефлоу: иначе старт-трансформ = (старая −
    // схлопнутая) = +высота строки — все карточки НИЖЕ исходной секции
    // («под ней») на кадр уезжают ВНИЗ на строку и 200ms-слайдом возвращаются
    // (видимое «дерганье вниз» сохранённых вкладок при проносе мимо группы).
    syncSourceRowKeeper();
    if (firstRects) applyFlipFrom(firstRects);
  } else {
    restoreWrapHiddenCard(); // заглушка не вставлена — скрытую карточку вернуть
  }
  syncSourceRowKeeper(); // заглушка переехала (или осталась) — пересчёт холдеров
  return true;
}

// FLIP: record rects of visible elements (the drag source is excluded).
// Без аргументов — карточки #tabs-list (card path); selector + excludeEl —
// chip path ('#space-chips .space-chip', скрытый исходный чип).
function snapshotCardRects(selector, excludeEl) {
  const m = new Map();
  const scope = selector || '#tabs-list .tab-card';
  for (const c of document.querySelectorAll(scope)) {
    if (c === excludeEl || c === dragSourceCardEl || c.style.display === 'none') continue;
    m.set(c, c.getBoundingClientRect());
  }
  return m;
}

// FLIP, dnd-kit style (Toby original: transform 200ms ease, same-frame retargeting):
// after the reflow (ghost slot moved) — layout position = post-rect MINUS the in-flight
// transform (getComputedStyle matrix, may be mid-interpolation); the inverse transform
// (pre-reflow visual - layout) is applied with transition:none + a sync flush
// (offsetHeight), then transition 'transform <slideMs>ms ease' + transform:'' — the slide
// starts in the SAME frame as the reflow; on the next anchor change the transition
// retargets from the current interpolated position (no rAF wait, no setTimeout fallback:
// no 33ms freeze, no teleports on fast drags). One transitionend listener per element
// (replaced per pass); it clears the inline transition only while still the latest pass.
function applyFlipFrom(firstRects) {
  const ms = window.blatamFx && window.blatamFx.slideMs;
  if (!ms) return;
  const pending = [];
  for (const entry of firstRects) {
    const el = entry[0], fr = entry[1];
    if (!el.isConnected || el.style.display === 'none') continue;
    const post = el.getBoundingClientRect();
    const cs = getComputedStyle(el).transform;
    const m = (cs && cs !== 'none') ? cs.match(/matrix\(([^)]+)\)/) : null;
    const tx = m ? (parseFloat(m[1].split(',')[4]) || 0) : 0;
    const ty = m ? (parseFloat(m[1].split(',')[5]) || 0) : 0;
    const dx = fr.left - (post.left - tx);
    const dy = fr.top - (post.top - ty);
    if (Math.abs(dx) < 0.5 && Math.abs(dy) < 0.5) continue;
    pending.push([el, dx, dy]);
  }
  if (!pending.length) return;
  for (const p of pending) {
    p[0].style.transition = 'none';
    p[0].style.transform = 'translate(' + p[1] + 'px,' + p[2] + 'px)';
  }
  for (const p of pending) { void p[0].offsetHeight; } // flush — commit the start values
  for (const p of pending) {
    const el = p[0];
    if (el.__flipClear) el.removeEventListener('transitionend', el.__flipClear);
    el.style.transition = 'transform ' + ms + 'ms ease';
    el.style.transform = '';
    const clear = (ev) => {
      if (ev.propertyName !== 'transform') return;
      el.removeEventListener('transitionend', clear);
      if (el.__flipClear === clear) el.style.transition = '';
    };
    el.__flipClear = clear;
    el.addEventListener('transitionend', clear);
  }
}


// Commits a card drop at coordinates (pointer path): target —
// document.elementFromPoint. Mirrors the HTML5 drop handlers:
// .gbar / .group-empty-slot — the tab goes INTO the group (place-tab /
// place-tabs, end of list), .space-chip — INTO the space (moveTabTo), inside
// #tabs-list — INTO the ghost slot (placeCardToSlot). Returns {rect} — the
// destination rect for the clone settle animation, or null when the point is
// not a valid card drop target (cancel).
function commitCardDropAt(clientX, clientY) {
  if (!dragSourceUrl || dragSourceGroupId) return null;
  const t = document.elementFromPoint(clientX, clientY);
  if (!t || !t.closest) return null;
  const src = allTabs.find(tb => tb.url === dragSourceUrl);
  if (!src) return null;
  const moveIntoGroup = (gid) => {
    const batch = dragBatchUrls && dragBatchUrls.length > 1 ? dragBatchUrls : null;
    if (batch) {
      if (batch.some(u => {
        const tb = allTabs.find(x => x.url === u);
        return !tb || tabGroupOf(tb) !== gid;
      })) chrome.runtime.sendMessage({ action: 'place-tabs', urls: batch,
        anchorUrl: null, side: 'after', groupId: gid });
    } else if (src.groupId !== gid) {
      chrome.runtime.sendMessage({ action: 'place-tab', index: allTabs.indexOf(src),
        anchorIndex: null, side: 'after', groupId: gid });
    }
    // Свернутая группа (шапка/слот принимает карточку): разворачиваем
    expandGroupForDrop(gid);
  };
  const gbar = t.closest('.gbar');
  if (gbar) {
    // The false click on the header is born in this moment (before dragend of
    // the source) — arm the one-shot suppression and take the warm ghost away
    // (like the HTML5 drop on the header does)
    pendingGbarClickAfterDrag = true;
    const rect = gbar.getBoundingClientRect();
    removeGhostSlot();
    // Only an empty/collapsed group (no visible cards) accepts a card
    if (!groupVisibleCardCount(gbar.dataset.groupId)) moveIntoGroup(gbar.dataset.groupId);
    return { rect };
  }
  const slot = t.closest('.group-empty-slot');
  if (slot) {
    const rect = slot.getBoundingClientRect();
    removeGhostSlot();
    moveIntoGroup(slot.dataset.groupId);
    return { rect };
  }
  const chip = t.closest('.space-chip');
  if (chip) {
    const rect = chip.getBoundingClientRect();
    chip.classList.remove('drag-over');
    const batch = dragBatchUrls;
    if (batch && batch.length > 1) {
      for (const u of batch) {
        const tb = allTabs.find(x => x.url === u);
        if (tb) moveTabTo(tb, chip.dataset.spaceId, undefined);
      }
    } else moveTabTo(src, chip.dataset.spaceId, undefined);
    return { rect };
  }
  const rail = t.closest('#rail-right');
  if (rail) {
    if (railRight) railRight.classList.remove('rail-drag-over'); // тёплый тон снят (endCardDrag — страховка)
    // Карточка → рейка: сайт открывается новой фоновой вкладкой, сама
    // карточка не тронута (без записи в storage). Слота в сетке нет — клон
    // «приземляется» у курсора (rect размером с карточку под курсором).
    // Исходник скрыт во время драга (display:none) — rect снят при захвате
    const w = (dragCardSize && dragCardSize.w) ? dragCardSize.w : 160;
    const h = (dragCardSize && dragCardSize.h) ? dragCardSize.h : 84;
    const urls = (dragBatchUrls && dragBatchUrls.length > 1) ? dragBatchUrls : [src.url];
    openSavedUrlsInBackground(urls);
    removeGhostSlot();
    return { rect: { left: clientX - w / 2, top: clientY - h / 2, width: w, height: h } };
  }
  // Пустая полоса сетки (между строками карточек) — not a valid card drop
  // target: cancel (clone settles home, no storage write)
  if (cardAreaEmptyBand(clientX, clientY)) return null;
  if (!tabsList.contains(t)) return null;
  // The ghost slot (when visible) is the destination: measure BEFORE the
  // commit — the commit re-renders and removes the ghost
  let rect = null;
  if (dragGhostSlot && dragGhostSlot.isConnected && dragGhostSlot.style.display !== 'none')
    rect = dragGhostSlot.getBoundingClientRect();
  placeCardToSlot(src, cursorCardAnchor(clientX, clientY));
  removeGhostSlot();
  return { rect };
}

// === Pointer drag (real Chrome UX) ===
// The pointer path replaces the native HTML5 drag image: press on the card +
// move over 8 px — the original disappears from its slot (warm ghost slot in
// its place), a LIFT CLONE (fixed-position copy of the card, scale liftScale
// + drop shadow) tracks the cursor 1:1, the ghost slot walks the grid
// (siblings — FLIP slide of slideMs). On release the state commits
// synchronously and the clone "lands" in the destination over settleMs
// (fade + scale to 0.96). Escape / release outside a drop target — cancel
// (clone returns to the original slot). The HTML5 path (dragstart/dragover/
// drop/dragend) stays for the synthetic test harness.
let pd = null; // active press: {tab, card, rect, startX, startY, ox, oy, armed}
let pdClone = null; // lift clone (copy of the card, position:fixed, in body)
let pdLastAnchor = null; // last ghost-slot anchor (FLIP-pass dedup)
let gpd = null; // group-header pointer press: {g, bar, homeRect, sectionEls, ghostSlot, ghostHeight, lastGap, startX, startY, ox, oy, armed}
// Свой pointer-путь обрабатывает press на элементе (ставится на pointerdown
// pointer-путём шапки группы / рейки — более поздние волны): guard в dragstart
// убивает trusted нативный драг. Синтетическая цепочка харнесса (untrusted)
// всегда проходит
let gbarPointerPress = false;
let railPointerPress = false;
// Живой pointer-драг ЧУЖОГО элемента (карточка — pd, чип — pcd, рейка — btl;
// состояние гbar добавится в его волне): пересекающий trusted dragstart
// гасится, чтобы не украсть drag-source из-под идущего pointer-драга
function pdForeignActive() {
  return !!(pd && pd.armed) || !!(pcd && pcd.armed) || !!(btl && btl.armed) || !!(gpd && gpd.armed);
}

// Press target is a nested interactive element (button/checkbox/link/label) —
// do not arm the drag (hover controls keep their own job)
function pdInteractiveTarget(el) {
  return !!(el instanceof Element && el.closest('button, input, a, label'));
}

function pdScale() { return (window.blatamFx && window.blatamFx.liftScale) || 1.02; }
function pdSettleMs() { const v = window.blatamFx && window.blatamFx.settleMs; return v == null ? 180 : v; }

// Toby-style autoScroll (original: DndContext autoScroll): during an armed pointer-drag,
// a cursor within 40px of the top/bottom edge of the scrollable container holding the
// cursor (fallback: the source element) scrolls THAT container — linear ramp, up to 20px
// per pointermove. Returns true when it scrolled (caller re-tracks at the same point —
// the geometry moved).
const PD_SCROLL_EDGE = 40, PD_SCROLL_SPEED = 20;
function pdFindScroller(el) {
  let c = el;
  while (c && c !== document.body && c !== document.documentElement) {
    const st = getComputedStyle(c);
    if ((st.overflowY === 'auto' || st.overflowY === 'scroll') && c.scrollHeight > c.clientHeight) return c;
    c = c.parentElement;
  }
  return null;
}
function pdAutoScrollAt(clientX, clientY, sourceEl) {
  const t = document.elementFromPoint(clientX, clientY) || sourceEl;
  const c = t ? pdFindScroller(t) : null;
  if (!c) return false;
  const r = c.getBoundingClientRect();
  let dy = 0;
  if (clientY > r.bottom - PD_SCROLL_EDGE) {
    dy = Math.min(1, (clientY - (r.bottom - PD_SCROLL_EDGE)) / PD_SCROLL_EDGE) * PD_SCROLL_SPEED;
  } else if (clientY < r.top + PD_SCROLL_EDGE) {
    dy = -Math.min(1, ((r.top + PD_SCROLL_EDGE) - clientY) / PD_SCROLL_EDGE) * PD_SCROLL_SPEED;
  }
  if (!dy) return false;
  const ns = Math.max(0, Math.min(c.scrollHeight - c.clientHeight, c.scrollTop + dy));
  if (ns === c.scrollTop) return false;
  c.scrollTop = ns;
  return true;
}

function pdCloneXf(x, y) {
  return 'translate3d(' + x + 'px,' + y + 'px,0) scale(' + pdScale() + ')';
}

// LIFT CLONE: a fixed-position copy of the card (no id; cloneNode copies no
// listeners), card-sized, under the cursor, no transition while dragging
function pdCreateClone(card, rect, x, y) {
  const clone = card.cloneNode(true);
  clone.id = '';
  clone.classList.add('pd-clone');
  clone.style.cssText = 'position:fixed;top:0;left:0;margin:0;box-sizing:border-box;' +
    'width:' + rect.width + 'px;height:' + rect.height + 'px;overflow:hidden;' +
    'z-index:2147483000;pointer-events:none;transition:none;will-change:transform;' +
    'transform:' + pdCloneXf(x, y) +
    ';filter:drop-shadow(0 6px 14px rgba(0,0,0,0.18))';
  document.body.appendChild(clone);
  return clone;
}

function pdCloneMove(x, y) {
  if (pdClone) pdClone.style.transform = pdCloneXf(x, y);
}

// Clone finish: over `ms` — move to the rect, fade out, scale to 0.96 (curve
// cubic-bezier(0.22, 1, 0.36, 1)); ms=0 — removed immediately.
function pdFinishClone(rect, ms) {
  const clone = pdClone;
  pdClone = null;
  if (!clone || !clone.isConnected) return;
  const C = 'cubic-bezier(0.22, 1, 0.36, 1)';
  const finish = () => { if (clone.isConnected) clone.remove(); };
  if (!ms || !rect) { clone.remove(); return; }
  clone.style.transition = 'transform ' + ms + 'ms ' + C + ',opacity ' + ms + 'ms ' + C +
    ',width ' + ms + 'ms ' + C + ',height ' + ms + 'ms ' + C;
  clone.style.transform = 'translate3d(' + rect.left + 'px,' + rect.top + 'px,0) scale(0.96)';
  clone.style.width = rect.width + 'px';
  clone.style.height = rect.height + 'px';
  clone.style.opacity = '0';
  clone.addEventListener('transitionend', (ev) => { if (ev.propertyName === 'transform') finish(); });
  setTimeout(finish, ms + 80); // fallback: remove even if transitionend does not fire
}

function pdTeardown() {
  window.removeEventListener('pointermove', pdOnMove);
  window.removeEventListener('pointerup', pdOnUp);
  window.removeEventListener('pointercancel', pdOnCancel);
  window.removeEventListener('keydown', pdOnKey);
  document.body.style.cursor = '';
}

// Cancel: no commit — the card returns to its slot, the clone "goes home"
function pdCancelEnd() {
  endCardDrag(pd.card);
  pdFinishClone(pd.rect, pdSettleMs());
  pd = null;
}

function pdOnKey(e) {
  if (!pd || !pd.armed || e.key !== 'Escape') return;
  pdTeardown();
  pdCancelEnd();
}

function pdOnCancel(e) {
  if (!pd) return;
  const armed = pd.armed;
  pdTeardown();
  if (armed) pdCancelEnd();
  else pd = null;
}

function pdOnUp(e) {
  if (!pd) return;
  const armed = pd.armed;
  const cardEl = pd.card;
  const homeRect = pd.rect;
  pdTeardown();
  if (!armed) { pd = null; return; } // plain press — the click passes through
  const info = commitCardDropAt(e.clientX, e.clientY);
  endCardDrag(cardEl);
  // Committed — the clone "lands" in the destination; not a valid target —
  // it returns home
  pdFinishClone(info && info.rect ? info.rect : homeRect,
    pdSettleMs());
  pd = null;
}

function pdOnMove(e) {
  if (!pd) return;
  if (!pd.armed) {
    const dx = e.clientX - pd.startX, dy = e.clientY - pd.startY;
    if (dx * dx + dy * dy <= 8 * 8) return; // not a drag until over 8 px
    pd.armed = true;
    pdLastAnchor = null;
    beginCardDrag(pd.tab, pd.card, true);
    pdClone = pdCreateClone(pd.card, pd.rect, e.clientX - pd.ox, e.clientY - pd.oy);
    // Armed: cursor grabbing on body and on the card
    document.body.style.cursor = 'grabbing';
    if (pd.card.isConnected) pd.card.style.cursor = 'grabbing';
  }
  e.preventDefault();
  pdCloneMove(e.clientX - pd.ox, e.clientY - pd.oy);
  pdAutoScrollAt(e.clientX, e.clientY, pd.card);
  trackCardDragAt(e.clientX, e.clientY);
}

function pdBindCard(card, tab) {
  card.addEventListener('pointerdown', (e) => {
    if (e.button !== 0) return;
    if (card.dataset.pressBtn || pdInteractiveTarget(e.target)) return;
    const rect = card.getBoundingClientRect();
    pd = { tab, card, rect, startX: e.clientX, startY: e.clientY,
           ox: e.clientX - rect.left, oy: e.clientY - rect.top, armed: false };
    window.addEventListener('pointermove', pdOnMove);
    window.addEventListener('pointerup', pdOnUp);
    window.addEventListener('pointercancel', pdOnCancel);
    window.addEventListener('keydown', pdOnKey);
  });
}
// === Pointer drag of group headers (real Chrome UX) — wave 2 «grab feel», wave 3 «gap ghost» ===
// Шапка группы (.gbar): press по имени/чепрону (не по hover-кнопкам) + движение
// больше 8 px — нативный HTML5-drag убивается (guard в dragstart: gbarPointerPress),
// ЦЕЛОЕ отделение группы (gbar + все её .tab-card + её .group-empty-slot) вырывается
// из потока (display:none), всё ниже сдвигается FLIP-проходом (applyFlipFrom,
// slideMs 200ms ease), под курсором компактный header-pill клон (.pd-clone в body,
// position:fixed) 1:1. ЕДИНСТВЕННЫЙ индикатор вставки — тёплая полноширинная
// .gbar-ghost-slot высотой вырванного отделения: ХОДИТ ПО ЗАЗОРАМ между групповыми
// секциями (границы — layout-геометрия layoutRect: верх первой секции, середины
// межсекционных зазоров, низ последней секции), остальные группы «разъезжаются»
// FLIP-слайдом при смене зазора. Seam-индикаторы волны 1 (.drop-before/
// .drop-after, --gbar-seam) в pointer-пути НЕ ставятся — они остались для
// синтетической HTML5-цепочки харнесса.
// Отпускание: внутри #tabs-list — reorderGroups по ТЕКУЩЕМУ зазору заглушки
// (gpd.lastGap: before/after; запись в blattam-groups); вне списка / других
// групп нет — cancel (renderTabs восстанавливает раскладку, клон «возвращается
// домой» за settleMs). Escape — cancel. Обычный клик (без движения) по-прежнему
// сворачивает/разворачивает группу (click-хендлер не тронут).
// Своё состояние (gpd) + gpd.armed в pdForeignActive. pdCreateClone/pdCloneMove/
// pdFinishClone/pdSettleMs/applyFlipFrom/pdAutoScrollAt/reorderGroups/layoutRect —
// общие (pdClone-переменная — безопасно: драг один). Синтетическая HTML5-цепочка
// (не-trusted DragEvents) идёт своим dragstart.
// Всё отделение группы g в #tabs-list: gbar + её .tab-card (DOM-порядок) +
// .group-empty-slot (если есть). Порядок: gbar → карточки → слот.
function gpdSectionEls(g) {
  const list = document.getElementById('tabs-list');
  const out = [];
  const bar = list && list.querySelector('.gbar[data-group-id="' + g.id + '"]');
  if (bar) out.push(bar);
  if (list) {
    list.querySelectorAll('.tab-card').forEach(c => { if (c.__tab && c.__tab.groupId === g.id) out.push(c); });
    const slot = list.querySelector('.group-empty-slot[data-group-id="' + g.id + '"]');
    if (slot) out.push(slot);
  }
  return out;
}

// FLIP-снапшот ВСЕХ видимых section-level элементов #tabs-list, КРОМЕ группы
// gpd.g.id (карточки, шапки, loose-метки, слоты). Геометрия — layoutRect (без
// вполёте FLIP-трансформов: gap-правило детерминировано во время 200ms-слайда).
// .gbar-ghost-slot не включается (селектор не ловит; сама заглушка FLIP-ом не
// трансформируется).
function gpdFlipSnapshot() {
  const m = new Map();
  document.querySelectorAll('#tabs-list .tab-card, #tabs-list .gbar, #tabs-list .loose-label, #tabs-list .group-empty-slot').forEach(el => {
    if (getComputedStyle(el).display === 'none') return;
    const id = el.__tab ? tabGroupOf(el.__tab) : (el.dataset.groupId || null);
    if (id === gpd.g.id) return;
    m.set(el, layoutRect(el));
  });
  return m;
}

// Тёплая полноширинная заглушка ВЫСОТОЙ вырванного отделения группы (height —
// инлайн, box-sizing border-box) — единственный индикатор вставки pointer-драга
// группы. grid-column 1/-1 даёт класс .gbar-ghost-slot (view.html); инлайн-токены
// --ghost-bg/--ghost-ring — в тестах head-стили view.html не грузятся целиком.
// pointer-events:none — курсор «видит сквозь» заглушку.
function makeGroupGhostSlot(height) {
  const slot = document.createElement('div');
  slot.className = 'gbar-ghost-slot';
  slot.draggable = false;
  slot.style.cssText =
    'box-sizing:border-box;pointer-events:none;background:var(--ghost-bg);' +
    'border-width:1px;border-style:dashed;border-color:var(--ghost-ring);' +
    'border-radius:6px;width:100%;' + 'height:' + height + 'px';
  return slot;
}

// Групповые секции #tabs-list БЕЗ excludeGid (DOM-порядок). Секция начинается на
// .gbar и включает следующих .tab-card/.group-empty-slot до следующей .gbar /
// .loose-label / #add-group-btn. У каждой: gbar, gid, lastEl (последняя
// .tab-card, иначе .group-empty-slot, иначе сама gbar), top/bottom — layoutRect.
function gpdGroupSections(excludeGid) {
  const list = document.getElementById('tabs-list');
  const out = [];
  if (!list) return out;
  let cur = null;
  for (const el of list.children) {
    if (el.classList.contains('gbar')) {
      cur = (el.dataset.groupId && el.dataset.groupId !== excludeGid)
        ? { gbar: el, gid: el.dataset.groupId, lastEl: el } : null;
      if (cur) out.push(cur);
      continue;
    }
    if (el.classList.contains('loose-label') || el.id === 'add-group-btn') { cur = null; continue; }
    if (cur && (el.classList.contains('tab-card') || el.classList.contains('group-empty-slot'))) cur.lastEl = el;
  }
  for (const s2 of out) {
    s2.top = layoutRect(s2.gbar).top;
    s2.bottom = layoutRect(s2.lastEl).bottom;
  }
  return out;
}

// Якорь вставки в ЗАЗОРЕ под курсором (null, если других групп нет). Границы —
// layout-геометрия: верх первой секции, середины межсекционных зазоров, низ
// последней; g = число границ <= clientY (0..M+1): g <= M-1 — перед секцией g,
// иначе — после последней (нижняя кромка списка).
function gpdGapAnchor(clientY) {
  const secs = gpdGroupSections(gpd.g.id);
  const M = secs.length;
  if (M === 0) return null;
  const edges = [secs[0].top];
  for (let i = 0; i < M - 1; i++) edges.push((secs[i].bottom + secs[i + 1].top) / 2);
  edges.push(secs[M - 1].bottom);
  let g = 0;
  while (g < edges.length && edges[g] <= clientY) g++;
  const anchor = (g <= M - 1)
    ? { el: secs[g].gbar, side: 'before', toId: secs[g].gid }
    : { el: secs[M - 1].lastEl, side: 'after', toId: secs[M - 1].gid };
  return anchor;
}

// Передвинуть уже вставленную тёплую заглушку к якорю (before/after элемента);
// соседи сдвигаются естественным reflow сетки — FLIP-проход у вызывающего.
function gpdMoveGhostSlot(anchor) {
  if (!gpd || !gpd.ghostSlot || !gpd.ghostSlot.isConnected) return;
  if (anchor.side === 'before') anchor.el.before(gpd.ghostSlot);
  else anchor.el.after(gpd.ghostSlot);
}
// Вставить (первый раз — заглушка ещё не в DOM) / передвинуть тёплую заглушку
// к якорю — без isConnected-guard (первая вставка создаёт подключение).
function gpdMoveGhostSlotInsert(anchor) {
  if (!gpd || !gpd.ghostSlot) return;
  if (anchor.side === 'before') anchor.el.before(gpd.ghostSlot);
  else anchor.el.after(gpd.ghostSlot);
}

// Снять тёплую заглушку (каждый выход: commit/cancel/teardown — следов нет).
function removeGroupGhostSlot() {
  if (gpd && gpd.ghostSlot && gpd.ghostSlot.isConnected) gpd.ghostSlot.remove();
  if (gpd) gpd.ghostSlot = null;
}

function gpdTeardown() {
  window.removeEventListener('pointermove', gpdOnMove);
  window.removeEventListener('pointerup', gpdOnUp);
  window.removeEventListener('pointercancel', gpdOnCancel);
  window.removeEventListener('keydown', gpdOnKey);
  document.body.style.cursor = '';
  if (gpd) gpd.bar.draggable = true; // возвращаем флаг после pointer-взаимодействия
  gbarPointerPress = false;
  removeGroupGhostSlot(); // тёплая заглушка не переживает ни один выход
}

// Cancel: renderTabs восстанавливает раскладку (yank отменён), ложный клик по
// шапке после отмены подавляется, клон «возвращается домой» за settleMs.
function gpdCancelEnd() {
  removeGroupGhostSlot();
  renderTabs();
  pendingGbarClickAfterDrag = true;
  lastDragEndAt = Date.now();
  pdFinishClone(gpd.homeRect, pdSettleMs());
  gpd = null;
}

function gpdOnKey(e) {
  if (!gpd || !gpd.armed || e.key !== 'Escape') return;
  gpdTeardown();
  gpdCancelEnd();
}

function gpdOnCancel(e) {
  if (!gpd) return;
  const armed = gpd.armed;
  gpdTeardown();
  if (armed) gpdCancelEnd();
  else gpd = null;
}

// Release: внутри #tabs-list — reorderGroups по ТЕКУЩЕМУ зазору заглушки
// (gpd.lastGap: before/after); вне списка / других групп нет — cancel
// (renderTabs + клон домой). plain press — клик по шапке сворачивает/
// разворачивает (подавляющих флагов НЕ ставим).
function gpdOnUp(e) {
  if (!gpd) return;
  const armed = gpd.armed;
  const homeRect = gpd.homeRect;
  let destRect = homeRect;
  let committed = false;
  if (armed) {
    // rect заглушки — до teardown (teardown её снимает)
    const t = document.elementFromPoint(e.clientX, e.clientY);
    const inList = t && (t === tabsList || tabsList.contains(t));
    const anchor = gpd.lastGap;
    // Топ-зона: у списка нет top-padding (только padding-bottom 110px), поэтому
    // «перед первой группой» внутри списка недостижимо, когда первая секция —
    // на еговерху. Полоса 24px над верхом списка в пределах ширины колонки +
    // заглушка ПЕРЕД ПЕРВОЙ секцией — коммит «перед первой» (сама заглушка
    // стоит вверху списка и сдвигает первую секцию вниз — сравнивать верха
    // нельзя, только позицию якоря); выше полосы / вне ширины — cancel.
    const lr = tabsList.getBoundingClientRect();
    const gpdSecs = gpdGroupSections(gpd.g.id);
    const inTopBand = !inList && anchor && anchor.side === 'before' &&
      gpdSecs.length > 0 && anchor.el === gpdSecs[0].gbar &&
      e.clientY >= lr.top - 24 && e.clientY < lr.top &&
      e.clientX >= lr.left && e.clientX <= lr.right;
    if ((inList || inTopBand) && anchor && anchor.toId && anchor.toId !== gpd.g.id) {
      if (gpd.ghostSlot && gpd.ghostSlot.isConnected) destRect = gpd.ghostSlot.getBoundingClientRect();
      committed = true;
    }
  }
  gpdTeardown();
  if (!armed) { gpd = null; return; }
  if (committed) {
    // no-op-коммит (дроп в собственный слот — порядок не изменился):
    // reorderGroups не пишет, а в реальном Chrome set равного значения не
    // шлёт onChanged → перерисовки не будет — вырванное отделение осталось
    // бы display:none до чужой записи. renderTabs восстанавливает раскладку,
    // клон возвращается домой (как cancel)
    const wrote = reorderGroups(gpd.g.id, gpd.lastGap.toId, gpd.lastGap.side);
    if (!wrote) { renderTabs(); destRect = homeRect; }
    pendingGbarClickAfterDrag = true;
    lastDragEndAt = Date.now();
  } else {
    renderTabs();
    pendingGbarClickAfterDrag = true;
    lastDragEndAt = Date.now();
  }
  removeGroupGhostSlot();
  pdFinishClone(destRect, pdSettleMs());
  gpd = null;
}

function gpdOnMove(e) {
  if (!gpd) return;
  if (!gpd.armed) {
    const dx = e.clientX - gpd.startX, dy = e.clientY - gpd.startY;
    if (dx * dx + dy * dy <= 64) return; // not a drag until over 8 px
    gpd.armed = true;
    // Высота вырванного отделения — до скрытия (gbar → последняя карточка/слот)
    const srcSecs = gpdSectionEls(gpd.g);
    gpd.ghostHeight = srcSecs.length === 0 ? 0
      : (layoutRect(srcSecs[srcSecs.length - 1]).bottom - layoutRect(srcSecs[0]).top);
    const firstRects = gpdFlipSnapshot();
    for (const el of srcSecs) el.style.display = 'none'; // yank-out целого отделения
    if (gpd.ghostHeight > 0) {
      gpd.ghostSlot = makeGroupGhostSlot(gpd.ghostHeight);
      const anchor = gpdGapAnchor(e.clientY);
      if (anchor) { gpdMoveGhostSlotInsert(anchor); gpd.lastGap = anchor; }
    }
    applyFlipFrom(firstRects); // всё ниже сдвигается (slideMs ease)
    pdClone = pdCreateClone(gpd.bar, gpd.homeRect, e.clientX - gpd.ox, e.clientY - gpd.oy);
    document.body.style.cursor = 'grabbing';
  }
  e.preventDefault();
  pdCloneMove(e.clientX - gpd.ox, e.clientY - gpd.oy);
  pdAutoScrollAt(e.clientX, e.clientY, gpd.bar);
  // Тёплая заглушка ходит по зазорам; parting-FLIP — только при смене якоря
  const anchor = gpdGapAnchor(e.clientY);
  if (anchor && gpd.ghostSlot && gpd.ghostSlot.isConnected &&
      (!gpd.lastGap || gpd.lastGap.toId !== anchor.toId || gpd.lastGap.side !== anchor.side)) {
    const firstRects = gpdFlipSnapshot();
    gpdMoveGhostSlotInsert(anchor);
    applyFlipFrom(firstRects);
    gpd.lastGap = anchor;
  }
}

function gpdBindGbar(bar, g) {
  bar.addEventListener('pointerdown', (e) => {
    if (e.button !== 0) return;
    if (bar.dataset.pressBtn || pdInteractiveTarget(e.target)) return; // hover-кнопки держат свой клик
    const rect = bar.getBoundingClientRect();
    gpd = { g, bar, homeRect: rect, sectionEls: null, ghostSlot: null, ghostHeight: 0, lastGap: null,
            startX: e.clientX, startY: e.clientY,
            ox: e.clientX - rect.left, oy: e.clientY - rect.top, armed: false };
    gbarPointerPress = true;
    bar.draggable = false; // pointer-путь владеет press — нативный drag не инициируется
    window.addEventListener('pointermove', gpdOnMove);
    window.addEventListener('pointerup', gpdOnUp);
    window.addEventListener('pointercancel', gpdOnCancel);
    window.addEventListener('keydown', gpdOnKey);
  });
}

// === Pointer drag of space chips (real Chrome UX) ===
// Chip-путь зеркалирует карточный: press по чипу + движение больше 8 px —
// нативный drag-образ отменяется (dragstart чипа: preventDefault + e.isTrusted),
// оригинал исчезает из ряда (тёплая .space-ghost-slot в его месте, синхронно —
// без setTimeout), LIFT-КЛОН (.pd-clone в body, position:fixed, liftScale +
// тень) следует за курсором 1:1, ghost-slot ходит по ряду с FLIP-слайдом
// соседних чипов (slideMs). Отпускание: на чип — reorderSpaces (левая/правая
// половина цели), на ряд (зазор/«+ Пространство») — по ТЕКУЩЕЙ DOM-позиции
// заглушки (то же правило, что row-drop), в остальном — cancel (без записи);
// клон «приземляется» в цель за settleMs, при cancel — возвращается домой.
// Escape — cancel. Обычный клик (без движения) по-прежнему переключает
// пространство (click-хендлер не тронут). Своё состояние (pcd) — не пересекается
// с card path (одна мышь); pdCreateClone/pdCloneMove/pdFinishClone/pdScale/
// pdSettleMs/applyFlipFrom общие (pdClone-переменная — безопасно: драг один).
// Синтетическая HTML5-цепочка (не-trusted DragEvents) идёт своим dragstart.
let pcd = null; // active press: {spId, chip, homeRect, startX, startY, ox, oy, armed, lastAnchor}

// .space-chip под точкой (elementFromPoint — клон/заглушка pointer-events:none,
// «видят сквозь» курсор)
function pcdChipAt(x, y) {
  const t = document.elementFromPoint(x, y);
  return t && t.closest ? t.closest('.space-chip') : null;
}

function pcdTeardown() {
  window.removeEventListener('pointermove', pcdOnMove);
  window.removeEventListener('pointerup', pcdOnUp);
  window.removeEventListener('pointercancel', pcdOnCancel);
  window.removeEventListener('keydown', pcdOnKey);
  document.body.style.cursor = '';
}

// Cancel: чип возвращается в ряд, заглушка снята, клон «возвращается домой»
// (p — состояние драга; передаётся из pcdOnUp, где pcd уже обнулён)
function pcdCancelState(p) {
  p = p || pcd;
  pcd = null;
  dragSourceSpaceId = null;
  removeSpaceGhostSlot();
  if (p.chip.isConnected) p.chip.style.display = '';
  pdFinishClone(p.homeRect, pdSettleMs());
}

function pcdOnKey(e) {
  if (!pcd || !pcd.armed || e.key !== 'Escape') return;
  pcdTeardown();
  pcdCancelState();
}

function pcdOnCancel(e) {
  if (!pcd) return;
  const armed = pcd.armed;
  pcdTeardown();
  if (armed) pcdCancelState();
  else pcd = null;
}

// Release: over a chip — reorderSpaces (side by X-half); over the row — commit
// ghost's CURRENT DOM position (neighbouring .space-chip; «+ Пространство»/null
// — not a target; no-op-guard — внутри reorderSpaces); elsewhere — null (cancel).
// Rects измеряются ДО commit — commit ре-рендерит чипы и снимает заглушку.
function pcdCommitAt(x, y, p) {
  const fromId = p.spId;
  const chipEl = pcdChipAt(x, y);
  if (chipEl) {
    // скрытый источник не попадает под курсор — дроп в собственный слот
    // уходит в row-ветку ниже (заглушка дома — no-op)
    const rect = chipEl.getBoundingClientRect();
    reorderSpaces(fromId, chipEl.dataset.spaceId, reorderSideX(chipEl, x));
    return rect;
  }
  const t = document.elementFromPoint(x, y);
  if (t && t.closest && t.closest('#spaces-bar')) {
    const slot = dragGhostChipSlot;
    const rect = (slot && slot.isConnected) ? slot.getBoundingClientRect() : p.homeRect;
    if (slot && slot.isConnected) {
      const next = slot.nextElementSibling;
      const prev = slot.previousElementSibling;
      if (next && next.classList.contains('space-chip')) {
        reorderSpaces(fromId, next.dataset.spaceId, 'before');
      } else if (prev && prev.classList.contains('space-chip')) {
        reorderSpaces(fromId, prev.dataset.spaceId, 'after');
      }
      // заглушка не у чипов (пустой ряд) — no-op
    }
    return rect;
  }
  return null;
}

function pcdOnUp(e) {
  if (!pcd) return;
  const armed = pcd.armed;
  const p = pcd;
  pcd = null;
  pcdTeardown();
  if (!armed) return; // plain press — the click passes through (switch space)
  const rect = pcdCommitAt(e.clientX, e.clientY, p);
  if (rect) {
    dragSourceSpaceId = null;
    removeSpaceGhostSlot();
    // no-op-коммит (порядок не изменился — reorderSpaces не записал):
    // перерисовки не было — чип возвращается в ряд сам
    if (p.chip.isConnected && p.chip.style.display === 'none') p.chip.style.display = '';
    pdFinishClone(rect, pdSettleMs()); // committed — клон «приземляется» в цель
  } else {
    pcdCancelState(p); // вне ряда — cancel
  }
}

// Ghost slot walks the row by the cursor: over a chip — before/after it by the
// half; when the anchor CHANGES — FLIP pass (rect snapshot of visible chips,
// excluding the hidden source, BEFORE the move → move ghost → applyFlipFrom);
// over the row — ghost keeps its DOM position; elsewhere — no anchor (a cancel
// candidate on release)
function pcdTrackAt(x, y) {
  const chipEl = pcdChipAt(x, y);
  if (chipEl) {
    const side = reorderSideX(chipEl, x);
    if (pcd.lastAnchor && pcd.lastAnchor.el === chipEl && pcd.lastAnchor.side === side) return;
    const firstRects = snapshotCardRects('#space-chips .space-chip', pcd.chip);
    moveSpaceGhostSlot({ el: chipEl, side: side });
    pcd.lastAnchor = { el: chipEl, side: side };
    applyFlipFrom(firstRects);
    return;
  }
  const t = document.elementFromPoint(x, y);
  pcd.lastAnchor = (t && t.closest && t.closest('#spaces-bar')) ? { row: true } : null;
}

function pcdOnMove(e) {
  if (!pcd) return;
  if (!pcd.armed) {
    const dx = e.clientX - pcd.startX, dy = e.clientY - pcd.startY;
    if (dx * dx + dy * dy <= 8 * 8) return; // not a drag until over 8 px
    // ARM: меряем rect и заглушку ДО display:none (у скрытого чипа 0-размеры),
    // прячем источник, тёплая заглушка дома, lift-клон под курсором
    const chip = pcd.chip;
    pcd.homeRect = chip.getBoundingClientRect();
    dragSourceSpaceId = pcd.spId;
    pendingChipClickAfterDrag = true; // ложный post-drag клик не переключает пространство
    const ghost = makeSpaceGhostSlot(chip);
    chip.insertAdjacentElement('afterend', ghost);
    dragGhostChipSlot = ghost;
    chip.style.display = 'none';
    pdClone = pdCreateClone(chip, pcd.homeRect, e.clientX - pcd.ox, e.clientY - pcd.oy);
    pcd.armed = true;
    pcd.lastAnchor = null;
    // Armed: cursor grabbing on body and on the chip
    document.body.style.cursor = 'grabbing';
    if (chip.isConnected) chip.style.cursor = 'grabbing';
  }
  e.preventDefault();
  pdCloneMove(e.clientX - pcd.ox, e.clientY - pcd.oy);
  pdAutoScrollAt(e.clientX, e.clientY, pcd.chip);
  pcdTrackAt(e.clientX, e.clientY);
}

function pcdBindChip(chip, spId) {
  chip.addEventListener('pointerdown', (e) => {
    if (e.button !== 0) return;
    const rect = chip.getBoundingClientRect();
    pcd = { spId: spId, chip: chip, homeRect: rect,
            startX: e.clientX, startY: e.clientY,
            ox: e.clientX - rect.left, oy: e.clientY - rect.top,
            armed: false, lastAnchor: null };
    window.addEventListener('pointermove', pcdOnMove);
    window.addEventListener('pointerup', pcdOnUp);
    window.addEventListener('pointercancel', pcdOnCancel);
    window.addEventListener('keydown', pcdOnKey);
  });
}



// 'before'/'after' — по позиции курсора относительно середины элемента
function reorderSide(card, clientY) {
  const rect = card.getBoundingClientRect();
  return (clientY == null || clientY <= rect.top + rect.height / 2) ? 'before' : 'after';
}

// 'before'/'after' — по курсору относительно ГОРИЗОНТАЛЬНОЙ середины
// элемента (reorder чипов пространств; вертикальная reorderSide для
// шапок групп не тронута)
function reorderSideX(el, clientX) {
  const rect = el.getBoundingClientRect();
  return (clientX == null || clientX <= rect.left + rect.width / 2) ? 'before' : 'after';
}

// Двойной клик по имени → инлайн-переименование
function startRename(tab, nameEl, body) {
  const input = document.createElement('input');
  input.type = 'text';
  input.className = 'tab-name-input';
  input.value = tab.name;
  input.autocomplete = 'off';
  nameEl.replaceWith(input);
  input.focus();
  input.select();

  let done = false;
  const finish = (save) => {
    if (done) return;
    done = true;
    const newName = input.value.trim();
    if (save && newName && newName !== tab.name) {
      chrome.runtime.sendMessage({ action: 'rename-tab', index: allTabs.indexOf(tab), name: newName });
    }
    renderTabs(searchInput.value);
  };

  input.addEventListener('click', (e) => e.stopPropagation());
  input.addEventListener('keydown', (e) => {
    e.stopPropagation();
    if (e.key === 'Enter') finish(true);
    if (e.key === 'Escape') finish(false);
  });
  input.addEventListener('blur', () => finish(true));
}

// === Массовое открытие ===

function updateSelectionBar() {
  const n = selectedUrls.size;
  selectionBar.classList.toggle('hidden', n === 0);
  selectionCount.textContent = t('selected_n', { n: n });
}



openSelectedBtn.addEventListener('click', () => {
  const urls = allTabs.filter(t => selectedUrls.has(t.url)).map(t => t.url);
  openMany(urls);
});

clearSelectionBtn.addEventListener('click', () => {
  selectedUrls.clear();
  renderTabs(searchInput.value);
});

// «Удалить» — массовое удаление выделенных вкладок: ВСЕ выделенные уходят
// в корзину (blattam-trash) БЕЗ confirm (возврат — через корзину), одна
// запись в storage, выбор снимается. Пустой выбор — no-op.
deleteSelectedBtn.addEventListener('click', () => {
  if (selectedUrls.size === 0) return;
  sendTabsToTrash(allTabs.filter(t => selectedUrls.has(t.url)));
});

// «Сбросить фильтры» — в состоянии «ничего не найдено»
const btnResetFilters = document.getElementById('btn-reset-filters');
if (btnResetFilters) {
  btnResetFilters.addEventListener('click', () => {
    searchInput.value = '';
    activeUrl = null;
    renderTabs('');
  });
}

// Поиск
searchInput.addEventListener('input', (e) => {
  renderTabs(e.target.value);
});

// === Keyboard navigation ===
// Стрелки — по карточкам, Enter — открыть, Delete — удалить, Esc — сброс.
// Не перехватывает, пока набран текст или открыта модалка.

function isEditable(el) {
  if (!el) return false;
  const tag = (el.tagName || '').toLowerCase();
  if (tag === 'input' || tag === 'textarea' || tag === 'select') return true;
  return el.isContentEditable === true;
}

// Движение по видимым карточкам: +1 / -1 шаг
function moveActive(delta) {
  const f = visibleTabs(searchInput.value);
  if (!f.length) return;
  let i = activeUrl ? f.findIndex(t => t.url === activeUrl) : -1;
  if (i === -1) i = delta < 0 ? f.length - 1 : 0; // нет активной → крайняя по направлению
  else i = (i + delta + f.length) % f.length; // зациклено
  activeUrl = f[i].url;
  renderTabs(searchInput.value);
}

function openActiveTab() {
  const f = visibleTabs(searchInput.value);
  const t = f.find(t => t.url === activeUrl) || f[0];
  if (t) openUrl(t.url);
}

function deleteActiveTab() {
  const f = visibleTabs(searchInput.value);
  const tab = f.find(t => t.url === activeUrl);
  if (!tab) return;
  // Без confirm: вкладка уходит в корзину (blattam-trash)
  sendTabsToTrash([tab]); // onChanged-обработчик обнулит activeUrl, если карточки не осталось
}

// Быстрый поиск: вспышка большой буквы в центре + потемнение окна.
// Каждое нажатие буквы перезапускает fade (CSS transition 650ms на .qs-overlay).
const qsOverlay = document.getElementById('qs-overlay');
const qsLetter = document.getElementById('qs-letter');
function qsFlash(ch) {
  if (!qsOverlay || !qsLetter) return;
  qsLetter.textContent = ch;
  qsOverlay.classList.add('show');
  void qsOverlay.offsetHeight; // reflow: при снятии .show перезапускается fade-переход
  qsOverlay.classList.remove('show');
}
function qsHide() {
  if (!qsOverlay) return;
  qsOverlay.style.transition = 'none';
  qsOverlay.classList.remove('show');
  void qsOverlay.offsetHeight;
  qsOverlay.style.transition = '';
}
// === Горячие клавиши (blattam-hotkeys, chrome.storage.local) ===
// 10 действий, каждое — список комбинаций. Канонический вид связки:
// [ctrl|alt|shift|meta]+ + key (одна буква — uppercase): 'ArrowDown', 'Enter',
// 'ctrl+k', '/'. Escape — зарезервирован (глобальный сброс), не привязывается.
// Дефолты = текущее поведение клавиатуры. Порядок HOTKEY_ACTIONS — при дубле
// связки побеждает первое действие.
const HOTKEY_ACTIONS = ['next', 'prev', 'open', 'delete', 'search', 'selectAll', 'newSpace', 'newGroup', 'theme', 'settings'];
const HOTKEY_DEFAULTS = {
  next: ['ArrowDown', 'ArrowRight'],
  prev: ['ArrowUp', 'ArrowLeft'],
  open: ['Enter'],
  delete: ['Delete', 'Backspace'],
  search: ['/'],
  selectAll: ['ctrl+a'],
  newSpace: [],
  newGroup: [],
  theme: [],
  settings: []
};
let hotkeyConfig = JSON.parse(JSON.stringify(HOTKEY_DEFAULTS));

function hotkeyComboFromEvent(e) {
  if (!e.key) return null;
  const mods = [];
  if (e.ctrlKey) mods.push('ctrl');
  if (e.altKey) mods.push('alt');
  if (e.shiftKey) mods.push('shift');
  if (e.metaKey) mods.push('meta');
  let key = e.key;
  return mods.length ? mods.join('+') + '+' + key : key;
}

const HK_GLYPHS = { ArrowDown: '↓', ArrowUp: '↑', ArrowLeft: '←', ArrowRight: '→', Delete: 'Del' };
function hotkeyComboDisplay(combo) {
  return combo.split('+').map((p) => {
    if (p === 'ctrl') return 'Ctrl';
    if (p === 'alt') return 'Alt';
    if (p === 'shift') return 'Shift';
    if (p === 'meta') return 'Meta';
    return HK_GLYPHS[p] || (p.length === 1 ? p.toUpperCase() : p);
  }).join('+');
}

function selectAllVisibleTabs() {
  selectedUrls = new Set(visibleTabs(searchInput.value).map((t) => t.url));
  renderTabs(searchInput.value);
}
function toggleThemeAction() {
  setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
}

const HOTKEY_RUN = {
  next: () => moveActive(1),
  prev: () => moveActive(-1),
  open: openActiveTab,
  delete: deleteActiveTab,
  search: () => { searchInput.focus(); searchInput.select(); },
  selectAll: selectAllVisibleTabs,
  newSpace: openNewSpaceModal,
  newGroup: createGroupInActiveSpace,
  theme: toggleThemeAction,
  settings: openSettingsModal
};

// Перерисовка значений строк (строки статичные в view.html; во время захвата
// — не трогаем)
function renderHotkeyRows() {
  HOTKEY_ACTIONS.forEach((action) => {
    const box = document.querySelector('.hk-box[data-action="' + action + '"]');
    if (!box || box.classList.contains('hk-armed')) return;
    const combos = hotkeyConfig[action] || [];
    const val = box.querySelector('.hk-val');
    const clearBtn = box.querySelector('.hk-clear');
    val.textContent = combos.length ? combos.map(hotkeyComboDisplay).join(' · ') : t('hk_none');
    val.classList.toggle('hk-empty', !combos.length);
    if (clearBtn) clearBtn.style.display = combos.length ? '' : 'none';
  });
}

// Захват: клик по строке → однострочный слушатель keydown на window (capture —
// раньше ВСЕХ document-слушателей: модалочные Escape-закрытия и глобальный
// keydown). Esc — отмена; одиночный модификатор — игнор; комбинация — dedup +
// запись storage.
let hkArmed = null;
function hkDisarm() {
  if (!hkArmed) return;
  const box = document.querySelector('.hk-box[data-action="' + hkArmed.action + '"]');
  if (box) box.classList.remove('hk-armed');
  window.removeEventListener('keydown', hkArmed.listener, true);
  hkArmed = null;
  renderHotkeyRows();
}
function hkArm(action) {
  hkDisarm();
  const box = document.querySelector('.hk-box[data-action="' + action + '"]');
  if (!box) return;
  box.classList.add('hk-armed');
  const val = box.querySelector('.hk-val');
  val.classList.remove('hk-empty');
  val.textContent = t('hk_press');
  const listener = (e) => {
    e.preventDefault();
    e.stopImmediatePropagation();
    if (e.key === 'Escape') { hkDisarm(); return; }
    if (e.key === 'Control' || e.key === 'Shift' || e.key === 'Alt' || e.key === 'Meta') return;
    const combo = hotkeyComboFromEvent(e);
    if (!combo) return;
    const list = hotkeyConfig[action] || (hotkeyConfig[action] = []);
    if (list.indexOf(combo) === -1) list.push(combo);
    chrome.storage.local.set({ 'blattam-hotkeys': hotkeyConfig });
    hkDisarm();
  };
  hkArmed = { action, listener };
  window.addEventListener('keydown', listener, true);
}

document.querySelectorAll('.hk-box').forEach((box) => {
  box.addEventListener('click', (e) => {
    if (e.target.closest('.hk-clear')) {
      e.stopPropagation();
      hkDisarm();
      hotkeyConfig[box.dataset.action] = [];
      chrome.storage.local.set({ 'blattam-hotkeys': hotkeyConfig });
      return; // onChanged перерисует
    }
    if (hkArmed && hkArmed.action === box.dataset.action) { hkDisarm(); return; }
    hkArm(box.dataset.action);
  });
});
const hkResetAllBtn = document.getElementById('hk-reset-all');
if (hkResetAllBtn) hkResetAllBtn.addEventListener('click', () => {
  hkDisarm();
  chrome.storage.local.remove(['blattam-hotkeys']);
  hotkeyConfig = JSON.parse(JSON.stringify(HOTKEY_DEFAULTS));
  renderHotkeyRows();
});

// Конфиг: init + onChanged (другие newtab-окна следуют за сменой; перерисовка
// карточек не нужна)
function applyHotkeyConfig(stored) {
  HOTKEY_ACTIONS.forEach((a) => {
    if (stored && Array.isArray(stored[a])) hotkeyConfig[a] = stored[a].slice();
  });
  renderHotkeyRows();
}
// Init — ПОСЛЕ готовности языка (loadLang): строки показывают t('hk_none')
// и зависят от I18N_LANG.
loadLang().then(() => chrome.storage.local.get(['blattam-hotkeys'], (r) => applyHotkeyConfig(r['blattam-hotkeys'])));

document.addEventListener('keydown', (e) => {
  // Модалка работает сама — не перехватываем
  if (spaceModal.classList.contains('open')) return;
  if (isAnyModalOpen()) return;

  // Esc — сброс: поиск, выбор и активная карточка (активное пространство НЕ
  // сбрасывается — нет «Все», к которому можно вернуться). Работает и из поля
  // (например, из поиска) — очищает его и снимает фокус.
  if (e.key === 'Escape') {
    qsHide();
    if (searchInput.value) searchInput.value = '';
    const ae = document.activeElement;
    if (ae && ae !== document.body) ae.blur();
    activeUrl = null;
    selectedUrls.clear();
    renderTabs('');
    e.preventDefault();
    return;
  }

  // Остальные клавиши не перехватываем, пока набирается текст
  if (isEditable(document.activeElement)) return;

  // Быстрый поиск: любая буква (лат/кир, с Shift или без) — в поиск,
  // вспышка буквы в центре. Цифры и символы не обрабатываются.
  if (quickSearchOn && e.key.length === 1 && /^[\p{L}]$/u.test(e.key)) {
    searchInput.value += e.key;
    renderTabs(searchInput.value);
    qsFlash(e.key);
    e.preventDefault();
    return;
  }
  if (quickSearchOn && e.key === 'Backspace' && searchInput.value) {
    searchInput.value = searchInput.value.slice(0, -1);
    renderTabs(searchInput.value);
    qsHide();
    e.preventDefault();
    return;
  }

  // Горячие клавиши: связка события → действие (blattam-hotkeys). Escape выше
  // (сброс), буквы быстрого поиска — не доходят до сюда.
  const hkCombo = hotkeyComboFromEvent(e);
  if (hkCombo) {
    for (let i = 0; i < HOTKEY_ACTIONS.length; i++) {
      const action = HOTKEY_ACTIONS[i];
      if ((hotkeyConfig[action] || []).indexOf(hkCombo) !== -1) {
        e.preventDefault();
        HOTKEY_RUN[action]();
        return;
      }
    }
  }
});

// === Автообновление ===

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'local') {
    // Вкладки — в local (migrate sync → local): в local реагируем только на blattam-tabs
    if (changes['blattam-tabs']) {
      const newTabs = changes['blattam-tabs'].newValue || [];
      const oldTabs = changes['blattam-tabs'].oldValue || [];
      // Группа потеряла последнюю вкладку — автосворачивание: вместо строки
      // «Перетащите вкладку сюда» — свёрнутая шапка с «0 вкладок» (свежесозданная
      // или вручную раскрытая пустая группа остаются раскрытыми — слот = цель дропа)
      let groupsEmptied = false;
      allGroups.forEach(g => {
        if (g.collapsed) return;
        const isMember = (t) => t && t.spaceId === g.spaceId && t.groupId === g.id;
        const before = oldTabs.filter(isMember).length;
        const after = newTabs.filter(isMember).length;
        if (before > 0 && after === 0) { g.collapsed = true; groupsEmptied = true; }
      });
      if (groupsEmptied) chrome.storage.sync.set({ 'blattam-groups': allGroups });
      // Реордер (набор URL тот же, изменился только порядок) — выбор и активная
      // карточка завязаны на URL, поэтому переживают перерисовку
      const sameUrlSet = oldTabs.length === newTabs.length &&
        oldTabs.map(t => t.url).sort().join('|') === newTabs.map(t => t.url).sort().join('|');
      allTabs = newTabs;
      if (!sameUrlSet) selectedUrls.clear(); // набор вкладок изменился — сброс выбора
      renderTabs(searchInput.value);
    }
    // «Корзина» (blattam-trash): записываем состояние, обновляем счётчик
    // рейки и открытую модалку. Сетку перерисовывает ветка blattam-tabs
    // (одна запись меняет оба ключа) — здесь только корзина.
    if (changes['blattam-trash']) {
      trashTabs = changes['blattam-trash'].newValue || [];
      updateTrashCount();
      if (trashModal && trashModal.classList.contains('open')) renderTrashList();
    }
    // Зеркало открытых вкладок (blattam-browser-tabs) — перерисовка рейки.
    // В драге рейки не перерисовываем (заглушка уйдёт из DOM) — dragend
    // перерисует.
    if (changes['blattam-browser-tabs']) {
      if (dragSourceBrowserTab) return;
      browserTabs = changes['blattam-browser-tabs'].newValue || [];
      renderBrowserTabs();
      return;
    }
    // «Фон»: применяем/снимаем картинку как при записи из настроек, так и
    // при внешнем изменении (другое окно расширения); идемпотентно,
    // перерисовка карточек не нужна.
    if (changes['blattam-bg-image']) {
      applyBackgroundImage(changes['blattam-bg-image'].newValue || '');
    }
    // «Тема» (blattam-theme): внешняя запись (другое окно) — применяем тему
    // и синхронизируем кнопки настроек; идемпотентно, перерисовка не нужна.
    if (changes['blattam-theme']) {
      applyTheme(changes['blattam-theme'].newValue || 'light');
      applyThemeButtons();
    }
    // «Фоны боковых реек»: применяем/снимаем картинку как у основного фона.
    if (changes['blattam-bg-image-left']) {
      applyRailBackgroundImage('left', changes['blattam-bg-image-left'].newValue || '');
    }
    if (changes['blattam-bg-image-right']) {
      applyRailBackgroundImage('right', changes['blattam-bg-image-right'].newValue || '');
    }
    // «Цвет вкладок» (blattam-tab-color): применяем/снимаем кастомный цвет;
    // идемпотентно (инлайн-стиль documentElement), перерисовка карточек не нужна.
    if (changes['blattam-tab-color']) {
      applyTabCardColor(changes['blattam-tab-color'].newValue || '');
    }
    // «Цвета»/«Размер и форма»/«Шрифт» (blattam-custom-theme): применяем/снимаем
    // кастомные токены (объект, либо null после удаления ключа).
    if (changes['blattam-custom-theme']) {
      applyCustomTheme(changes['blattam-custom-theme'].newValue || null);
    }
    // «Горячие клавиши» (blattam-hotkeys): обновляем конфиг + строки
    // настроек; перерисовка карточек не нужна.
    if (changes['blattam-hotkeys']) {
      applyHotkeyConfig(changes['blattam-hotkeys'].newValue || null);
    }
    // «Пресеты»: изменился любой из шести ключей внешнего вида — сверить активный
    // (значения не совпали — снять «активен»); список/активный изменились — обновить;
    // открытая модалка — перерисовать список.
    if (PRESET_KEYS.some((k) => changes[k]) || changes['blattam-presets'] || changes['blattam-active-preset']) {
      syncActivePreset();
      if (settingsModal.classList.contains('open')) renderPresetList();
    }
    return;
  }
  if (areaName !== 'sync') return;
// 

  if (changes['blattam-spaces']) {
    const newSpaces = changes['blattam-spaces'].newValue || [];
    allSpaces = newSpaces;
    // Активное пространство удалено (например, из другого окна) — переключаемся на первое
    if (!allSpaces.some(s => s.id === activeSpaceId) && allSpaces.length > 0) {
      activeSpaceId = allSpaces[0].id;
      chrome.storage.sync.set({ 'blattam-last-space': activeSpaceId });
    }
    renderSpaces();
    renderTabs(searchInput.value);
  }
  if (changes['blattam-groups']) {
    allGroups = changes['blattam-groups'].newValue || [];
    renderTabs(searchInput.value);
  }
});

// === Экспорт / Импорт (с пространствами и группами) ===

document.getElementById('export-btn').addEventListener('click', () => {
  const data = {
    'blatt-tabs': true,
    version: chrome.runtime.getManifest().version,
    exported: new Date().toISOString(),
    spaces: allSpaces,
    groups: allGroups,
    tabs: allTabs
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  a_click(url, `blatt-tabs-backup-${new Date().toISOString().slice(0, 10)}.json`);
  URL.revokeObjectURL(url);
});

function a_click(url, download) {
  const a = document.createElement('a');
  a.href = url;
  a.download = download;
  a.click();
}

document.getElementById('import-btn').addEventListener('click', () => {
  document.getElementById('import-input').click();
});

document.getElementById('import-input').addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (event) => {
    try {
      const data = JSON.parse(event.target.result);

      if (!data.tabs || !Array.isArray(data.tabs)) {
        alert(t('import_bad_format'));
        return;
      }

      // Файл без spaces/groups, но с legacy-«folders» — прогоняем ту же миграцию
      // папки → пространства перед слиянием (старые экспорты остаются импортируемыми)
      let fileSpaces = Array.isArray(data.spaces) ? data.spaces : null;
      let fileGroups = Array.isArray(data.groups) ? data.groups : [];
      const fileTabs = data.tabs;

      // С2.8: валидация импорта — небезопасные/чрезмерные данные НЕ импортируем
      // (alert и выход, ничего не записываем): только http/https, url ≤ 2048,
      // name ≤ 200, comment ≤ 1000, ≤ 5000 вкладок
      if (fileTabs.length > 5000) { alert(t('import_too_many_tabs')); return; }
      for (const tab of fileTabs) {
        if (!tab) continue; // не-объекты и так отбрасывает импорт-фильтр (t.url && t.name)
        if (tab.url != null && tab.url !== '') {
          let urlOk = false;
          if (typeof tab.url === 'string' && tab.url.length <= 2048) {
            try {
              const pu = new URL(tab.url);
              urlOk = pu.protocol === 'http:' || pu.protocol === 'https:';
            } catch (e) { urlOk = false; }
          }
          if (!urlOk) { alert(t('import_invalid_url')); return; }
        }
        if (tab.name != null && (typeof tab.name !== 'string' || tab.name.length > 200)) {
          alert(t('import_invalid_name')); return;
        }
        if (tab.comment != null && String(tab.comment).length > 1000) {
          alert(t('import_invalid_comment')); return;
        }
      }

      if (fileSpaces === null && (Array.isArray(data.folders) || fileTabs.some(t => t && t.folderId != null))) {
        fileSpaces = [];
        migrateFoldersToSpaces(fileTabs, fileSpaces, data.folders);
      }

      // Пространства: дедупликация по имени (свои сохраняются), remap id для вкладок/групп
      const spaceIdByName = new Map(allSpaces.map(s => [String(s.name).toLowerCase(), s.id]));
      const spaceIdRemap = new Map();
      let newSpaces = 0;
      (fileSpaces || []).forEach(s => {
        if (!s || !s.name) return;
        const key = String(s.name).toLowerCase();
        if (!spaceIdByName.has(key)) {
          const sp = { id: s.id || genId('sp'), name: s.name };
          allSpaces.push(sp);
          spaceIdByName.set(key, sp.id);
          newSpaces++;
        }
        spaceIdRemap.set(s.id, spaceIdByName.get(key));
      });
      const fallbackSpaceId = allSpaces[0] ? allSpaces[0].id : null;

      // Группы: дедупликация по имени, spaceId — через spaceIdRemap
      const groupIdByName = new Map(allGroups.map(g => [String(g.name).toLowerCase(), g.id]));
      const groupIdRemap = new Map();
      let newGroups = 0;
      (fileGroups || []).forEach(g => {
        if (!g || !g.name) return;
        const key = String(g.name).toLowerCase();
        if (!groupIdByName.has(key)) {
          const ng = {
            id: g.id || genId('g'),
            name: g.name,
            spaceId: spaceIdRemap.get(g.spaceId) || fallbackSpaceId,
            collapsed: !!g.collapsed
          };
          allGroups.push(ng);
          groupIdByName.set(key, ng.id);
          newGroups++;
        }
        groupIdRemap.set(g.id, groupIdByName.get(key));
      });

      const importedTabs = fileTabs.filter(t => t && t.url && t.name);
      const duplicates = importedTabs.filter(t => allTabs.some(existing => existing.url === t.url)).length;
      const newCount = importedTabs.length - duplicates;

      if (!confirm(
        t('import_summary', {
          spaces: (fileSpaces || []).length, new_spaces: newSpaces,
          groups: (fileGroups || []).length, new_groups: newGroups,
          tabs: importedTabs.length, new_tabs: newCount, dups: duplicates
        })
      )) {
        return;
      }

      importedTabs.forEach(t => {
        if (allTabs.some(existing => existing.url === t.url)) return; // дубль по URL
        t.spaceId = spaceIdRemap.get(t.spaceId) || fallbackSpaceId;
        if (t.groupId) t.groupId = groupIdRemap.get(t.groupId) || null;
        delete t.folderId; // legacy-поле — больше не хранится
        allTabs.push(t);
      });

      chrome.storage.local.set({ 'blattam-tabs': allTabs });
      chrome.storage.sync.set({
        'blattam-spaces': allSpaces,
        'blattam-groups': allGroups
      });
    } catch (err) {
      alert(t('import_bad_json'));
    }
  };
  reader.readAsText(file);
  e.target.value = '';
});

// === Правая рейка: живое зеркало открытых вкладок браузера (blattam-browser-tabs) ===
// Единственный реальный источник зеркала — background.js (слушатели chrome.tabs,
// дебаунс ~200 мс); view.js этот ключ НЕ записывает. Рейка показывает вкладки
// ТОЛЬКО этого окна (chrome.windows.getCurrent) в порядке верхней полосы;
// страница newtab (view.html) не показывается. Драг: reorder внутри рейки
// (chrome.tabs.move — верхняя полоса и рейка синхронизируются в обе стороны)
// и дроп в центр (сохранить вкладку карточкой — браузерная вкладка остаётся
// открытой).

// Страница newtab (view.html) — в рейку не попадает
function isOwnNewTab(t) {
  if (!t) return true;
  try {
    const selfUrl = chrome.runtime.getURL('view.html');
    return t.url === selfUrl || t.pendingUrl === selfUrl;
  } catch (err) { return false; }
}

// Начальная загрузка зеркала: окно (windows.getCurrent) + ключ
// blattam-browser-tabs; фолбэк — chrome.tabs.query (первый запуск:
// background зеркало ещё не записал)
function loadBrowserTabs() {
  (async () => {
    if (chrome.windows && chrome.windows.getCurrent) {
      try { const w = await chrome.windows.getCurrent(); browserWindowId = w ? w.id : null; }
      catch (err) { browserWindowId = null; }
    }
    let list = null;
    try {
      const data = await chrome.storage.local.get('blattam-browser-tabs');
      if (Array.isArray(data['blattam-browser-tabs']) && data['blattam-browser-tabs'].length > 0) {
        list = data['blattam-browser-tabs'];
      }
    } catch (err) { list = null; }
    if ((!list || list.length === 0) && chrome.tabs && chrome.tabs.query) {
      try {
        const q = browserWindowId != null ? { windowId: browserWindowId } : {};
        const tabs = await chrome.tabs.query(q);
        if (Array.isArray(tabs)) {
          list = tabs.filter(t => !isOwnNewTab(t))
            .map(t => ({ id: t.id, title: t.title || '', url: t.url || '',
                         favIconUrl: t.favIconUrl || '', windowId: t.windowId, index: t.index }))
            .sort((a, b) => (a.windowId - b.windowId) || (a.index - b.index));
        }
      } catch (err) { list = []; }
    }
    browserTabs = Array.isArray(list) ? list : [];
    renderBrowserTabs();
  })();
}

// Рендер рейки: вкладки этого окна в порядке полосы (index), по id
function renderBrowserTabs() {
  if (!browserTabsList) return;
  // Перерисовка в драге рейки уносит заглушку из DOM — сбрасываем ссылку,
  // чтобы отсоединённая заглушка не «воскресла» после dragend
  if (dragBrowserTabGhost && !dragBrowserTabGhost.isConnected) dragBrowserTabGhost = null;
  const mine = browserTabs
    .filter(t => browserWindowId == null || t.windowId === browserWindowId)
    .slice()
    .sort((a, b) => (a.windowId - b.windowId) || (a.index - b.index));
  browserTabsList.innerHTML = '';
  mine.forEach(t => browserTabsList.appendChild(makeBtItem(t)));
}

// Буквенная плитка фавикона рейки — та же монохромная, что у карточек
function makeBtIconFallback(t) {
  const el = document.createElement('span');
  el.className = 'bt-icon-fallback';
  el.textContent = faviconFallbackChar(t.url || t.title || '');
  return el;
}

// Элемент рейки: фавикон 16px (img; error — буквенная плитка) + обрезанное имя
function makeBtItem(t) {
  const item = document.createElement('div');
  item.className = 'bt-tab';
  item.dataset.id = String(t.id);
  item.draggable = true;
  item.title = t.title || t.url || '';
  if (t.favIconUrl) {
    const img = document.createElement('img');
    img.className = 'bt-icon';
    img.src = t.favIconUrl;
    img.alt = '';
    img.draggable = false;
    img.addEventListener('error', () => { if (img.parentNode) img.replaceWith(makeBtIconFallback(t)); });
    item.appendChild(img);
  } else {
    item.appendChild(makeBtIconFallback(t));
  }
  const label = document.createElement('span');
  label.className = 'bt-title';
  label.textContent = t.title || t.url || '—';
  item.appendChild(label);
  // Клик — переключить браузер на уже открытую вкладку (ложный post-drop-клик гасится one-shot)
  item.addEventListener('click', () => {
    if (pendingBtClickAfterDrag) { pendingBtClickAfterDrag = false; return; }
    focusBrowserTab(t);
  });
  item.addEventListener('dragstart', (e) => onBtDragStart(e, item, t));
  item.addEventListener('dragend', () => onBtDragEnd());
  btlBindItem(item, t); // pointer-путь (реальный Chrome UX)
  return item;
}

// Переключение браузера на уже открытую вкладку: активировать её (chrome.tabs.update
// active) + фокус её окна (chrome.windows.update focused). НЕ открывает новую вкладку.
function focusBrowserTab(t) {
  if (!t || t.id == null) return;
  let done = null;
  if (chrome.tabs && typeof chrome.tabs.update === 'function') {
    try { done = chrome.tabs.update(t.id, { active: true }); } catch (_) { done = null; }
  }
  const focusWindow = () => {
    if (t.windowId != null && chrome.windows && typeof chrome.windows.update === 'function') {
      try { chrome.windows.update(t.windowId, { focused: true }); } catch (_) {}
    }
  };
  if (done && typeof done.then === 'function') done.then(focusWindow).catch(focusWindow);
  else focusWindow();
}

// Заглушка рейки: тёплая (как ghost-slot карточек: --ghost-bg + пунктир
// --ghost-ring), размер элемента. Инлайн — в тестах head-стили view.html
// не грузятся
function makeBtGhostSlot(height) {
  const slot = document.createElement('div');
  slot.className = 'bt-ghost-slot';
  slot.style.cssText =
    'pointer-events:none;box-sizing:border-box;background:var(--ghost-bg);' +
    'border-width:1px;border-style:dashed;border-color:var(--ghost-ring);' +
    'border-radius:6px;width:100%;height:' + (height || 30) + 'px;';
  return slot;
}

function onBtDragStart(e, item, t) {
  // Нативный HTML5-драг отменяется, когда press ведёт pointer-путь: свой
  // (railPointerPress — ставится на pointerdown pointer-путём рейки, более поздняя волна)
  // или чужой pointer-драг пересекает рейку (pdForeignActive). Синтетическая
  // цепочка харнесса (не-trusted) всегда проходит без изменений
  if (e.isTrusted && (railPointerPress || pdForeignActive())) { e.preventDefault(); return; }
  dragSourceBrowserTab = { id: t.id, url: t.url || '', title: t.title || '',
                           favIconUrl: t.favIconUrl || '', windowId: t.windowId, index: t.index };
  btDragItem = item;
  btDragHeight = item.offsetHeight || 30; // меряем ДО display:none
  btDropCommitted = false;
  // Ложный клик по элементу рождается в момент дропа (до dragend) —
  // вооружаем one-shot-подавление
  pendingBtClickAfterDrag = true;
  pendingCardClickAfterDrag = true; // дроп в центр: ложный клик не открывает карточку
  pendingChipClickAfterDrag = true; // дроп на чип: ложный клик не переключает пространство
  if (e.dataTransfer) {
    e.dataTransfer.setData('text/plain', String(t.id));
    e.dataTransfer.effectAllowed = 'move';
  }
  item.style.display = 'none';
  // Отложенно: display:none в самом dragstart «залипает» HTML5-drag в Chrome
  setTimeout(() => {
    // Перерисовка в драге уносит элемент из DOM — отсоединённому заглушку
    // не вставляем
    if (!dragSourceBrowserTab || !btDragItem || !btDragItem.isConnected) return;
    if (!dragBrowserTabGhost) {
      dragBrowserTabGhost = makeBtGhostSlot(btDragHeight);
      btDragItem.before(dragBrowserTabGhost);
    }
  }, 0);
}

// Полный cleanup (идемпотентный): заглушки сняты, источник возвращён в слот,
// рейка перерисована
function onBtDragEnd() {
  const src = dragSourceBrowserTab;
  dragSourceBrowserTab = null;
  btDragItem = null;
  if (!btDropCommitted) pendingBtClickAfterDrag = false; // драг отменён — ложного клика не будет
  btDropCommitted = false;
  if (dragBrowserTabGhost && dragBrowserTabGhost.isConnected) dragBrowserTabGhost.remove();
  dragBrowserTabGhost = null;
  removeGhostSlot(); // центральная заглушка (рейка → центр)
  restoreWrapHiddenCard(); // временно скрытая «row-full» карточка — вернуть
  pdLastTouchCard = null;
  pdLastTouchAnchor = null;
  if (src && browserTabsList) {
    // Источник мог уже перерисоваться (onChanged) — восстановим видимость по id
    const el = browserTabsList.querySelector('.bt-tab[data-id="' + CSS.escape(String(src.id)) + '"]');
    if (el) el.style.display = '';
  }
  renderBrowserTabs(); // идемпотентно
}

// Видимые элементы рейки в DOM-порядке (источник при драге скрыт)
function btVisibleItems() {
  if (!browserTabsList) return [];
  return [...browserTabsList.querySelectorAll('.bt-tab')].filter(el => el.style.display !== 'none');
}

// Слот вставки в рейке (midpoint-правило, как у карточек): первый элемент,
// чья вертикальная середина НИЖЕ курсора — слот перед ним; выше середин всех —
// после последнего
function btSlotAnchor(clientY) {
  const items = btVisibleItems();
  if (!items.length) return null;
  for (const it of items) {
    const r = it.getBoundingClientRect();
    if (clientY != null && clientY < r.top + r.height / 2) return { el: it, side: 'before' };
  }
  return { el: items[items.length - 1], side: 'after' };
}

function moveBtGhostSlot(anchor) {
  if (!dragBrowserTabGhost || !dragBrowserTabGhost.isConnected) return;
  if (!anchor || !anchor.el) { browserTabsList.appendChild(dragBrowserTabGhost); return; }
  if (anchor.side === 'before') anchor.el.before(dragBrowserTabGhost);
  else anchor.el.after(dragBrowserTabGhost);
}

// Новый per-window-индекс перетаскиваемой вкладки по DOM-позиции заглушки
// (порядок рейки = порядок верхней полосы окна)
function btGhostIndex() {
  const ghost = dragBrowserTabGhost;
  const src = dragSourceBrowserTab;
  if (!ghost || !ghost.isConnected) return src ? src.index : 0;
  let pos = 0;
  for (const child of browserTabsList.children) {
    if (child === ghost) break;
    if (child.classList && child.classList.contains('bt-tab') && child.style.display !== 'none') pos++;
  }
  return pos;
}

// Reorder рейки: chrome.tabs.move — зеркало (background) и верхняя полоса
// следуют, onChanged перерисует рейку. Целевой индекс — по РЕАЛЬНОМУ окну:
// рейка не показывает newtab-страницу (view.html), поэтому позиция в рейке —
// НЕ то же, что индекс в окне (view.html занимает слот в окне). Достаём окно,
// вставляем источник в позицию заглушки по числу ВИДИМЫХ вкладок перед ней.
// После chrome.tabs.move перерисовываем рейку НЕМЕДЛЕННО из реального
// окна. В реальном Chrome запись зеркала в background идёт с дебаунсом
// ~200 мс, и пока она не доберётся до view, рейка остаётся в старом
// порядке (мок перерисовывает зеркало синхронно, поэтому в тестах это не
// видно). В storage зеркало view не пишет (единственный источник —
// background) — обновляем только в-памяти список browserTabs + рейку.
function syncRailFromTabs() {
  if (!chrome.tabs || !chrome.tabs.query) return;
  try {
    chrome.tabs.query({}, (tabs) => {
      if (!Array.isArray(tabs)) return;
      browserTabs = tabs
        .filter(t => t && !isOwnNewTab(t))
        .map(t => ({ id: t.id, title: t.title || '', url: t.url || '',
                     favIconUrl: t.favIconUrl || '', windowId: t.windowId, index: t.index }))
        .sort((a, b) => (a.windowId - b.windowId) || (a.index - b.index));
      renderBrowserTabs();
    });
  } catch (err) { /* рейка — вспомогательная, молча пропускаем */ }
}

function commitBtRailMove(src) {
  // Индекс ЗАГЛУШКИ фиксируем синхронно (ЧИСЛО): async-ветка ниже отработает
  // уже ПОСЛЕ cleanup pointer-пути, где заглушка снята — читать DOM-позицию в
  // микрозадаче pointer-путь прочёл бы index источника (no-op). HTML5-путь не
  // тронут: там ghostPos и есть индекс (источник не двигался)
  const ghostPos = typeof btGhostIndex === 'function' ? btGhostIndex() : 0;
  btDropCommitted = true;
  // Снимаем guard ДО записи: onChanged (мок) перерисует рейку сразу
  dragSourceBrowserTab = null;
  if (!chrome.tabs || !chrome.tabs.move) return;
  if (chrome.tabs.query) {
    (async () => {
      const tabs = await new Promise((res) =>
        chrome.tabs.query({ windowId: src.windowId }, (ts) => res(ts || [])));
      const others = tabs.filter(t => t && t.id !== src.id);
      let count = 0, target = others.length;
      for (let i = 0; i < others.length; i++) {
        if (count === ghostPos) { target = i; break; }
        if (!isOwnNewTab(others[i])) count++;
      }
      if (target !== src.index) {
        const p = chrome.tabs.move(src.id, { windowId: src.windowId, index: target });
        if (p && p.then) p.then(() => syncRailFromTabs()).catch(() => {});
        else syncRailFromTabs();
      }
    })().catch(() => {});
  } else if (ghostPos !== src.index) {
    const p = chrome.tabs.move(src.id, { windowId: src.windowId, index: ghostPos });
    if (p && p.then) p.then(() => syncRailFromTabs()).catch(() => {});
    else syncRailFromTabs();
  }
}

// Сохранённая карточка из браузерной вкладки — те же поля, что у
// существующего save-пути (saveCurrentTab): name/url/title/favIconUrl?/spaceId
// (+ groupId секции)
function makeSavedTabFromBrowser(src, section) {
  const tab = {
    name: ((src.title || '').trim() || src.url) || t('untitled'),
    url: src.url,
    title: src.title || '',
    spaceId: activeSpaceId,
    groupId: section
  };
  if (src.favIconUrl) tab.favIconUrl = src.favIconUrl;
  return tab;
}

// Дроп в центр: НОВАЯ карточка в позиции ghost-slot (groupId секции слота,
// null — «Без группы»); браузерная вкладка остаётся открытой, зеркало не
// трогаем
function saveBtToCenter(src, anchor) {
  btDropCommitted = true;
  dragSourceBrowserTab = null;
  let section = null, at = allTabs.length;
  const res = slotAnchorResolution(anchor);
  if (res) {
    section = res.section;
    const a = allTabs.findIndex(t => t.url === res.anchorUrl);
    if (a !== -1) at = res.side === 'after' ? a + 1 : a;
  }
  const tabs = allTabs.slice();
  tabs.splice(at, 0, makeSavedTabFromBrowser(src, section));
  chrome.storage.local.set({ 'blattam-tabs': tabs });
  // Свернутая группа-секция слота: новая карточка в неё ушла — разворачиваем
  expandGroupForDrop(section);
  removeGhostSlot();
}

// Дроп на шапку группы (или слот пустой группы): в ту группу, в конец списка
// (семантика drop-пути gbar)
function saveBtToGroup(src, groupId) {
  btDropCommitted = true;
  dragSourceBrowserTab = null;
  const tabs = allTabs.slice();
  tabs.push(makeSavedTabFromBrowser(src, groupId));
  chrome.storage.local.set({ 'blattam-tabs': tabs });
  // Свернутая группа: новая карточка в неё ушла — разворачиваем
  expandGroupForDrop(groupId);
  removeGhostSlot();
}

// Центральная заглушка для драга рейка → центр: ghost-slot карточки, размер
// видимой карточки (создаётся при первом dragover по центральному списку)
function ensureCentralBtGhost() {
  if (dragGhostSlot && dragGhostSlot.isConnected) return;
  const ref = document.querySelector('#tabs-list .tab-card');
  if (!ref) return;
  dragGhostSlot = makeGhostSlot(ref);
}

// Ставит центральную заглушку в слот вставки при драге рейка → центр.
// moveGhostSlot неприменим: он завязан на dragSourceUrl (драг карточки) —
// а источник тут в рейке, а не в секции карточек.
function moveCentralBtGhost(anchor) {
  if (!dragGhostSlot) return;
  if (!anchor || !anchor.el) return;
  if (anchor.side === 'before') anchor.el.before(dragGhostSlot);
  else anchor.el.after(dragGhostSlot);
}

// Глобальный dragover при драге вкладки рейки: рейка — заглушка по
// midpoint-правилу; чип пространства — no-target (заглушка замирает, дроп не
// переключает пространство); шапка группы / слот пустой группы — дроп в группу
// (центральная заглушка скрыта); центральный список — центральная заглушка
// следует, как при драге карточки
document.addEventListener('dragover', (e) => {
  if (!dragSourceBrowserTab || !e.dataTransfer) return;
  const t = e.target;
  const closest = (s) => (t && t.closest) ? t.closest(s) : null;
  if (closest('.space-chip')) return; // no-target
  if (closest('.gbar') || closest('.group-empty-slot')) {
    if (dragGhostSlot) setGhostDisplay('none');
    restoreWrapHiddenCard();
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    return;
  }
  if (closest('#browser-tabs-list')) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    moveBtGhostSlot(btSlotAnchor(e.clientY));
    return;
  }
  if (closest('#tabs-list')) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    // Нижняя полоса: заглушка скрыта, дроп там — отмена
    if (cardAreaEmptyBand(e.clientX, e.clientY) !== null) {
      if (dragGhostSlot) setGhostDisplay('none');
      restoreWrapHiddenCard();
      return;
    }
    // Территориальная система (та же, что у драга карточки)
    ensureCentralBtGhost();
    setGhostDisplay('');
    const anchor = cursorCardAnchor(e.clientX, e.clientY);
    if (anchor) {
      updateWrapHiddenCard(anchor);
      moveCentralBtGhost(anchor);
    } else {
      restoreWrapHiddenCard();
    }
  }
});

document.addEventListener('drop', (e) => {
  if (!dragSourceBrowserTab || !e.dataTransfer) return;
  const t = e.target;
  const closest = (s) => (t && t.closest) ? t.closest(s) : null;
  const src = dragSourceBrowserTab;
  if (closest('.space-chip')) return; // no-target — отмена
  const gbar = closest('.gbar');
  if (gbar && gbar.dataset.groupId) { e.preventDefault(); saveBtToGroup(src, gbar.dataset.groupId); return; }
  const ges = closest('.group-empty-slot');
  if (ges && ges.dataset.groupId) { e.preventDefault(); saveBtToGroup(src, ges.dataset.groupId); return; }
  if (closest('#browser-tabs-list')) { e.preventDefault(); commitBtRailMove(src); return; }
  if (closest('#tabs-list')) {
    e.preventDefault();
    // Нижняя полоса — отмена (dragend уберёт заглушки)
    if (cardAreaEmptyBand(e.clientX, e.clientY) !== null) return;
    saveBtToCenter(src, cursorCardAnchor(e.clientX, e.clientY));
    return;
  }
  // Повсюду остальном — отмена (dragend снимет заглушки)
});

// Catch-all: перерисовка в драге уносит источник из DOM, и его собственный
// dragend не сработает — cleanup здесь
document.addEventListener('dragend', () => {
  if (dragSourceBrowserTab) onBtDragEnd();
});

// === Pointer drag of rail browser tabs (real Chrome UX) ===
// Путь зеркалирует карточный (pd) и чиповый (pcd): press по элементу рейки
// + движение больше 8 px — нативный HTML5-драг отменяется (guard в
// onBtDragStart: isTrusted и (railPointerPress или pdForeignActive) —
// preventDefault), источник прячется (тёплая .bt-ghost-slot на его месте —
// синхронно, без setTimeout), LIFT-КЛОН (.pd-clone в body, position:fixed,
// liftScale + тень) следует за курсором 1:1, заглушка ходит по рейке по
// midpoint-правилу (btSlotAnchor — то же, что у HTML5-пути) с FLIP-слайдом
// соседей (snapshotCardRects '#browser-tabs-list .bt-tab' + applyFlipFrom).
// Отпускание — те же цели, что у drop-хендлера: шапка группы/слот пустой
// группы — saveBtToGroup, рейка — commitBtRailMove (индекс РЕАЛЬНОГО окна по
// DOM-позиции заглушки), центральный список — saveBtToCenter (тёплая
// центральная заглушка следует за курсором через moveCentralBtGhost),
// чип пространства/повсюду остальном — cancel; клон «приземляется» в цель
// за settleMs, при cancel — возвращается домой. Escape — cancel. Обычный
// клик (без движения) по-прежнему открывает вкладку (click-хендлер не
// тронут). Заглушка — общий dragBrowserTabGhost (синхронная вставка —
// btGhostIndex корректен при коммите). Своё состояние (btl) — не
// пересекается с карточным/чиповым путями (одна мышь);
// pdCreateClone/pdCloneMove/pdFinishClone/pdScale/pdSettleMs/applyFlipFrom
// общие (pdClone — безопасно: драг один). Синтетическая HTML5-цепочка
// (ne-trusted DragEvents) идёт своим dragstart — не тронута.
let btl = null; // активный press: {t, item, homeRect, startX, startY, ox, oy, armed, lastAnchor}

function btlTeardown() {
  window.removeEventListener('pointermove', btlOnMove);
  window.removeEventListener('pointerup', btlOnUp);
  window.removeEventListener('pointercancel', btlOnCancel);
  window.removeEventListener('keydown', btlOnKey);
  document.body.style.cursor = '';
}

// После коммита: центральная заглушка снята самими save-функциями, рейку
// снимаем и перерисовываем (источник мог уже перерисоваться onChanged-ом —
// по id, как в onBtDragEnd)
function btlAfterCommit(p) {
  btDropCommitted = true;
  // Центральная заглушка (рейка → центр) снимается явно: save-функции
  // центра/группы снимают сами, а коммит в рейку — нет, без неё заглушка
  // остаётся в центральном списке (идемпотентно)
  removeGhostSlot();
  restoreWrapHiddenCard(); // временно скрытая «row-full» карточка — вернуть
  pdLastTouchCard = null;
  pdLastTouchAnchor = null;
  if (dragBrowserTabGhost && dragBrowserTabGhost.isConnected) dragBrowserTabGhost.remove();
  dragBrowserTabGhost = null;
  if (p && p.t && browserTabsList) {
    const el = browserTabsList.querySelector('.bt-tab[data-id="' + CSS.escape(String(p.t.id)) + '"]');
    if (el) el.style.display = '';
  }
  renderBrowserTabs();
}

// Cancel: элемент возвращается в рейку, заглушка снята, клон «возвращается
// домой» (p — состояние драга; передаётся из btlOnUp, где btl уже обнулён)
function btlCancelState(p) {
  p = p || btl;
  btl = null;
  railPointerPress = false;
  dragSourceBrowserTab = null;
  btDragItem = null;
  pendingBtClickAfterDrag = false; // драг отменён — ложного клика не будет
  if (dragBrowserTabGhost && dragBrowserTabGhost.isConnected) dragBrowserTabGhost.remove();
  dragBrowserTabGhost = null;
  removeGhostSlot(); // центральная заглушка (рейка → центр) при отмене
  restoreWrapHiddenCard(); // временно скрытая «row-full» карточка — вернуть
  pdLastTouchCard = null;
  pdLastTouchAnchor = null;
  if (p && p.item && p.item.isConnected) p.item.style.display = '';
  renderBrowserTabs();
  if (p) pdFinishClone(p.homeRect, pdSettleMs());
}

function btlOnKey(e) {
  if (!btl || !btl.armed || e.key !== 'Escape') return;
  btlTeardown();
  btlCancelState();
}

function btlOnCancel(e) {
  if (!btl) return;
  const armed = btl.armed;
  btlTeardown();
  if (armed) btlCancelState();
  else { btl = null; railPointerPress = false; }
}

// Commit at (x, y) — те же цели, что у HTML5-дропа (document drop). Rect
// цели (для клон-сета) снимаем ДО commit — commit ре-рендерит рейку и
// снимает заглушки. null — не целевая точка (cancel).
function btlCommitAt(x, y, p) {
  const t = document.elementFromPoint(x, y);
  const closest = (sel) => (t && t.closest) ? t.closest(sel) : null;
  const src = dragSourceBrowserTab;
  if (!src || !t || !t.closest) return null;
  if (closest('.space-chip')) return null; // no-target — отмена (не переключает пространство)
  const gbar = closest('.gbar');
  if (gbar && gbar.dataset.groupId) {
    const rect = gbar.getBoundingClientRect();
    saveBtToGroup(src, gbar.dataset.groupId);
    btlAfterCommit(p);
    return rect;
  }
  const ges = closest('.group-empty-slot');
  if (ges && ges.dataset.groupId) {
    const rect = ges.getBoundingClientRect();
    saveBtToGroup(src, ges.dataset.groupId);
    btlAfterCommit(p);
    return rect;
  }
  if (closest('#browser-tabs-list')) {
    // Точка релиза — тот же midpoint-якорь, что dragover; индекс — по РЕАЛЬНОМУ
    // окну (commitBtRailMove), DOM-позиция заглушки уже верна (синхронная)
    moveBtGhostSlot(btSlotAnchor(y));
    const rect = (dragBrowserTabGhost && dragBrowserTabGhost.isConnected)
      ? dragBrowserTabGhost.getBoundingClientRect() : p.homeRect;
    commitBtRailMove(src);
    btlAfterCommit(p);
    return rect;
  }
  if (closest('#tabs-list')) {
    // Нижняя полоса — отмена (те же правила, что у драга карточки)
    if (cardAreaEmptyBand(x, y) !== null) return null;
    const anchor = cursorCardAnchor(x, y);
    ensureCentralBtGhost();
    if (anchor) moveCentralBtGhost(anchor);
    let rect = p.homeRect;
    if (dragGhostSlot && dragGhostSlot.isConnected) rect = dragGhostSlot.getBoundingClientRect();
    saveBtToCenter(src, anchor);
    btlAfterCommit(p);
    return rect;
  }
  return null; // повсюду остальном — отмена
}

function btlOnUp(e) {
  if (!btl) return;
  const armed = btl.armed;
  const p = btl;
  btl = null;
  btlTeardown();
  railPointerPress = false;
  if (!armed) return; // обычный press — клик проходит (открывает вкладку)
  const rect = btlCommitAt(e.clientX, e.clientY, p);
  if (rect) {
    pdFinishClone(rect, pdSettleMs()); // зафиксировано — клон «приземляется» в цель
  } else {
    btlCancelState(p); // вне целей — отмена
  }
}
// Размер-состояние клона рейка-драга: курсор над центральным списком или
// левой рейкой — ПОЛНЫЙ размер карточки (при дропе там появляется именно
// карточка); над правой рейкой или вне блоков — малый размер элемента рейки
// (rect источника, снятый при arming). Клон pointer-events:none —
// elementFromPoint его не видит. Пустой центр (нет .tab-card) — запасной
// размер: центральная заглушка, иначе clientWidth списка / 5 (высота 80,
// как у карточки) — детерминированно и стабильно.
// FULL-состояние: клон выглядит как СОХРАНЁННАЯ карточка — фон
// var(--tab-card-bg) (включая кастомный цвет из настроек), радиус, имя
// сверху (шрифт/цвет .tab-name), фавикон снизу (img или буква — те же
// узлы, что у карточки). CSS вида — класс .pd-clone.btl-clone-full.
function btlCloneCardBody(t) {
  const letter = faviconFallbackChar(t.url || '');
  const name = document.createElement('div');
  name.className = 'tab-name btl-clone-card-name';
  name.textContent = String(t.title || '').trim() || letter;
  const box = document.createDocumentFragment();
  box.appendChild(name);
  if (t.favIconUrl) {
    const img = document.createElement('img');
    img.className = 'tab-favicon';
    img.src = t.favIconUrl;
    img.alt = '';
    img.draggable = false;
    img.addEventListener('error', () => {
      if (img.parentNode) img.replaceWith(makeFaviconFallback(t, letter));
    });
    box.appendChild(img);
  } else {
    box.appendChild(makeFaviconFallback(t, letter));
  }
  return box;
}
let btlCloneState = null; // 'full' | 'small' — последнее применённое состояние
function btlCloneSizeAt(x, y) {
  if (!btl || !btl.armed || !pdClone || !pdClone.isConnected) return;
  const t = document.elementFromPoint(x, y);
  const full = !!(t && t.closest && (t.closest('#center-pane') || t.closest('#rail-left')));
  const state = full ? 'full' : 'small';
  if (state === btlCloneState) return;
  btlCloneState = state;
  if (full) pdClone.replaceChildren(btlCloneCardBody(btl.t)); // вид сохранённой карточки
  else if (btl.cloneNodes && btl.cloneNodes.length) pdClone.replaceChildren(...btl.cloneNodes); // исходный вид элемента рейки
  let w, h;
  if (full) {
    let card = null;
    for (const el of document.querySelectorAll('#tabs-list .tab-card'))
      if (el.offsetWidth > 0) { card = el; break; }
    if (card) { w = card.offsetWidth; h = card.offsetHeight; }
    else if (dragGhostSlot && dragGhostSlot.isConnected && dragGhostSlot.offsetWidth > 0) {
      w = dragGhostSlot.offsetWidth; h = dragGhostSlot.offsetHeight;
    } else {
      const tl = document.getElementById('tabs-list');
      w = (tl && tl.clientWidth >= 10) ? Math.round(tl.clientWidth / 5) : 166; h = 80;
    }
  } else {
    w = btl.homeRect.width; h = btl.homeRect.height;
  }
  pdClone.style.width = Math.round(w) + 'px';
  pdClone.style.height = Math.round(h) + 'px';
  pdClone.classList.toggle('btl-clone-full', full);
}


// Заглушка следует за курсором: рейка — midpoint-якорь (btSlotAnchor, то же
// правило, что у HTML5-пути), при СМЕНЕ якоря — FLIP-проход соседей
// (снапшот ДО перемещения, скроуп строго в рейку — body-клон не считается);
// центральный список — центральная заглушка за курсором; повсюду остальном —
// заглушки стоят (cancel-кандидат при отпускании)
function btlTrackAt(x, y) {
  btlCloneSizeAt(x, y); // размер-состояние клона: полный над центром/левой рейкой
  const t = document.elementFromPoint(x, y);
  if (t && t.closest && t.closest('#browser-tabs-list')) {
    const anchor = btSlotAnchor(y);
    // FLIP — только при РЕАЛЬНОЙ смене места (заглушка не на якорном месте):
    // повторная установка в ту же позицию слайда не требует
    const atPlace = anchor.side === 'before'
      ? (dragBrowserTabGhost && dragBrowserTabGhost.nextElementSibling === anchor.el)
      : (dragBrowserTabGhost && dragBrowserTabGhost.previousElementSibling === anchor.el);
    const same = btl.lastAnchor && btl.lastAnchor.el === anchor.el && btl.lastAnchor.side === anchor.side;
    if (!same || !atPlace) {
      const firstRects = atPlace ? null : snapshotCardRects('#browser-tabs-list .bt-tab', btl.item);
      moveBtGhostSlot(anchor);
      btl.lastAnchor = anchor;
      if (firstRects) applyFlipFrom(firstRects);
    }
    return;
  }
  if (t && t.closest && t.closest('#tabs-list')) {
    // Шапка группы / слот пустой группы: дроп В группу — центральная
    // заглушка скрыта целиком (та же семантика, что у драга карточки)
    if (t.closest('.gbar') || t.closest('.group-empty-slot')) {
      if (dragGhostSlot) setGhostDisplay('none');
      restoreWrapHiddenCard();
      btl.lastAnchor = null;
      return;
    }
    // Нижняя полоса списка (below the last row): заглушка скрыта,
    // отпускание там — отмена (btlCommitAt вернёт null)
    if (cardAreaEmptyBand(x, y) !== null) {
      if (dragGhostSlot) setGhostDisplay('none');
      restoreWrapHiddenCard();
      btl.lastAnchor = null;
      return;
    }
    // Территориальная система (та же, что у драга карточки): cursorCardAnchor
    ensureCentralBtGhost();
    if (dragGhostSlot) setGhostDisplay('');
    const anchor = cursorCardAnchor(x, y);
    if (anchor) {
      // FLIP — только при РЕАЛЬНОЙ смене места (как в рейке): повторная
      // установка в ту же позицию слайда не требует
      const atPlace = anchor.side === 'before'
        ? (dragGhostSlot && dragGhostSlot.isConnected && dragGhostSlot.nextElementSibling === anchor.el)
        : (dragGhostSlot && dragGhostSlot.isConnected && dragGhostSlot.previousElementSibling === anchor.el);
      const same = btl.lastAnchor && btl.lastAnchor.el === anchor.el && btl.lastAnchor.side === anchor.side;
      if (!same || !atPlace) {
        const firstRects = atPlace ? null : snapshotCardRects();
        updateWrapHiddenCard(anchor);
        moveCentralBtGhost(anchor);
        btl.lastAnchor = anchor;
        if (firstRects) applyFlipFrom(firstRects);
      }
    } else {
      restoreWrapHiddenCard();
    }
    return;
  }
  btl.lastAnchor = null; // вне рейки — якорь сбрасывается (в рейке заново FLIP-нет)
}

function btlOnMove(e) {
  if (!btl) return;
  if (!btl.armed) {
    const dx = e.clientX - btl.startX, dy = e.clientY - btl.startY;
    if (dx * dx + dy * dy <= 8 * 8) return; // не драг, пока больше 8 px нет
    // ARM: меряем rect и высоту ДО display:none (у скрытого элемента 0-размеры),
    // прячем источник, тёплая заглушка дома (синхронно), lift-клон под курсором
    const item = btl.item;
    btl.homeRect = item.getBoundingClientRect();
    dragSourceBrowserTab = { id: btl.t.id, url: btl.t.url || '', title: btl.t.title || '',
                             favIconUrl: btl.t.favIconUrl || '', windowId: btl.t.windowId, index: btl.t.index };
    btDragItem = item;
    btDragHeight = item.offsetHeight || 30;
    btDropCommitted = false;
    pendingBtClickAfterDrag = true; // ложный post-drag-клик не открывает вкладку
    pendingCardClickAfterDrag = true; // дроп в центр: ложный клик не открывает карточку
    pendingChipClickAfterDrag = true; // дроп на чип: ложный клик не переключает пространство
    dragBrowserTabGhost = makeBtGhostSlot(btDragHeight);
    item.before(dragBrowserTabGhost);
    item.style.display = 'none';
    pdClone = pdCreateClone(item, btl.homeRect, e.clientX - btl.ox, e.clientY - btl.oy);
    pdClone.style.transition = 'width 150ms ease, height 150ms ease'; // плавная смена размера full/small (transform — нет: 1:1 за курсором)
    btlCloneState = null; // размер-состояние — заново (первое движение применит текущее)
    btl.cloneNodes = Array.from(pdClone.childNodes); // SMALL: исходный контент элемента рейки
    btl.armed = true;
    btl.lastAnchor = null;
    pdLastTouchCard = null;   // fresh drag — no card touched yet (territory freeze state)
    pdLastTouchAnchor = null;
    // Вооружено: курсор grabbing на body и на элементе
    document.body.style.cursor = 'grabbing';
    if (item.isConnected) item.style.cursor = 'grabbing';
  }
  e.preventDefault();
  pdCloneMove(e.clientX - btl.ox, e.clientY - btl.oy);
  pdAutoScrollAt(e.clientX, e.clientY, btl.item);
  btlTrackAt(e.clientX, e.clientY);
}

function btlBindItem(item, t) {
  item.addEventListener('pointerdown', (e) => {
    if (e.button !== 0) return;
    if (!item.draggable) return; // guardDragOverButtons снял draggable — press на кнопке
    const rect = item.getBoundingClientRect();
    btl = { t: t, item: item, homeRect: rect,
            startX: e.clientX, startY: e.clientY,
            ox: e.clientX - rect.left, oy: e.clientY - rect.top,
            armed: false, lastAnchor: null };
    railPointerPress = true; // guard в onBtDragStart отменит trusted нативный драг
    window.addEventListener('pointermove', btlOnMove);
    window.addEventListener('pointerup', btlOnUp);
    window.addEventListener('pointercancel', btlOnCancel);
    window.addEventListener('keydown', btlOnKey);
  });
}

// === i18n: переключатель языка (Настройки → Кастомизация) ===
function updateLangButtons() {
  const ru = document.getElementById('lang-btn-ru');
  const en = document.getElementById('lang-btn-en');
  if (ru) ru.classList.toggle('active', I18N_LANG === 'ru');
  if (en) en.classList.toggle('active', I18N_LANG === 'en');
}

function switchLanguage(lang) {
  if (lang === I18N_LANG) return;
  setLang(lang);
  applyI18n();
  updateLangButtons();
  renderSpaces();
  renderTabs(searchInput.value);
  updateSelectionBar();
  renderPresetList();
}

(function () {
  const ru = document.getElementById('lang-btn-ru');
  const en = document.getElementById('lang-btn-en');
  if (ru) ru.addEventListener('click', function () { switchLanguage('ru'); });
  if (en) en.addEventListener('click', function () { switchLanguage('en'); });
})();

// === Start ===
loadLang().then(function () {
  updateLangButtons();
  loadData();
  loadBrowserTabs();
  loadTrash(); // корзина: состояние + счётчик рейки
});

// === Аккаунт (левая рейка, низ): GitHub — вход и синхронизация ===
// Слот .rail-accounts .slot — кнопка #account-slot. Состояния:
// не подключён (подпись «Нажмите, чтобы войти в GitHub») / подключён
// («GitHub: <login>» + «Синхронизация через GitHub»). Клик: не подключён
// → OAuth-поток (get-token); подключён → sync-now (pull+push).
(function initAccountSlot() {
  const slot = document.getElementById('account-slot');
  if (!slot) return;
  const label = slot.querySelector('.a-t');
  const sub = slot.querySelector('.a-s');
  const devRow = document.getElementById('account-device');
  const devCodeEl = document.getElementById('account-device-code');
  const devCopyBtn = document.getElementById('account-device-copy');

  function showDeviceCode(code) {
    if (devRow && devCodeEl) { devCodeEl.textContent = code; devRow.hidden = false; }
  }
  function hideDeviceCode() {
    if (devRow) devRow.hidden = true;
    if (devCodeEl) devCodeEl.textContent = '';
  }

  function renderAccount(user, subOverride) {
    if (user) {
      label.textContent = user.login ? 'GitHub: ' + user.login : 'GitHub';
      sub.textContent = subOverride || t('account_connected_sub');
      hideDeviceCode();
    } else {
      label.textContent = t('account_label');
      sub.textContent = subOverride || t('account_connect_sub');
    }
  }

  // Авто-retry verify: при провале рейка/модалка показывают ошибку,
  // таймер ведёт СТРАНИЦА (SW умирает), 30 с, стоп при успехе; retry
  // тихий — модалка не мигает «проверяем» (showChecking=false).
  let verifyRetryTimer = null;
  function clearVerifyRetry() {
    if (verifyRetryTimer) { clearTimeout(verifyRetryTimer); verifyRetryTimer = null; }
  }
  function scheduleVerifyRetry() {
    clearVerifyRetry();
    const ms = (typeof self !== 'undefined' && self.__verifyRetryMs) || 30000;
    verifyRetryTimer = setTimeout(function () {
      verifyRetryTimer = null;
      refreshAccount();
      renderGitHubModal(false);
    }, ms);
  }
  function isAuthVerifyError(err) {
    return typeof err === 'string' && /^api (401|403)$/.test(err);
  }

  function refreshAccount() {
    chrome.storage.local.get(['github-token', 'blattam-github-login'], (r) => {
      if (!r['github-token']) { clearVerifyRetry(); renderAccount(null); return; }
      // Мгновенно — при токене + кэше логина, до verify-github:
      // рейка не мигает «подключаем», успех verify перекроет свежим логином.
      if (r['blattam-github-login']) renderAccount({ login: r['blattam-github-login'] });
      chrome.runtime.sendMessage({ action: 'verify-github' }, (res) => {
        if (res && res.success) {
          clearVerifyRetry();
          chrome.storage.local.set({ 'blattam-github-login': res.user.login });
          renderAccount(res.user);
          return;
        }
        // Токен есть, но verify не удался:
        if (r['blattam-github-login']) {
          clearVerifyRetry();
          renderAccount({ login: r['blattam-github-login'] });
          return;
        }
        if (res && res.token_present) {
          if (isAuthVerifyError(res.error)) {
            // Мёртвый токен не лечится повтором — показываем ошибку, без retry
            clearVerifyRetry();
            renderAccount(null, t('account_token_invalid'));
          } else {
            // Стадийность сети убрали: честная ошибка + тихий авто-retry
            // (сеть может восстановиться; при успехе логин перекроет)
            renderAccount(null, t('account_verify_error'));
            scheduleVerifyRetry();
          }
          return;
        }
        renderAccount(null, t('account_verify_error'));
        scheduleVerifyRetry();
      });
    });
  }

  // Device Flow (fallback, когда auth-окно не открывается): background
  // запрашивает код и начинает поллинг; мы открываем страницу ввода кода
  // обычной вкладкой и показываем код в подписи. Успех придёт сам
  // (storage.onChanged → refreshAccount).
  let devPollTimer = null;
  function stopDevicePolling() {
    if (devPollTimer) { clearInterval(devPollTimer); devPollTimer = null; }
  }
  // Поллинг ведёт СТРАНИЦА (service worker умирает; живая страница — нет).
  // Каждое сообщение будит SW, он делает один шаг поллинга и сохраняет
  // состояние. Успех/ошибка — в ответе; токен появится в storage →
  // onChanged → refreshAccount (уже есть ниже).
  function startDevicePolling(intervalS, expiresAt) {
    stopDevicePolling();
    const ms = Math.max(1, intervalS || 5) * 1000;
    devPollTimer = setInterval(function () {
      if (expiresAt && Date.now() > expiresAt) {
        stopDevicePolling();
        hideDeviceCode();
        refreshAccount();
        return;
      }
      chrome.runtime.sendMessage({ action: 'device-flow-poll' }, (res) => {
        if (!res) return;
        if (res.connected) { stopDevicePolling(); return; }
        if (res.slow_down) {
          // GitHub просит паузу — ждём указанный интервал, потом возобновляем
          setAccountSub(t('account_slow_down'));
          stopDevicePolling();
          setTimeout(function () { startDevicePolling(intervalS, expiresAt); },
                     res.wait_ms || 30000);
          return;
        }
        if (res.inactive) {
          stopDevicePolling();
          if (res.error) setAccountSub(res.error);
          else refreshAccount();
        }
      });
    }, ms);
  }
  function startDeviceFlowLogin() {
    setAccountSub(t('account_device_starting'));
    chrome.runtime.sendMessage({ action: 'device-flow-start' }, (res) => {
      if (!res) {
        chrome.storage.local.get('github-auth-error', (r) => {
          setAccountSub(r['github-auth-error'] || t('account_sync_error'));
        });
        return;
      }
      // Открываем страницу ввода кода обычной вкладкой (всегда работает)
      // Страница ввода кода — verification_uri_complete: код уже подставлен
      // (без него страница требует ввести код руками)
      chrome.tabs.create({ url: (res.verification_uri_complete || res.verification_uri), active: true });
      setAccountSub(t('account_device_hint'));
      showDeviceCode(res.user_code);
      startDevicePolling(res.interval, res.expires_at);
      // Код живёт до expires_at (GitHub даёт ~15 минут) — потом возвращаем
      // подпись к обычному виду
      setTimeout(function () { hideDeviceCode(); refreshAccount(); },
                 Math.max(10000, (res.expires_at || Date.now() + 300000) - Date.now()));
    });
  }

  // OAuth web-flow СТРОГО со страницы (живой жест — Chrome не отклонит
  // окно; из background это падало бы с «Authorization page could not be loaded»)
  function startGitHubLogin() {
    const m = chrome.runtime.getManifest();
    // redirect_uri = chromiumapp.org-URL расширения (ID из `key` в manifest) —
    // единственная редирект-URL, зарегистрированная в OAuth App GitHub;
    // chrome.runtime.getURL('oauth-callback.html') (chrome-extension://…)
    // GitHub не принимает → «redirect_uri mismatch»
    const redirectUri = chrome.identity.getRedirectURL();
    const authUrl = 'https://github.com/login/oauth/authorize'
      + '?client_id=' + encodeURIComponent(m.oauth2.client_id)
      + '&scope=' + encodeURIComponent('gist')
      + '&redirect_uri=' + encodeURIComponent(redirectUri);
    chrome.identity.launchWebAuthFlow({ url: authUrl, interactive: true }, (resultUrl) => {
      if (chrome.runtime.lastError) {
        // Auth-окно не открылось (кPageLoadFailure и т.п.) — Device Flow:
        // код + обычная вкладка github.com/login/device (без спец-окон)
        startDeviceFlowLogin();
        return;
      }
      if (!resultUrl) return; // окно закрыто/отменено
      const params = new URLSearchParams(new URL(resultUrl).search);
      const code = params.get('code');
      const error = params.get('error');
      if (!code) {
        setAccountSub(error ? 'GitHub: ' + error : t('account_sync_error'));
        return;
      }
      chrome.runtime.sendMessage({ action: 'oauth-exchange', code, redirectUri }, (token) => {
        if (token) {
          refreshAccount(); // токен в storage → подпись «GitHub: <login>»
        } else {
          chrome.storage.local.get('github-auth-error', (r) => {
            setAccountSub(r['github-auth-error'] || t('account_sync_error'));
          });
        }
      });
    });
  }

  slot.addEventListener('click', () => {
    openGitHubModal();
  });

  // === Модалка GitHub: полная панель аккаунта (подключение/синхронизация) —
  // перенесена из popup. Открывается по клику на слот аккаунта; рейка
  // показывает только текущее состояние.
  const ghModal = document.getElementById('github-modal');
  const ghStatus = document.getElementById('github-modal-status');
  const ghConnect = document.getElementById('github-connect-btn');
  const ghSync = document.getElementById('github-sync-btn');
  const ghClear = document.getElementById('github-clear-btn');
  const ghDisconnect = document.getElementById('github-disconnect-btn');
  const ghRetry = document.getElementById('github-retry-btn');
  const ghClose = document.getElementById('github-modal-close');

  function ghStatusSet(text) {
    if (ghStatus) ghStatus.textContent = text;
  }
  // Статус пишется и в рейку (.a-s), и в модалку (если открыта)
  function setAccountSub(text) {
    if (sub) sub.textContent = text;
    ghStatusSet(text);
  }

  function renderGitHubModal(showChecking = true) {
    if (!ghModal || !ghModal.classList.contains('open')) return;
    chrome.storage.local.get(['github-token', 'blattam-github-login', 'github-auth-error'], (r) => {
      if (!r['github-token']) {
        if (ghConnect) ghConnect.style.display = '';
        if (ghSync) ghSync.style.display = 'none';
        if (ghClear) ghClear.style.display = 'none';
        if (ghDisconnect) ghDisconnect.style.display = 'none';
        ghStatusSet(r['github-auth-error'] || t('github_not_connected'));
        return;
      }
      if (ghConnect) ghConnect.style.display = 'none';
      if (ghSync) ghSync.style.display = '';
      if (ghClear) ghClear.style.display = '';
      if (ghDisconnect) ghDisconnect.style.display = '';
      // Вспышка «проверяем» только для пользовательских проверок; тихий
      // retry (showChecking=false) не мигает статусом.
      if (showChecking) ghStatusSet(t('account_verifying'));
      if (ghRetry) ghRetry.style.display = '';
      chrome.runtime.sendMessage({ action: 'verify-github' }, (res) => {
        let name = null;
        if (res && res.success) {
          clearVerifyRetry();
          name = res.user.login;
          chrome.storage.local.set({ 'blattam-github-login': name });
        } else if (r['blattam-github-login']) {
          clearVerifyRetry();
          name = r['blattam-github-login'];
        } else if (res && res.token_present) {
          if (isAuthVerifyError(res.error)) {
            clearVerifyRetry();
            ghStatusSet(t('account_token_invalid'));
            if (ghRetry) ghRetry.style.display = '';
            return;
          }
          ghStatusSet(t('account_verify_error'));
          scheduleVerifyRetry();
          if (ghRetry) ghRetry.style.display = '';
          return;
        } else {
          ghStatusSet(t('account_verify_error'));
          scheduleVerifyRetry();
          if (ghRetry) ghRetry.style.display = '';
          return;
        }
        if (ghRetry) ghRetry.style.display = 'none';
        chrome.runtime.sendMessage({ action: 'check-sync-status' }, (st) => {
          const map = { synced: t('github_synced'), ahead: t('github_local_ahead'), behind: t('github_remote_ahead') };
          ghStatusSet('GitHub: ' + name + ' · ' + (map[st] || t('github_status_unknown')));
        });
      });
    });
  }

  function openGitHubModal() {
    ghModal.classList.add('open');
    setModalOpen('github');
    renderGitHubModal();
  }

  function closeGitHubModal() {
    ghModal.classList.remove('open');
    setModalOpen(null);
  }

  ghClose.addEventListener('click', closeGitHubModal);
  ghModal.addEventListener('click', (e) => {
    if (e.target === ghModal) closeGitHubModal();
  });
  document.addEventListener('keydown', (e) => {
    if (ghModal.classList.contains('open') && e.key === 'Escape') closeGitHubModal();
  });

  ghConnect.addEventListener('click', () => startGitHubLogin());

  // «Проверить ещё раз» — немедленный повтор verify (авто-retry и так
  // крутится каждые 30 с; кнопка — ручное ускорение)
  ghRetry.addEventListener('click', () => { refreshAccount(); renderGitHubModal(); });

  ghSync.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'sync-now' }, (res) => {
      const ok = !!(res && (res.pulled || res.pushed));
      ghStatusSet(ok ? t('account_sync_done')
                     : ((res && res.error) ? t('account_sync_error_detail', { err: res.error })
                                           : t('account_sync_error')));
      // Ошибка остаётся видимой: renderGitHubModal НЕ затирает её.
      if (ok) setTimeout(renderGitHubModal, 3000);
    });
  });

  ghClear.addEventListener('click', () => {
    if (!confirm(t('github_clear_confirm'))) return;
    chrome.runtime.sendMessage({ action: 'clear-cloud' }, () => {
      ghStatusSet(t('github_cleared'));
      setTimeout(renderGitHubModal, 3000);
    });
  });

  ghDisconnect.addEventListener('click', () => {
    // токен исчезнет из storage → onChanged ниже перерисует рейку и модалку
    chrome.runtime.sendMessage({ action: 'disconnect-github' });
  });

  // Копирование кода в буфер: клик — navigator.clipboard.writeText,
  // фидбек ✓ (возврат глифа через 1.5 с). Отказ буфера — выделить код,
  // чтобы можно было скопировать руками (текст выделяемый: user-select text).
  if (devCopyBtn && devCodeEl) {
    devCopyBtn.addEventListener('click', function () {
      const code = devCodeEl.textContent;
      if (!code || !(navigator.clipboard && navigator.clipboard.writeText)) {
        const sel = window.getSelection();
        if (sel) sel.selectAllChildren(devCodeEl);
        return;
      }
      navigator.clipboard.writeText(code).then(function () {
        devCopyBtn.textContent = '✓';
        setTimeout(function () { devCopyBtn.textContent = '⧉'; }, 1500);
      }).catch(function () {
        const sel = window.getSelection();
        if (sel) sel.selectAllChildren(devCodeEl);
      });
    });
  }

  // Слот обновляется, когда токен появляется/исчезает (вход/выход из popup или отсюда)
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local' && changes['github-token']) { refreshAccount(); renderGitHubModal(); }
  });

  refreshAccount();
})();
